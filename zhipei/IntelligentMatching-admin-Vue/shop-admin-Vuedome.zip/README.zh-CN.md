
<p align="center">
  <h3>蓝科后台</h3>
</p> 
<p>
项目:全源兴农溯源管理系统 
</p>
 <p>版本:1.0.0;</p>
 <p>基于 vue-element-admin 开发,地址:http://panjiachen.github.io/vue-element-admin</p>




