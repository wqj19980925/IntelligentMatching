<template>
	<div>
		<!-- 信息筛选 -->
		<el-row class="mainContentItemBox">
			<div class="mainHeaderTitleBox">
				<div class="titleNameBox">信息筛选</div>
				<div class="buttonBox"></div>
			</div>
			<el-form ref="formList" :model="formList" size="medium" label-width="100px" class="mainSearchItemBox">
				<el-row>
					<el-col :span="6">
						<el-form-item label="渠道名称:" prop="chan_unit_name">
							<el-input v-model="formList.chan_unit_name" placeholder="请输入渠道名称" clearable class="mainIptSelBox"/>
						</el-form-item>
					</el-col>
					<el-col :span="6">
						<el-form-item label="配送商:" prop="chre_distributors_chan_id">
							<el-select v-model="formList.chre_distributors_chan_id" placeholder="请选择渠道" @click.native="getReplenishChannel()" filterable remote :remote-method="getReplenishChannel" clearable class="mainIptSelBox">
								<el-option v-for="item in replenishChannelInfo" :key="item.chan_id" :label="item.chan_unit_name" :value="item.chan_id"/>
							</el-select>
						</el-form-item>
					</el-col>
					<el-col :span="6">
						<el-form-item label="补货职务:" prop="chre_duty_state">
							<el-select v-model="formList.chre_duty_state" clearable class="mainIptSelBox">
								<el-option v-for="item in stateSelectInfo" :key="item.id" :label="item.name" :value="item.id"/>
							</el-select>
						</el-form-item>
					</el-col>
					<el-col :span="6">
						<el-button class type="primary" @click="searchList('formList')">搜&nbsp;&nbsp;索</el-button>
						<el-button class @click="resetForm('formList')">重&nbsp;&nbsp;置</el-button>
					</el-col>
				</el-row>
			</el-form>
		</el-row>
		<!-- 列表 -->
		<el-row class="mainContentItemBox">
			<div class="mainHeaderTitleBox">
				<div class="titleNameBox">补货关系列表</div>
				<div class="buttonBox"></div>
			</div>
			<el-table :data="listData" width="100%" @selection-change="handleSelectionChange">
				<el-table-column type="selection" width="55"/>
				<el-table-column label="渠道商" prop="chan_unit_name" min-width align="center"/>
				<el-table-column label="补货职务" prop="" align="center">
					<template slot-scope="scope">
						<span v-if="scope.row.chre_duty_state">{{ stateSelectInfo[scope.row.chre_duty_state-1].name }}</span>
						<span v-else>--</span>
					</template>
				</el-table-column>
				<el-table-column label="配送商" prop="" align="center">
					<template slot-scope="scope">
						<span v-if="scope.row.chre_distributors_chan_unit_name">{{ scope.row.chre_distributors_chan_unit_name }}</span>
						<span v-else>--</span>
					</template>
				</el-table-column>
				<el-table-column label="配送名单" prop="" align="center">
					<template slot-scope="scope">
						<span v-if="(scope.row.chre_duty_state == 2 || scope.row.chre_duty_state == 3) && scope.row.chre_shop_quantity !== ''">{{ scope.row.chre_shop_quantity }}</span>
						<span v-else>--</span>
					</template>
				</el-table-column>
				<el-table-column label="操作" width="260" align="center">
					<template slot-scope="scope">
						<div class="mainOperationBtnBox">
							<el-button type="primary" v-if="btnShow.setBtn && scope.row.chre_duty_state == 0" @click="setRelationBtn(scope.row)">关系设定</el-button>
							<el-button type="primary" v-if="btnShow.altBtn && (scope.row.chre_duty_state == 2 || scope.row.chre_duty_state == 3)" @click="altRelationBtn(scope.row)">关系变更</el-button>
							<el-button v-if="btnShow.repBtn && (scope.row.chre_duty_state == 2 || scope.row.chre_duty_state == 3)" class="btn-delete" @click="replenishRescissionBtn(scope.row)">补货解约</el-button>
							<el-button v-if="btnShow.delBtn && scope.row.chre_duty_state == 1" class="btn-delete" @click="deliveryRescissionBtn(scope.row)">配送解约</el-button>
							<el-button v-if="btnShow.detBtn && scope.row.chre_shop_quantity != 0 && (scope.row.chre_duty_state == 2 || scope.row.chre_duty_state == 3)" class="btn-mainCol" @click="deliveryDetailBtn(scope.row)">配送详情</el-button>
						</div>
					</template>
				</el-table-column>
			</el-table>
			<div v-if="listData.length>0" class="mainPageTurningBox">
				<el-pagination :current-page="currentPage" :page-size="pageSize" :total="totalNum" layout="total, prev, pager, next, jumper" background @current-change="handleCurrentChange"/>
			</div>
		</el-row>
		<!-- 关系设定 -->
		<el-dialog :visible.sync="setRelationDialog.show" :title="setRelationDialog.title" :width="setRelationDialog.width" :close-on-click-modal="false" @close="resetForm('setRelationForm')" >
			<el-form ref="setRelationForm" :model="setRelationForm"  label-width="100px">
				<el-form-item label="渠道名称:" prop="chan_unit_name" class="mainFormSeeInfoBox">
					{{setRelationForm.chan_unit_name}}
				</el-form-item>
				<el-form-item label="配送职务:" prop="chre_duty_state" class="mainFormSeeInfoBox" v-if="addAndEditShow">
					<el-radio-group v-model="setRelationForm.chre_duty_state" @change="setChangeChreDutyBtn">
						<el-radio :label="1">安装门店</el-radio>
						<el-radio :label="2">配送商</el-radio>
						<el-radio :label="3">安装门店+配送商</el-radio>
					</el-radio-group>
				</el-form-item>
				<el-form-item label="配送职务:" prop="chre_duty_state" class="mainFormSeeInfoBox" v-else>
					<span v-if="setRelationForm.chre_duty_state != 0">{{ stateSelectInfo[setRelationForm.chre_duty_state-1].name }}</span>
				</el-form-item>
				<el-form-item label="选择配送商:" v-if="setRelationForm.chre_duty_state == 1">
					<el-select v-model="setRelationForm.chre_distributors_chan_id" placeholder="请选择配送商" @click.native="getReplenishChannel()" filterable remote :remote-method="getReplenishChannel" class="mainIptSelBox">
						<el-option v-for="item in replenishChannelInfo" :key="item.chan_id" :label="item.chan_unit_name" :value="item.chan_id"/>
					</el-select>
				</el-form-item>
				<el-form-item prop="chre_distributors_list" v-if="setRelationForm.chre_duty_state == 2 || setRelationForm.chre_duty_state == 3" label-width="0px" class="mainFormSeeInfoBox">
					<el-card shadow="never" class="mainCardBorNoneBox">
						<!-- <div slot="header" class="clearfix">
							<span class="titleNameBox">配送名单</span>
						</div> -->
						<el-table :data="setRelationForm.chre_distributors_list" style="width: 100%">
							<el-table-column label="单位名称" prop="info_chan_id">
								<template slot-scope="scope">
									<el-select v-model="scope.row.info_chan_id" placeholder="请选择配送商" @change="setChangeChanBtn(scope.row,scope.$index)" @click.native="getReplenishChannel()" filterable remote :remote-method="getReplenishChannel" class="mainIptSelBox">
										<el-option v-for="item in replenishChannelInfo" :key="item.chan_id" :label="item.chan_unit_name" :value="item.chan_id"/>
									</el-select>
								</template>
							</el-table-column>
							<el-table-column label="关联分店" prop="" align="center" width="120">
								<template slot-scope="scope">
									<el-switch v-model="scope.row.infoChanState" active-value="1" inactive-value="2"></el-switch>
								</template>
							</el-table-column>
							<el-table-column label="操作" prop="" align="center" width="100">
								<template slot-scope="scope">
									<el-button type="primary" icon="el-icon-delete" @click="setDeleteRelationChanBtn(scope.$index)" circle></el-button>
								</template>
							</el-table-column>
						</el-table>
					</el-card>
					<el-button type="button" class="btn-mainCol" @click="setAddRelationChanBtn">增加单位</el-button>
				</el-form-item>
			</el-form>
			<span slot="footer">
				<el-button @click="setRelationDialog.show = false">取 消</el-button>
				<el-button type="primary" @click="setRelationSubmitBtn('setRelationForm')">提 交</el-button>
			</span>
		</el-dialog>
		<!-- 补货解约 -->
		<el-dialog :visible.sync="rescissionDialog.show" :title="rescissionDialog.title" :width="rescissionDialog.width" :close-on-click-modal="false" @close="resetForm('rescissionForm')" >
			<el-form ref="rescissionForm" :model="rescissionForm" label-width="100px">
				<el-form-item label="解约提醒:" prop="chan_name" class="mainFormSeeInfoBox">
					当前操作将关闭“<span class="red">{{ rescissionForm.chan_name }}</span>”补货功能<br>之前绑定的安装门店将由新配送商进行补货，请选择新的配送商。
				</el-form-item>
				<el-form-item label="新配送商:" prop="chre_distributors_chan_id" >
					<el-select v-model="rescissionForm.chre_distributors_chan_id" placeholder="请选择配送商" @click.native ="getRescissionChannel()" filterable remote :remote-method="getRescissionChannel" class="mainIptSelBox">
						<el-option v-for="item in rescissionChannelInfo" :key="item.chan_id" :label="item.chan_unit_name" :value="item.chan_id"/>
					</el-select>
				</el-form-item>
			</el-form>
			<span slot="footer">
				<el-button @click="rescissionDialog.show = false">取 消</el-button>
				<el-button type="primary" @click="rescissionSubmitBtn('rescissionForm')">提 交</el-button>
			</span>
		</el-dialog>
		<!-- 配送详情 -->
		<el-dialog :visible.sync="detailDialog.show" :title="detailDialog.title" :width="detailDialog.width" :close-on-click-modal="false">
			<el-form ref="detailForm" :model="detailForm" label-width="100px">
				<el-form-item label="安装门店">
					<el-input v-model="detailForm.search_data" placeholder="请输入门店名称" clearable class="mainIptSelBox"/>
					<el-button class type="primary" @click="deliveryDetailBtn({chre_id:detailForm.chre_id})">搜&nbsp;&nbsp;索</el-button>
				</el-form-item>
				<el-table :data="detailForm.dataList" style="width:100%">
					<el-table-column label="序号" align="center" width="50px">
						<template slot-scope="scope">
							{{scope.$index + 1}}
						</template>
					</el-table-column>
					<el-table-column label="渠道名称" align="center" prop="chan_unit_name"></el-table-column>
					<el-table-column label="操作" align="center" width="100px">
						<template slot-scope="scope">
							<div class="mainOperationBtnBox">
								<el-button v-if="btnShow.delBtn" class="red" type="text" @click="deliveryRescissionBtn(scope.row)">解约</el-button>
							</div>
						</template>
					</el-table-column>
				</el-table>
				<div v-if="detailForm.dataList.length>0" class="mainPageTurningBox">
					<el-pagination :current-page="currentPagetwo" :page-size="pageSizetwo" :total="totalNumtwo" layout="total, prev, pager, next, jumper" background @current-change="handleCurrentChangetwo"/>
				</div>
			</el-form>
		</el-dialog>
	</div>
</template>
<script>
import { relationList,relationListtermination,replenishmentTermination,relationshipSet,relationshipChange,Listinfo } from '@/api/replenishment'
import { getChannelInfo,getDistributors,getReplenishmentChannel } from '@/api/commonAction'
import { errorStatus } from '@/utils/index'
export default {
	name: 'ClassList',
	data() {
		return {
			replenishChannelInfo:[],//开启补货的渠道
			rescissionChannelInfo:[],//补货觖约-职务为配送商的渠道
			// 搜索参数
			formList: {
				chan_unit_name: '',
				chre_distributors_chan_id: '',
				chre_duty_state: '',
			},
			// 渠道和配送下拉列表
			channelSelectInfo:[],
			// 补货职务
			stateSelectInfo: [
				{ id: 1, name: '安装门店' },
				{ id: 2, name: '配送商' },
				{ id: 3, name: '安装门店+配送商' },
			],
			listData: [],//信息列表
			chosed: '',
			currentPage: 1,//当前页码
			pageSize: null,//每页多少条
			totalNum: null,//总共多少条
			currentPagetwo: 1,//配送详情当前页码
			pageSizetwo: null,//配送详情每页多少条
			totalNumtwo: null,//配送详情总共多少条
			// 关系设定
			setRelationDialog:{
				title:'',
				show:false,
				width:'600px',
			},
			// 关系设定-表单
			setRelationForm:{
				chan_unit_name:'',
				chre_id:'',
				chre_duty_state:'',
				chre_distributors_chan_id:'',
				info_chan_id:[],
				info_chre_id:[],
				info_subbranch_state:[],
				chre_distributors_list:[],
			},
			selected_unit_list:[],//关系设定-已选配送单位
			addAndEditShow:true,//true关系设定，false关系变更
			// 补货解约
			rescissionDialog:{
				title:'补货解约',
				show:false,
				width:'500px',
			},
			// 补货解约-表单
			rescissionForm:{
				chre_id:'',
				chan_name:'',
				chre_distributors_chan_id:'',
			},
			// 配送详情
			detailDialog:{
				title:'配送详情',
				show:false,
				width:'600px',
			},
			// 配送详情-表单
			detailForm:{
				chre_id:'',
				search_data:'',
				dataList:[],
			},
			// 按钮权限
			btnShow: {
				setBtn: false,
				altBtn: false,
				repBtn: false,
				delBtn: false,
				detBtn: false,
			},
		}
	},
	created() {
		// 页面加载时
		this.getPageInfo()
	},
	methods: {
		// 获取列表
		getPageInfo() {
			const loading = this.$loading({
				lock: true,
				text: 'Loading',
				spinner: 'el-icon-loading',
				background: 'rgba(0, 0, 0, 0.7)'
			})
			const data = this.formList;
			data.page = this.currentPage;
			data.pri_id = this.$route.meta.pri_id;
			relationList(data).then(response => {
				loading.close()
				const dataRep = response.data
				if (errorStatus(dataRep)) {
					// console.log(dataRep);
					this.listData = dataRep.data.data;
					for(let i in this.listData){
						for(let j in dataRep.data.find_chan){
							if(this.listData[i].chre_distributors_chan_id == dataRep.data.find_chan[j].chan_id){
								this.listData[i].chre_distributors_chan_unit_name = dataRep.data.find_chan[j].chan_unit_name;
								break;
							}
						}
					}
					this.currentPage = dataRep.data.current_page
					this.pageSize = dataRep.data.current_number
					this.totalNum = dataRep.data.total
					const btnList = dataRep.list_button
					for (const i in btnList) {
						if (btnList[i].pri_method_name === '关系设定') {
							this.btnShow.setBtn = true
						} else if (btnList[i].pri_method_name === '关系变更') {
							this.btnShow.altBtn = true
						} else if (btnList[i].pri_method_name === '补货解约') {
							this.btnShow.repBtn = true
						} else if (btnList[i].pri_method_name === '解约') {
							this.btnShow.delBtn = true
						} else if (btnList[i].pri_method_name === '详情') {
							this.btnShow.detBtn = true
						}
					}
				}
				
			})
			.catch(Error => {
				loading.close()
				this.$message.error('请求失败!')
				// console.log("获取列表err", err);
			})
		},
		// 搜索
		searchList(formName) {
			this.currentPage = 1
			this.getPageInfo()
		},
		// 选中状态
		handleSelectionChange(val) {
			this.chosed = val
		},
		// 页面--分页器
		handleCurrentChange(val) {
			// console.log(`当前页: ${val}`)
			this.currentPage = val
			this.getPageInfo()
		},
		// 重置
		resetForm(formName) {
			this.$refs[formName].resetFields()
		},
		// 获取开启补货的渠道
		getReplenishChannel(val) {
			const data = {}
			data.search_data = val
			getReplenishmentChannel(data).then(response => {
				const dataRep = response.data
				if(errorStatus(dataRep)){
					this.replenishChannelInfo = dataRep.data.data
				}
			})
		},
		// 获取解约渠道
		getRescissionChannel(query) {
			const data = {}
			data.search_data = query
			getDistributors(data).then(response => {
				const dataRep = response.data
				if(errorStatus(dataRep)){
					this.rescissionChannelInfo = dataRep.data.data
				}
			})
		},
		// 配送详情-打开
		deliveryDetailBtn(val){
			this.detailForm.dataList = [];
			this.detailForm.chre_id = val.chre_id;
			this.detailDialog.show = true;
			this.deliveryDetailSearchBtn();
		},
		// 配送详情-搜索
		deliveryDetailSearchBtn(){
			const data = {}
			data.chre_id = this.detailForm.chre_id;
			data.search_data = this.detailForm.search_data;
			data.page = this.currentPagetwo;
			Listinfo(data).then(response=>{
				this.detailForm.dataList = [];
				const dataRep = response.data;
				if(errorStatus(dataRep)){
					this.detailForm.dataList = dataRep.data.data;
					// console.log(this.Listinfodata)
					this.currentPagetwo = dataRep.data.current_page;
					this.pageSizetwo = dataRep.data.current_number;
					this.totalNumtwo = dataRep.data.total;
				}
			}).catch(err=>{
				this.$message.error('配送详情获取失败！')
			})
		},
		// 配送详情-分页
		handleCurrentChangetwo(val){
			this.currentPagetwo = val
			this.deliveryDetailSearchBtn();
		},
		// 关系设定-打开
		setRelationBtn(val){
			// console.log(val);
			this.setRelationForm.chre_duty_state = '';
			this.setRelationForm.chre_distributors_chan_id = '';
			this.setRelationForm.info_chan_id = [];
			this.setRelationForm.info_chre_id = [];
			this.setRelationForm.info_subbranch_state = [];
			this.setRelationForm.chre_distributors_list = [];
			this.setRelationForm.chan_unit_name = val.chan_unit_name;
			this.setRelationForm.chre_id = val.chre_id;
			this.replenishChannelInfo = [];
			this.selected_unit_list = [];
			this.setRelationDialog.title = "关系设定";
			this.addAndEditShow = true;
			this.setRelationDialog.show = true;
		},
		// 关系设定-更换配送职务
		setChangeChreDutyBtn(val){
			// 1安装门店 2配送商 3安装门店+配送商
			if(val == 1){
				this.setRelationForm.chre_distributors_list = [];
				this.selected_unit_list = [];//清空已选配送单位
			}else if(val == 2 || val == 3){
				this.setRelationForm.chre_distributors_chan_id = '';
			}
		},
		// 关系设定（变更）-增加配送单位项
		setAddRelationChanBtn(){
			const chanListData = this.setRelationForm.chre_distributors_list;
			if(chanListData.length > 0){
				for(let i in chanListData){
					if(chanListData[i].info_chan_id == ''){
						this.$message.warning('请选择配送单位，再增加新的！');
						return false;
					}
				}
			}
			this.setRelationForm.chre_distributors_list.push({
				info_chan_id:"",
				info_subbranch_state:2,
			});
			// console.log('----',this.setRelationForm.chre_distributors_list)
		},
		// 关系设定（变更）-删除配送单位项
		setDeleteRelationChanBtn(index){
			this.setRelationForm.chre_distributors_list.splice(index,1);
			this.selected_unit_list.splice(index,1);
		},
		// 关系设定（变更）-选择配送单位
		setChangeChanBtn(val,index){
			// console.log(val);
			var exist = true;//是否存在
			if(this.selected_unit_list.length != 0){
				for(let i in this.selected_unit_list){
					if(val.info_chan_id == this.selected_unit_list[i]){
						this.$message.warning('当前配送单位已选择，请选择其他配送单位！');
						val.info_chan_id = ''
						this.selected_unit_list[index] = ''
						exist = false;//已存在
						break;
					}
				}
				if(exist){
					this.selected_unit_list[index] = val.info_chan_id
				}
			}else{
				this.selected_unit_list.push(val.info_chan_id);
			}
			// console.log(this.selected_unit_list);
		},
		// 关系设定（变更）-提交
		setRelationSubmitBtn(){
			if(this.setRelationForm.chre_duty_state == ''){
				this.$message.warning('请选择配送职务！');
				return false;
			}
			if(this.setRelationForm.chre_duty_state == 1 && this.setRelationForm.chre_distributors_chan_id == ''){
				this.$message.warning('请选择配送商！');
				return false;
			}
			if(this.setRelationForm.chre_duty_state != 1){
				const chanListData = this.setRelationForm.chre_distributors_list;
				if(chanListData.length == 0){
					this.$message.warning('请增加配送单位！');
					return false;
				}
				for(let i in chanListData){
					if(chanListData[i].info_chan_id == ''){
						this.$message.warning('请选择配送单位名称！');
						return false;
					}
				}
				this.setRelationForm.info_subbranch_state = [];
				for(let i in chanListData){
					this.setRelationForm.info_subbranch_state.push(chanListData[i].infoChanState);
				}
			}
			const data = this.setRelationForm
			data.info_chan_id = this.selected_unit_list;
			data.info_chre_id = this.selected_unit_list;
			relationshipSet(data).then(response=>{
				const dataRep = response.data
				if(errorStatus(dataRep)){
					this.$message.success(dataRep.data);
					this.setRelationDialog.show = false
					this.getPageInfo();
				}
			}).catch(Err=>{
				this.$message.error('关系设定失败！')
			})
		},
		// 关系更换-打开
		altRelationBtn(val){
			this.setRelationDialog.title = '关系变更';
			this.addAndEditShow = false;
			this.setRelationForm.chre_id = val.chre_id;
			this.setRelationForm.chan_unit_name = val.chan_unit_name;
			const data = {};
			data.type = 1;
			data.chre_id = val.chre_id;
			relationshipChange(data).then(response=>{
				const dataRep = response.data
				if(errorStatus(dataRep)){
					this.replenishChannelInfo = dataRep.data.chan_name
					this.setRelationForm.chre_duty_state = dataRep.data.chre_duty_state
					const dataList = JSON.parse(dataRep.data.chre_distributors_list)
					this.setRelationForm.chre_distributors_list = [];
					this.selected_unit_list = [];
					for(let i in dataList){
						this.setRelationForm.chre_distributors_list.push({
							info_chan_id:dataList[i].chan_id,
							info_subbranch_state:dataList[i].subbranch_state,
						});
						this.selected_unit_list.push(dataList[i].chre_id);
					}
					this.setRelationDialog.show = true;
				}
			}).catch(err=>{
				this.$message.error('信息获取失败！')
			})
		},
		// 配送解约
		deliveryRescissionBtn(val){
			const h = this.$createElement;
        	this.$msgbox({
				title: '解约',
				message: h('p', null, [ 
					h('span', null, '您确认要将 '),
					h('span', { style: 'color: #ff0000' }, val.chan_unit_name),
					h('span', null, ' 移出配送名单'),
				]),
				showCancelButton: true,
				confirmButtonText: '确定',
				cancelButtonText: '取消',
			}).then(() => {
				const datadd ={
					chre_id:val.chre_id
				}
				relationListtermination(datadd).then(response=>{
					const dataRep = response.data
					if(errorStatus(dataRep)){
						this.$message.success(dataRep.data);
						this.getPageInfo();
					}
				}).catch(err=>{
					this.$message.error('解约失败，请稍候重试！');
				})
			}).catch(() => {
			});
		},
		// 补货解约-打开
		replenishRescissionBtn(val){
			// console.log(val);
			this.rescissionForm.chre_id = val.chre_id;
			this.rescissionForm.chan_name = val.chan_unit_name;
			this.rescissionDialog.show = true;
		},
		// 补货解约-提交
		rescissionSubmitBtn(){
			if(this.rescissionForm.chre_distributors_chan_id == ''){
				this.$message.warning('请选择新的配送商！');
				return false;
			}
			const data = {}
			data.chre_id = this.rescissionForm.chre_id;
			data.chre_distributors_chan_id = this.rescissionForm.chre_distributors_chan_id;
			replenishmentTermination(data).then(response=>{
				const dataRep = response.data
				if(errorStatus(dataRep)){
					this.$message.success(dataRep.data);
					this.rescissionDialog.show = false;
					this.getPageInfo();
				}
			}).catch(err=>{
				this.$message.error('补货解约失败！')
			})
		},
	}
}
</script>
<style>
.mainCardBorNoneBox .el-card__body{padding:10px 0!important;}
</style>
