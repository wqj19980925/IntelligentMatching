<template>
    <div>
		<!-- 信息筛选 -->
		<el-row class="mainContentItemBox" >
			<div class="mainHeaderTitleBox">
				<div class="titleNameBox">信息筛选</div>
				<div class="buttonBox">
					<el-button v-if="btnShow.DistributionImportBtn" @click="DistributionImportBtn" type="primary">配送单导入</el-button>
				</div>
			</div>
			<el-form ref="formList" :model="formList" size="medium" label-width="100px" class="mainSearchItemBox">
				<el-row>
					<el-col :span="24">
						<el-form-item label="状态:" prop="shbi_state">
                            <el-badge class="mainStateBtnBox" >
                                <el-button :type="shbi_state ==1 ? 'primary':''" @click="getdatastate(1)">待审核</el-button>
                            </el-badge>
                            <el-badge   class="mainStateBtnBox">
                                <el-button  @click="getdatastate(2)"  :type="shbi_state ==2 ? 'primary':''">未完成</el-button>
                            </el-badge>
                            <el-badge   class="mainStateBtnBox">
                                <el-button @click="getdatastate(3)" :type="shbi_state ==3 ? 'primary':''">已完成</el-button>
                            </el-badge>
                            <el-badge   class="mainStateBtnBox">
                                <el-button @click="getdatastate(4)" :type="shbi_state ==4 ? 'primary':''">已驳回</el-button>
                            </el-badge>
                           
						</el-form-item>
					</el-col>
                    
					<el-col :span="6">
						<el-form-item  label="配送账单:" prop="shbi_shipping_number">
							<el-input  v-model="formList.shbi_shipping_number" placeholder="请输入补货单号" clearable  class="mainIptSelBox"/>
						</el-form-item>
					</el-col>
                    <el-col :span="6">
                        <el-form-item label="配送商:" prop="shbi_chan_id">
							<el-select v-model="formList.shbi_chan_id" placeholder="请选择配送商" class="mainIptSelBox"  @click.native ="getDistributors('',1)" clearable filterable  :multiple="false" remote :remote-method="(query)=>{getDistributors(query,1)}">
								<el-option v-for="item in channelList" :key="item.chan_id" :label="item.chan_unit_name" :value="item.chan_id"/>
							</el-select>
						</el-form-item>
                    </el-col>
                     <el-col :span="6">
                        <el-form-item label="安装门店:" prop="shbi_shop_id">
							<el-select v-model="formList.shbi_shop_id" placeholder="请选择安装门店" class="mainIptSelBox"  @click.native ="getShops('',1)" clearable filterable  :multiple="false" remote :remote-method="(query)=>{getShops(query,1)}">
								<el-option v-for="item in StoreList" :key="item.chan_id" :label="item.chan_unit_name" :value="item.chan_id"/>
							</el-select>
						</el-form-item>
                    </el-col>
					<el-col :span="6">
						<el-form-item label="原补货账单:" prop="shbi_sd_replenishment_number">
							<el-input v-model="formList.shbi_sd_replenishment_number" placeholder="请输入原补货账单" clearable  class="mainIptSelBox"/>
						</el-form-item>
					</el-col>
					
					<el-col :span="6">
						<el-form-item label="补货职务:"  prop="shbi_duty_state">
                            <el-select v-model="formList.shbi_duty_state" class="mainIptSelBox" placeholder="请选择补货职务"> 
                                <el-option value="3" label="全部"></el-option>
                                <el-option value="2" label="部分"></el-option>
                                <el-option value="1" label="未补"></el-option>
                            </el-select>
						</el-form-item>
					</el-col>
					<el-col :span="6">
						<el-form-item label="补货进度:" prop="shbi_replenish_state">
                            <el-select v-model="formList.shbi_replenish_state" class="mainIptSelBox" placeholder="请选择补货进度">
                                <el-option value="3" label="补全"></el-option>
                                <el-option value="2" label="部分"></el-option>
                                <el-option value="1" label="未补"></el-option>
                            </el-select>
						</el-form-item>
					</el-col>
					<el-col :span="6">
						<el-form-item label="创建时间:" prop="Time">
                            <el-date-picker v-model="formList.Time" type="daterange" value-format="yyyy-MM-dd" range-separator="至" start-placeholder="开始日期" end-placeholder="结束日期" class="mainIptSelBox"></el-date-picker>
						</el-form-item>
					</el-col>
					<el-col :span="5">
						<el-button type="primary" @click="searchList('formList')">搜&nbsp;&nbsp;索</el-button>
						<el-button @click="resetForm('formList')">重&nbsp;&nbsp;置</el-button>
					</el-col>
				</el-row>
			</el-form>
		</el-row>
        <!-- 列表 -->
		<el-row class="mainContentItemBox" >
			<div class="mainHeaderTitleBox">
				<div class="titleNameBox">配送账单列表</div>
				<div class="buttonBox"></div>
			</div>
			<el-table :data="listData" width="100%" >
				<el-table-column label="创建时间" width="100" prop="shbi_create_time"  align="center"/>
				<el-table-column label="配送账单" width="120" prop="shbi_shipping_number" align="center"/>
				<el-table-column label="补货职务" width="120"   align="center">
					<template slot-scope="scope">
						<div>
							{{scope.row.shbi_duty_state == 0?'无':scope.row.shbi_duty_state == 1 ? '安装门店' : scope.row.shbi_duty_state == 2 ? '配送商' : '配送商+安装门店' }}
						</div>
					</template>
				</el-table-column>
				<el-table-column label="收货对象" width="200"  align="left">
					<template slot-scope="scope">
						<div>
							<p>安装门店：{{scope.row.shbi_shop_name}}</p>
							<p>配送商：{{scope.row.shbi_chan_name || '无'}}</p>
						</div>
					</template>
				</el-table-column>
				<el-table-column label="原补货账单" width="120" prop="shbi_sd_replenishment_number" align="center"/>
				<el-table-column label="商品总量" width="80" prop="shbi_bill_amount"  align="center"/>
				<el-table-column label="已送货" width="80" prop="shbi_delivery_quantity" class="red" align="center"/>
				<el-table-column label="未补货" width="80" prop="shbi_no_replenishment" class="red" align="center"/>
				<el-table-column label="合计物流费" width="120" prop="shbi_logistic_total_money" align="center"/>
				<el-table-column label="兑现信息" width="120" align="center">
					<template slot-scope="scope">
						<div>
							<p>兑现数量：{{scope.row.shbi_cash_amount}}</p>
							<p>兑现金额：{{scope.row.shbi_cash_total_money}}</p>
						</div>
					</template>
				</el-table-column>
				<el-table-column label="送货单数" width="80" prop="shbi_delivery_order_quantity" align="center"/>
				<el-table-column label="备注" width="120" prop="shbi_remark" align="center"/>
				<el-table-column label="补货进度" width="120" align="center">
                    <template slot-scope="scope">
                        <div>
                            {{scope.row.shbi_replenish_state == 1?'未补':scope.row.shbi_replenish_state == 2?'部分':'补全'}}
                        </div>
                    </template>
                </el-table-column>
				<el-table-column label="状态" width="120" align="center">
                    <template slot-scope="scope">
                        <div>
                            {{scope.row.shbi_state == 1?'待审核':scope.row.shbi_state == 2?'未完成':scope.row.shbi_state == 3 ? '已完成' : '已驳回'}}
                        </div>
                    </template>
                </el-table-column>
				<el-table-column label="操作"  fixed='right' width="200" align="center">
					<template slot-scope="scope" >
                        <div class="mainOperationBtnBox">
                            <el-button class="btn-delete" v-if="btnShow.RemarksBtn" @click="RemarksBtn(scope.row,1)">账单备注</el-button>
                            <el-button type="primary" v-if="btnShow.detailsBtn" @click="detailsBtn(scope.row)">账单详情</el-button>
                            <el-button class="btn-delete" v-if="btnShow.toExamineBtn" @click="toExamineBtn(scope.row)">账单审核</el-button>
                            <el-button type="primary" v-if="btnShow.exportBtn" @click="exportBtn(scope.row)">账单导出</el-button>
                            
                            <el-button class="btn-delete" v-if="btnShow.primaryreplenishbillBtn" @click="primaryreplenishbillBtn(scope.row)">原补货账单</el-button>
                            <el-button class="btn-delete" v-if="btnShow.DeliveryBtn" @click="DeliveryBtn(scope.row)">送货账单</el-button>
                        </div>
					</template>
				</el-table-column> 
			</el-table>
			<div v-if="listData.length>0" class="mainPageTurningBox">
				<el-pagination :current-page="currentPage" :page-size="pageSize" :total="totalNum" layout="total, prev, pager, next, jumper" background @current-change="handleCurrentChange"/>
			</div>
		</el-row>
        <el-dialog :visible.sync="settingDialog.show" :title="settingDialog.title" :close-on-click-modal="false"  :width="settingDialog.width" @closed="closedialog('settingFrom')" >
            <el-form ref="settingFrom" :model="settingFrom"  label-width="120px" :rules="formRules">
                <div v-if="settingDialog.title == '账单备注' || settingDialog.title ==  '送货备注'">
                    <el-form-item label="备注内容" prop="shbi_remark">
                        <textarea   type="textarea" class="w340 h80"   :autosize="{ minRows: 2, maxRows: 4}" placeholder="请输入备注内容" v-model="settingFrom.shbi_remark"></textarea>
                    </el-form-item>
                </div>
				<div v-if="settingDialog.title == '配送单导入'" >
					<el-form-item label="上传文件："  required >
						<input type="file" id="filexcel" @change="uploadfile" accept=".xls, .xlsx"/>
                    </el-form-item>
				</div>
                <div v-if="settingDialog.title == '配送账单审核'|| settingDialog.title == '配送账单详情'|| settingDialog.title ==  '送货账单详情'">
                    <el-row>
                        <el-col :span="8">
                            <el-form-item v-if="settingDialog.title == '配送账单审核'|| settingDialog.title == '配送账单详情'" label="配送账单：">
                                {{settingFrom.find_bill.shbi_shipping_number}}
                            </el-form-item>
                            <el-form-item label="送货单：" v-else>
                                {{settingFrom.find_bill.dere_number}}
                            </el-form-item>                         
                        </el-col>
                        <el-col :span="8">
                             <el-form-item label="创建时间：" v-if="settingDialog.title == '配送账单审核'|| settingDialog.title == '配送账单详情'">
                                {{settingFrom.find_bill.shbi_create_time}}
                            </el-form-item> 
                            <el-form-item label="送货时间：" v-else>
                                {{settingFrom.find_bill.dere_create_time}}
                            </el-form-item>
                        </el-col>
                        <el-col :span="8">
                             <el-form-item label="商品总量："  v-if="settingDialog.title == '配送账单审核'|| settingDialog.title == '配送账单详情'">
                                {{settingFrom.find_bill.shbi_bill_amount}}
                            </el-form-item> 
                            <el-form-item label="送货量" v-else>
                                {{settingFrom.find_bill.dere_plan_send_amount}}
                            </el-form-item>
                        </el-col>
                        <el-col :span="8">
                             <el-form-item label="配送商："  v-if="settingDialog.title == '配送账单审核'|| settingDialog.title == '配送账单详情'">
                                {{settingFrom.find_bill.shbi_chan_name || '无'}}
                            </el-form-item> 
                            <el-form-item label="配送费：" v-else>
                                {{settingFrom.find_bill.dere_logistic_total_money}}
                            </el-form-item>
                        </el-col>
                        <el-col :span="8">
                             <el-form-item label="安装门店：" v-if="settingDialog.title == '配送账单审核'|| settingDialog.title == '配送账单详情'">
                                {{settingFrom.find_bill.shbi_shop_name}}
                            </el-form-item>
                            <el-form-item label="安装门店：" v-else>
                                {{DeliveryForm.shbi_shop_name}}
                            </el-form-item>
                            
                        </el-col>
                        <el-col :span="24">
                             <el-form-item label="备注：" v-if="settingDialog.title == '配送账单审核'|| settingDialog.title == '配送账单详情'">
                                {{settingFrom.find_bill.shbi_remark}}
                            </el-form-item> 
                            <el-form-item label="备注：" v-else>
                                 {{settingFrom.find_bill.dere_remark}}
                            </el-form-item>
                        </el-col>
                    </el-row>
                    <el-row>
                        <el-table border  :data="settingFrom.find_bill_goods" style="width: 100%" v-if="settingDialog.title == '配送账单审核'|| settingDialog.title == '配送账单详情'|| settingDialog.title ==  '送货账单详情'">
                            <el-table-column align="center" label="商品名称" >
                                <template slot-scope="scope">
                                   {{settingDialog.title != '送货账单详情'? scope.row.shbg_goo_name:scope.row.dego_goo_name}}
                                </template>
                            </el-table-column>
                            <el-table-column align="center" label="商品编码" >
                                 <template slot-scope="scope">
                                   {{settingDialog.title != '送货账单详情'? scope.row.shbg_goo_encode:scope.row.dego_goo_encode}}
                                </template>
                            </el-table-column>
                            <el-table-column align="center" label="品类" >
                                 <template slot-scope="scope">
                                   {{settingDialog.title != '送货账单详情'? scope.row.shbg_cate_name:scope.row.dego_cate_name}}
                                </template>
                            </el-table-column>
                            <el-table-column align="center" label="品牌" >
                                <template slot-scope="scope">
                                   {{settingDialog.title != '送货账单详情'? scope.row.shbg_bra_name:scope.row.dego_bra_name}}
                                </template>
                            </el-table-column>
                            <el-table-column v-if="settingDialog.title == '配送账单详情'" align="center" label="配送费" >
                                 <template slot-scope="scope">
                                   {{settingDialog.title != '送货账单详情'? scope.row.shbg_logistic_money:scope.row.dego_logistic_money}}
                                </template>
                            </el-table-column>
                            <el-table-column prop="shbg_goods_quantity" align="center"  v-if="settingDialog.title != '送货账单详情'" label="商品数量" />
                            <el-table-column prop="shbg_cash_quantity" align="center" v-if="settingDialog.title == '配送账单审核'"  label="兑换数量" />
                            <el-table-column prop="shbg_cash_money" align="center" v-if="settingDialog.title == '配送账单审核'"  label="兑换金额" />
                            <el-table-column prop="dego_actual_send_quantity" align="center" v-if="settingDialog.title == '送货账单详情'"  label="已送货" />
                            <el-table-column align="center"  label="操作" >
                                <template slot-scope="">
                                    <div>
                                        <!-- <el-button type="text" @click="goodsdeteli(scope.row)">商品详情</el-button> -->
                                    </div>
                                </template>
                            </el-table-column>
                        </el-table>
                        <div v-if="settingDialog.title == '配送账单详情'">
                            <div v-if="settingFrom.find_bill_goods.length>0" class="mainPageTurningBox">
                                <el-pagination :current-page="detailscurrentPage" :page-size="detailspageSize" :total="detailstotalNum" layout="total, prev, pager, next, jumper" background @current-change="detailshandleCurrentChange"/>
                            </div>
                        </div>
                    </el-row>
                </div>
                <div v-if="settingDialog.title == '原补货账单详情'">
                    <el-row>
                        <el-col :span="8">
                            <el-form-item  label="配送账单：">
                                {{settingFrom.find_bill.shbi_shipping_number}}
                            </el-form-item>
                        </el-col>
                        <el-col :span="8">
                             <el-form-item label="创建时间：">
                                {{settingFrom.find_bill.shbi_create_time}}
                            </el-form-item> 
                        </el-col>
                        <el-col :span="8">
                             <el-form-item label="商品总量：" >
                                {{settingFrom.find_bill.shbi_bill_amount}}
                            </el-form-item> 
                        </el-col>
                        <el-col :span="8">
                             <el-form-item label="原补货账单：" >
                                {{settingFrom.find_bill.shbi_sd_replenishment_number}}
                            </el-form-item> 
                        </el-col>
                        <el-col :span="8">
                             <el-form-item label="配送商：">
                                {{settingFrom.find_bill.shbi_chan_name}}
                            </el-form-item>
                        </el-col>
                        <el-col :span="24">
                             <el-form-item label="安装门店：" >
                                {{settingFrom.find_bill.shbi_shop_name}}
                            </el-form-item> 
                        </el-col>
                    </el-row>
                    <el-row>
                        <el-table border  :data="settingFrom.find_bill_goods" style="width: 100%">
                            <el-table-column align="center" label="商品名称" prop="rebg_goo_name" ></el-table-column>
                            <el-table-column align="center" label="商品编码" prop="rebg_goo_encode"></el-table-column>
                            <el-table-column align="center" label="品类" prop="rebg_cate_name" ></el-table-column>
                            <el-table-column align="center" label="品牌" prop="rebg_bra_name"></el-table-column>
                            <el-table-column align="center" label="配送费" prop="rebg_shipping_fee"></el-table-column>
                            <el-table-column prop="rebg_goods_quantity" align="center"  label="商品数量" />
                            <el-table-column key="rebg_replenishment_state" align="center" v-if="settingDialog.title != '送货账单详情'" label="能否补货" width="180">
                                <template slot-scope="scope">
                                    <span :class="scope.row.rebg_replenishment_state == 1 ? '':'red'">
                                        {{scope.row.rebg_replenishment_state == 1 ? '能':"否"}}
                                    </span>
                                </template>
                            </el-table-column>
                        </el-table>
                        <div v-if="settingFrom.find_bill_goods.length>0" class="mainPageTurningBox">
                            <el-pagination :current-page="detailscurrentPage" :page-size="detailspageSize" :total="detailstotalNum" layout="total, prev, pager, next, jumper" background @current-change="detailshandleCurrentChange"/>
                        </div>
                    </el-row>
                </div>
                <div v-if="settingDialog.title == '送货账单'">
                    <el-row>
						  <el-col :span="8">
                            <el-form-item label="创建时间：">
                                {{DeliveryForm.shbi_create_time}}
                            </el-form-item>                            
                        </el-col>
                        <el-col :span="8">
                            <el-form-item label="配送账单：">
                                {{DeliveryForm.shbi_shipping_number}}
                            </el-form-item>                            
                        </el-col>
                        <el-col :span="8">
                             <el-form-item label="配送商：">
                                {{DeliveryForm.shbi_chan_name || '无'}}
                            </el-form-item> 
                        </el-col>
                        <el-col :span="6">
                             <el-form-item label="安装门店：">
                                {{DeliveryForm.shbi_shop_name || '无'}}
                            </el-form-item> 
                        </el-col>
                        <el-col :span="6">
                             <el-form-item label="补货进度：">
                                {{DeliveryForm.shbi_replenish_state == 1?'未补':DeliveryForm.shbi_replenish_state == 2?'部分':'全部'}}
                            </el-form-item> 
                        </el-col>
                        <el-col :span="6">
                             <el-form-item label="商品总量：">
                                {{DeliveryForm.shbi_bill_amount}}
                            </el-form-item> 
                        </el-col>
                        <el-col :span="6">
                             <el-form-item label="未补货：">
                                {{DeliveryForm.shbi_no_replenishment}}
                            </el-form-item> 
                        </el-col>
                         <el-col :span="6">
                             <el-form-item label="已送货：">
                                {{DeliveryForm.shbi_delivery_quantity}}
                            </el-form-item> 
                        </el-col>
                         <el-col :span="6">
                             <el-form-item label="合计配送费：">
                                {{DeliveryForm.shbi_logistic_total_money}}
                            </el-form-item> 
                        </el-col>
                         <el-col :span="6">
                             <el-form-item label="状态：">
                                {{DeliveryForm.shbi_state == 1?'待审核':DeliveryForm.shbi_state == 2?'未完成':DeliveryForm.shbi_state == 3 ? '已完成' : '已驳回'}}
                            </el-form-item> 
                        </el-col>
                    </el-row>
                    <el-row class="mainContentItemBox" >
                        <div class="mainHeaderTitleBox">
                            <div class="titleNameBox">信息筛选</div>
                            <div class="buttonBox">
								<el-button @click="addDeliverytBtn" v-if="btnShow.addDeliverytBtn">新增送货单</el-button>
							</div>
                        </div>
                        <el-form ref="dialogformlist" :model="dialogformlist" size="medium" label-width="100px" class="mainSearchItemBox">
                            <el-row>
                                <el-col :span="6">
                                    <el-form-item label="送货单:" prop="dere_number">
                                        <el-input v-model="dialogformlist.dere_number" placeholder="请输入送货单" clearable  class="mainIptSelBox"/>
                                    </el-form-item>
                                </el-col>
                                
                                <el-col :span="6">
                                    <el-form-item label="状态:" prop="dere_state">
                                        <el-select v-model="dialogformlist.dere_state">
                                            <el-option value="1" label="未发货"></el-option>
                                            <el-option value="4" label="已撤销"></el-option>
                                            <el-option value="3" label="已完成"></el-option>
                                            <el-option value="2" label="待收货"></el-option>
                                        </el-select>
                                    </el-form-item>
                                </el-col>
                                <el-col :span="7">
                                    <el-form-item label="创建时间:" prop="Time">
                                        <el-date-picker v-model="dialogformlist.Time" type="daterange" range-separator="至" start-placeholder="开始日期" end-placeholder="结束日期" value-format="yyyy-MM-dd"  class="mainIptSelBox"></el-date-picker>
                                    </el-form-item>
                                </el-col>
                                <el-col :span="5">
                                    <el-button type="primary" @click="dialogsearchList('dialogformlist')">搜&nbsp;&nbsp;索</el-button>
                                    <el-button @click="resetForm('dialogformlist')">重&nbsp;&nbsp;置</el-button>
                                </el-col>
                            </el-row>
                        </el-form>
                    </el-row>
                    <el-row>
                        <el-table border v-if="settingDialog.title == '送货账单'"  :data="diatabledata" style="width: 100%">
                            <el-table-column prop="dere_create_time" align="center" label="送货时间" />
                            <el-table-column prop="dere_number" align="center" label="送货单" />
                            <el-table-column prop="dere_logistic_total_money" align="center" label="配送费" />
                            <el-table-column prop="dere_plan_send_amount" align="center" label="送货量" />
                            <el-table-column prop="dere_actual_send_amount" align="center" label="签收量" />
                            <el-table-column prop="dere_remark" align="center" label="备注" />
                            <el-table-column align="center" label="状态"  key="dere_state">
                                <template slot-scope="scope">
                                    {{scope.row.dere_state == 1?"未发货":scope.row.dere_state == 2?'待收货': scope.row.dere_state == 3 ? '已完成' :'已撤销'}}
                                </template>
                            </el-table-column>
                            <el-table-column align="center"  label="操作" >
                                <template slot-scope="scope">
                                    <div class="mainOperationBtnBox">
										<el-button  v-if="btnShow.DeliveryRemarksBtn" @click="RemarksBtn(scope.row,2)">送货备注</el-button>
                                        <el-button type="primary" v-if="btnShow.DeliverydetailsBtn" @click="Deliverydeteli(scope.row)">送货详情</el-button>
                                         <el-button class="btn-delete" v-if="btnShow.DeliveryRevokeBtn" @click="DeliveryRevokeBtn(scope.row)">送货撤销</el-button>
                                    </div>
                                </template>
                            </el-table-column>
                        </el-table>
                        <div v-if="diatabledata.length>0" class="mainPageTurningBox">
                            <el-pagination :current-page="diacurrentPage" :page-size="diapageSize" :total="diatotalNum" layout="total, prev, pager, next, jumper" background @current-change="diahandleCurrentChange"/>
                        </div>
                    </el-row>
                </div>
				<div v-if="settingDialog.title == '新增送货单'">
                     <el-row>
						  <el-col :span="8">
                            <el-form-item label="配送账单：">
                                {{addDeliveryForm.find_bill.shbi_shipping_number}}
                            </el-form-item>                            
                        </el-col>
                        <el-col :span="8">
                            <el-form-item label="创建时间：">
                                {{addDeliveryForm.find_bill.shbi_create_time}}
                            </el-form-item>                            
                        </el-col>
                        <el-col :span="8">
                             <el-form-item label="原补货账单：">
                                {{addDeliveryForm.find_bill.shbi_sd_replenishment_number || '无'}}
                            </el-form-item> 
                        </el-col>
                        <el-col :span="6">
                             <el-form-item label="商品总量：">
                                {{addDeliveryForm.find_bill.shbi_bill_amount}}
                            </el-form-item> 
                        </el-col>
                        <el-col :span="6">
                             <el-form-item label="配送商：">
                                {{addDeliveryForm.find_bill.shbi_chan_name||'无'}}
                            </el-form-item> 
                        </el-col>
                        <el-col :span="6">
                             <el-form-item label="收货对象：">
                                {{addDeliveryForm.find_bill.shbi_shop_name}}
                            </el-form-item> 
                        </el-col>
                        <el-col :span="6">
                             <el-form-item label="未补货：">
                                {{addDeliveryForm.find_bill.shbi_no_replenishment}}
                            </el-form-item> 
                        </el-col>
                         <el-col :span="6">
                             <el-form-item label="本次送货：">
                                {{addDeliveryForm.find_bill.shbi_delivery_order_quantity}}
                            </el-form-item> 
                        </el-col>
                         <el-col :span="6">
                             <el-form-item label="物流费：">
                                 <el-input placeholder="请输入物流费" @blur="/(^[1-9]\d*(\.\d{1,2})?$)|(^0(\.\d{1,2})?$)/.test(addDeliveryForm.find_bill.shbi_logistic_total_money) ? '' : addDeliveryForm.find_bill.shbi_logistic_total_money = ''" v-model="addDeliveryForm.find_bill.shbi_logistic_total_money"></el-input>
                            </el-form-item> 
                        </el-col>
                    </el-row>
                    <el-row class="mainContentItemBox" >
                        <div class="mainHeaderTitleBox">
                            <div class="titleNameBox">商品信息</div>
                            <div class="buttonBox">
							</div>
                        </div>
                    </el-row>
                     <el-row>
                        <el-table border v-if="settingDialog.title == '新增送货单'" :data="addDeliveryForm.find_bill_goods" style="width: 100%">
                            <el-table-column prop="shbg_goo_name" align="center" label="商品名称" />
                            <el-table-column prop="shbg_goo_encode" align="center" label="商品编号" />
                            <el-table-column prop="shbg_bra_name" align="center" label="品牌" />
                            <el-table-column prop="shbg_bra_name" align="center" label="品类" />
                            <el-table-column prop="shbg_goods_quantity" align="center" label="送货量" />
                            <el-table-column align="center" key="quantity" label="准备送货量" >
                                <template slot-scope="scope">
                                    <div>
                                        <el-input align='center' v-model="scope.row.quantity" @blur="Numberchange(scope.row,scope.$index,$event)" placeholder="请输入准备送货量"></el-input>
                                    </div>
                                </template>
                            </el-table-column>

                        </el-table>
                        
                    </el-row>
				</div>
            </el-form>
            <span slot="footer" v-if="settingDialog.title != '配送账单审核' && settingDialog.title != '配送账单详情' && settingDialog.title != '送货账单' && settingDialog.title !=  '送货账单详情'&& settingDialog.title != '原补货账单详情'">
                <el-button @click="settingDialog.show = false">取 消</el-button>
				<el-button type="primary" @click="SubmitBtn('settingFrom')">提 交</el-button>
            </span>
            <span slot="footer" v-if="settingDialog.title == '配送账单审核'">
                <el-button @click="auditBtn(4)" type="danger">驳 回</el-button>
                <el-button @click="auditBtn(2)" type="primary">同 意</el-button>
            </span>
        </el-dialog>
    
    </div>
</template>
<script>
import { errorStatus } from '@/utils/index'
import {getDistributors, getShops } from '@/api/commonAction'
import {
	ShippingBillsindex, ShippingBillsremark, ShippingBillsaudit, ShippingBillsexport, ShippingBillsdeliveryList, ShippingBillsinfo, 
    ShippingBillsdeliveryDetails, ShippingBillsdeliveryRemark, ShippingBillsdeliveryRevocation, ShippingBillsimport, ShippingBillsdeliveryAdd,
    replensBillinfo
	
} from '@/api/replenishment'
export default {
    data(){
        return {
            listData:[],
            diatabledata:[],
            btnShow:{},
            channelList:[],//配送商List
            StoreList:[],//安装门店List
            shbi_state:'',//账单状态
            goodsDetailData:{},//商品详情
            //新增送货单信息
            addDeliveryForm:{
                find_bill:{},
                find_bill_goods:[],
            },
            // 商品详情
			goodsDetailShow:{
				title:'商品详情',
				show:false,
				width:'560px',
			},
            baseUrl:process.env.BASE_API.replace("/index.php/api", "/"),
            formList:{
                shbi_replenish_state:"",
                shbi_shipping_number:"",
                Time:"",
                shbi_chan_id:"",
				shbi_shop_id:"",
				shbi_duty_state:"",
            },
            dialogformlist:{
                Time:"",
                dere_number:"",
                dere_state:"",
            },
            settingDialog:{
                show:false,
                title:"",
                width:'800px',
            },
            settingFrom:{
                shbi_id:"",
                shbi_sd_bill_id:"",
                shbi_remark:"",
                find_bill:{},
                find_bill_goods:[],
            },
            formRules:{
                shbi_remark:[
                    { required: true, message: '请输入备注', trigger: 'blur' }
				],
				
            },
            DeliveryForm:{},
            Deliverytabeldata:[],
            // deliverydeteli:{},
			currentPage: 1,//当前页码
			pageSize: null,//每页多少条
            totalNum: null,//总共多少条
            // 送货单分页
			diacurrentPage: 1,//送货单当前页码
			diapageSize: null,//送货单每页多少条
            diatotalNum: null,//送货单总共多少条
            // 详情分页
            detailscurrentPage: 1,//送货单当前页码
			detailspageSize: null,//送货单每页多少条
            detailstotalNum: null,//送货单总共多少条
        }
    },
    created(){
        this.getPageInfo();
    },
    methods:{
        // 获取列表
		getPageInfo() {
			const loading = this.$loading({
				lock: true,
				text: 'Loading',
				spinner: 'el-icon-loading',
				background: 'rgba(0, 0, 0, 0.7)'
			})
            const data = {...this.formList};
            if(this.formList.Time.length != 0){
                data.start_time = this.formList.Time[0];
                data.end_time = this.formList.Time[1];
            }
            data.page = this.currentPage;
            data.shbi_state = this.shbi_state;
			data.pri_id = this.$route.meta.pri_id;
			ShippingBillsindex(data).then(response => {
				const dataRep = response.data
				if (errorStatus(dataRep)) {
					this.listData = dataRep.data.data;
					for(let i in this.listData){
						for(let j in dataRep.data.find_chan){
							if(this.listData[i].shbi_chan_id ==  dataRep.data.find_chan[j].chan_id){
                                this.listData[i].shbi_chan_name = dataRep.data.find_chan[j].chan_unit_name;
							}
                        }
                        for(let j in dataRep.data.find_shop){
							if(this.listData[i].shbi_shop_id ==  dataRep.data.find_shop[j].chan_id){
                                this.listData[i].shbi_shop_name = dataRep.data.find_shop[j].chan_unit_name;
							}
						}
                    }
                    
					this.find_chan = dataRep.data.find_chan
					this.currentPage = dataRep.data.current_page
					this.pageSize = dataRep.data.current_number
					this.totalNum = dataRep.data.total
					// 操作按钮
					const btnList = dataRep.list_button;
					for (const i in btnList) {
						if (btnList[i].pri_method_name === '备注') {
							this.btnShow.RemarksBtn = true
						} else if (btnList[i].pri_method_name === '送货单备注') {
							this.btnShow.DeliveryRemarksBtn = true
						} else if (btnList[i].pri_method_name === '审核') {
							this.btnShow.toExamineBtn = true
						} else  if (btnList[i].pri_method_name === '配送账单详情') {
							this.btnShow.detailsBtn = true
						} else if (btnList[i].pri_method_name === '配送账单导出') {
							this.btnShow.exportBtn = true
						} else if (btnList[i].pri_method_name === '送货单列表') {
                            this.btnShow.DeliveryBtn = true
                        } else if (btnList[i].pri_method_name === '送货单详情') {
							this.btnShow.DeliverydetailsBtn = true
						} else if (btnList[i].pri_method_name === '送货单撤销') {
							this.btnShow.DeliveryRevokeBtn = true
						} else if (btnList[i].pri_method_name === '导入配送账单') {
							this.btnShow.DistributionImportBtn = true
						} else if (btnList[i].pri_method_name === '新增送货单') {
							this.btnShow.addDeliverytBtn = true
                        } else if (btnList[i].pri_method_name === '原补货账单详情') {
							this.btnShow.primaryreplenishbillBtn = true
                        }
                        
						
					}
				}
				loading.close()
			})
			.catch(err => {
				console.log(err)
				loading.close()
				this.$message.error('请求失败!')
				// console.log("获取列表err", err);
			})
        },
        resetForm(formName){
            this.$refs[formName].resetFields()
        },
        primaryreplenishbillBtn(row){
            const loading = this.$loading({
				lock: true,
				text: 'Loading',
				spinner: 'el-icon-loading',
				background: 'rgba(0, 0, 0, 0.7)'
			})
            this.settingDialog.title = '原补货账单详情';
            this.settingDialog.width = '800px';
            if(row !=undefined){
                this.settingFrom.shbi_sd_bill_id = row.shbi_sd_bill_id
            }
            const datadd = {
                rebi_id:this.settingFrom.shbi_sd_bill_id,
                type:1,
                page:this.detailscurrentPage
            }
            replensBillinfo(datadd).then(success=>{
                loading.close();
                if(success.data.code == 200){
                    if(row != undefined){
                        this.settingFrom.find_bill = {...row};
                        this.settingFrom.find_bill.rebi_chan_name = row.shbi_chan_name;
                    }
                    this.settingFrom.find_bill_goods = success.data.data.data;
                    this.settingDialog.show = true;
                   
                    this.detailscurrentPage = success.data.data.current_page
					this.detailspageSize = success.data.data.current_number
					this.detailstotalNum = success.data.data.total
                }else{
                    this.$message.error(success.data.data);
                }
            }).catch(err=>{
                loading.close();
                this.$message.error('审核信息获取失败！请联系管理员')
            })
        },
        // 准备送货量验证
        Numberchange(row,index,event){
            if(row.quantity == 0){
                return false
            }else if((!/^([1-9]\d*|0)(\.\d*[1-9])?$/.exec(row.quantity))){
                this.addDeliveryForm.find_bill_goods[index].quantity = this.addDeliveryForm.find_bill_goods[index].shbg_goods_quantity;
                event.target.value =  this.addDeliveryForm.find_bill_goods[index].shbg_goods_quantity;
                this.$forceUpdate()
            }else if(row.quantity >= row.shbg_goods_quantity){
                this.addDeliveryForm.find_bill_goods[index].quantity = this.addDeliveryForm.find_bill_goods[index].shbg_goods_quantity;
                event.target.value =  this.addDeliveryForm.find_bill_goods[index].shbg_goods_quantity;
                this.$forceUpdate()
            }
        },
		// 弹窗关闭
        closedialog(formName){            
            if(this.settingDialog.title == '送货账单'){
                this.DeliveryForm = {};
                this.$refs['dialogformlist'].resetFields();
                this.diatabledata = [];
                
            }else if(this.settingDialog.title == '配送账单审核'|| this.settingDialog.title == '配送账单详情'|| this.settingDialog.title ==  '送货账单详情'){
                this.$refs['settingFrom'].resetFields();
                if(this.settingDialog.title == '送货账单详情'){
                    this.settingDialog.show = true;
                    this.settingDialog.width = '1000px';
                    this.settingDialog.title = '送货账单';
                    // this.deliverydeteli = {};
                    // this.settingFrom.find_bill = {...this.DeliveryForm}
                    // this.diatabledata = this.Deliverytabeldata;
                    // this.Deliverytabeldata = [];
                }
            }else if(this.settingDialog.title == '送货备注') {
				this.DeliveryBtn(this.DeliveryForm);
				// this.settingDialog.show = true;
				// this.settingDialog.width = '1000px';
				// this.settingDialog.title = '送货账单';
				// this.settingFrom.find_bill = {...this.DeliveryForm}
				// this.settingFrom.find_bill_goods = this.Deliverytabeldata;
			}else if(this.settingDialog.title == '配送单导入'){
				document.getElementById('filexcel').value = '';
			} else if (this.settingDialog.title == '新增送货单'){
                this.addDeliveryForm = {};
                this.settingDialog.show = true;
                this.settingDialog.width = '1000px';
                this.settingDialog.title = '送货账单';
                this.diatabledata = [];
                // this.deliverydeteli = {};
                // this.settingFrom.find_bill = {...this.DeliveryForm}
                this.diatabledata = this.Deliverytabeldata;
                // this.Deliverytabeldata = [];
                // console.log(this.settingFrom)
            } else{
                this.$refs[formName].resetFields()
            }
            this.detailscurrentPage = 1;
            this.detailspageSize = null;
            this.detailstotalNum = null;
		},
		// 上传excel文件
		uploadfile(e){			
			this.settingFrom.file = e.target.files[0];
		},
        // 商品详情
        // viewGoodsBtn(val){
		// 	const data = {};
		// 	data.goo_id = val;
		// 	infoGoods(data).then(response => {
		// 		const dataRep = response.data
		// 		this.goodsDetailData = {};
		// 		if (errorStatus(dataRep)) {
		// 			this.goodsDetailData = dataRep.data;
		// 			this.goodsDetailData.goaf_attribute = eval(dataRep.data.goaf_attribute);
		// 			this.goodsDetailShow.show = true;
		// 		}
		// 	})
		// 	.catch(Error => {
		// 		this.$message.error('请求失败!')
		// 	})
        // },
        // 新增送货单
        addDeliverytBtn(){
            const datadd ={
                type:1,
                shbi_id:this.DeliveryForm.shbi_id
            }
            ShippingBillsdeliveryAdd(datadd).then(success=>{
                if(success.data.code == 200){
                    this.addDeliveryForm.find_bill = {...this.DeliveryForm};
                    this.addDeliveryForm.find_bill_goods = success.data.data;
                    for(let i=0;i<success.data.data.length;i++){
                        this.addDeliveryForm.find_bill_goods[i].quantity = success.data.data[i].shbg_goods_quantity
                    }
                    
                    this.settingDialog.title = '新增送货单';
                    this.settingDialog.width = '800px';
                }else{
                    this.$message.error(success.data.data)
                }
            }).catch(err=>{
                console.log(err)
                this.$message.error('新增信息获取失败！')
            })
        },
         // 获取配送商渠道
		getDistributors(query,type,Id) {
			const data = {}
			data.app_role = type
			if(query){
				data.search_data =query
			}
			getDistributors(data)
			.then(response => {
				console.log(response.data)
				if(errorStatus(response.data)){
					this.channelList = response.data.data.data
				}
			})
        },
        // 安装门店
		getShops(query,type,Id) {
			const data = {}
			data.app_role = type
			if(query){
				data.search_data =query
			}
			getShops(data)
			.then(response => {
				console.log(response.data)
				if(errorStatus(response.data)){
					this.StoreList = response.data.data.data
				}
			})
		},
        getdatastate(state){
            this.shbi_state = state;
            this.getPageInfo();
		},
		// 配送单导入
		DistributionImportBtn(){
			this.settingDialog.title = '配送单导入';
			this.settingDialog.show = true;
			this.settingDialog.width = '600px';
		},
        // 审核提交
        auditBtn(type){
            const datadd = {
                type:2,
                shbi_state:type,
                shbi_id:this.settingFrom.shbi_id,
            }
            ShippingBillsaudit(datadd).then(success=>{
                if(success.data.code== 200){
                    this.$message.success(success.data.data);
                    this.getPageInfo();
                    this.settingDialog.show = false;
                }else{
                    this.$message.error(success.data.data);
                }
            }).catch(err=>{
                this.$message.error('操作失败！请联系管理员')
            })
        },
		// 重置
		resetForm(formName) {
            this.$refs[formName].resetFields()
            if(formName == 'formList'){
                this.shbi_state = '';
            }
		},
        // 搜索
        searchList(){
            this.currentPage = 1;
            this.getPageInfo();
        },
        // 弹框数据搜索
        dialogsearchList(){
            // this.$message.
            // 
           this.DeliveryBtn(this.DeliveryForm);
        },
        // 翻页
        handleCurrentChange(e){
            this.currentPage = e;
            this.getPageInfo()
        },
        // 送货单翻页
        diahandleCurrentChange(e){
            this.diacurrentPage = e;
            this.DeliveryBtn(this.DeliveryForm);
        },
        // 详情分页
        detailshandleCurrentChange(e){
            this.detailscurrentPage = e;
            if(this.settingDialog.title == '原补货账单详情'){
                this.primaryreplenishbillBtn()
            }else if(this.settingDialog.title == '配送账单详情'){
                this.detailsBtn()
            }
        },
        //备注
        RemarksBtn(row,type){
			if(type == 1){
				this.settingDialog.title = '账单备注';
            	this.settingFrom.shbi_id = row.shbi_id;
			}else{
				this.settingDialog.title = '送货备注';
            	this.settingFrom.shbi_id = row.dere_id;
			}
            this.settingDialog.width = '600px';
            this.settingDialog.show = true;
        },
        // 审核
        toExamineBtn(row){
            const loading = this.$loading({
				lock: true,
				text: 'Loading',
				spinner: 'el-icon-loading',
				background: 'rgba(0, 0, 0, 0.7)'
			})
            this.settingDialog.title = '配送账单审核';
            this.settingDialog.width = '800px';
            this.settingFrom.shbi_id = row.shbi_id;
            
            const datadd = {
                shbi_id:row.shbi_id,
                type:1
            }
            ShippingBillsaudit(datadd).then(success=>{
                loading.close();
                if(success.data.code == 200){
                    this.settingFrom.find_bill = success.data.data.find_bill;
                    this.settingFrom.find_bill.shbi_shop_name = success.data.data.find_bill.shop_name;
                    this.settingFrom.find_bill.shbi_chan_name = success.data.data.find_bill.chan_name;
                    this.settingFrom.find_bill_goods = success.data.data.find_bill_goods;
                    console.log(this.settingFrom)
                    this.settingDialog.show = true;
                }else{
                    this.$message.error(success.data.data);
                }
            }).catch(err=>{
				loading.close();
				console.log(err)
                this.$message.error('审核信息获取失败！请联系管理员')
            })
        },
       
        // 账单详情
        detailsBtn(row){
            const loading = this.$loading({
				lock: true,
				text: 'Loading',
				spinner: 'el-icon-loading',
				background: 'rgba(0, 0, 0, 0.7)'
			})
            this.settingDialog.title = '配送账单详情';
            this.settingDialog.width = '800px';
            if(row != undefined){
                this.settingFrom.shbi_id = row.shbi_id;
            }
            
            const datadd = {
                shbi_id: this.settingFrom.shbi_id ,
                type:1,
                page:this.detailscurrentPage
            }
            ShippingBillsinfo(datadd).then(success=>{
                loading.close();
                if(success.data.code == 200){
                    if(row != undefined){
                        this.settingFrom.find_bill = {...row};
                        this.settingFrom.find_bill.shbi_chan_name = row.shbi_chan_name;
                    }
                    this.settingFrom.find_bill_goods = success.data.data.data;
                    this.settingDialog.show = true;

                    this.detailscurrentPage = success.data.data.current_page
					this.detailspageSize = success.data.data.current_number
					this.detailstotalNum = success.data.data.total
                }else{
                    this.$message.error(success.data.data);
                }
            }).catch(err=>{
                loading.close();
                console.log(err)
                this.$message.error('审核信息获取失败！请联系管理员')
            })
        },
        // 送货详情
        Deliverydeteli(row){
             const loading = this.$loading({
				lock: true,
				text: 'Loading',
				spinner: 'el-icon-loading',
				background: 'rgba(0, 0, 0, 0.7)'
			})
            this.settingDialog.title = '送货账单详情';
            this.settingDialog.width = '800px';
            // this.deliverydeteli = {...row};
            
            const datadd = {
				dere_id:row.dere_id,
				shbi_id:this.DeliveryForm.shbi_id
            }
            ShippingBillsdeliveryDetails(datadd).then(success=>{
                loading.close();
                if(success.data.code == 200){
                    this.settingFrom.find_bill = {...row};
                    // console.log(row,';;;')
                    this.settingFrom.find_bill.shbi_chan_name = this.DeliveryForm.shbi_chan_name;
                    this.settingFrom.find_bill_goods = success.data.data;
                    // this.settingDialog.show = true;
                    // console.log(this.settingFrom,';;;;000')
                }else{
                    this.$message.error(success.data.data);
                }
            }).catch(err=>{
                loading.close();
                console.log(err)
                this.$message.error('审核信息获取失败！请联系管理员')
            })
        },
        // Deliveryexport
        // 送货账单
        DeliveryBtn(row){
            const loading = this.$loading({
				lock: true,
				text: 'Loading',
				spinner: 'el-icon-loading',
				background: 'rgba(0, 0, 0, 0.7)'
			})
            this.settingDialog.title = '送货账单';
            this.settingDialog.width = '1000px';
            this.DeliveryForm = {...row};
            const datadd = {...this.dialogformlist};
            if(this.dialogformlist.Time.length == 2){
                datadd.start_time = this.dialogformlist.Time[0];
                datadd.end_time = this.dialogformlist.Time[1];
            }
            datadd.shbi_id = row.shbi_id;
			datadd.page = this.diacurrentPage;
			datadd.pri_id = this.$route.meta.pri_id;
            ShippingBillsdeliveryList(datadd).then(success=>{
                loading.close();
                if(success.data.code == 200){
                    this.diatabledata = success.data.data.data
                    this.Deliverytabeldata = success.data.data.data
                    this.diacurrentPage = success.data.data.current_page
					this.diapageSize = success.data.data.current_number
                    this.diatotalNum = success.data.data.total
                    this.settingDialog.show = true;
                }else{
                    this.diatabledata = [];
                    this.$message.error(success.data.data);
                }
            }).catch(err=>{
                loading.close();
                this.$message.error('送货账单获取失败！')
                this.diatabledata = []
            })
        },
     
        // 导出
        exportBtn(row){
            this.$confirm('确定导出此条配送账单吗？ 是否继续', '提示', {
                confirmButtonText: '确定',
                cancelButtonText: '取消',
                type: 'warning'
            }).then(() => {
                const datadd ={
                    shbi_id:row.shbi_id
                }
                ShippingBillsexport(datadd).then(success=>{
                    if(success.data.code == 200){
                        this.$message.success('导出成功！')
                        // window.location.href = 'http://gtest.bluearp.com/'+success.data.data;
                        window.open('http://gtest.bluearp.com/'+success.data.data);  
                    }else{
                        this.$message.error(success.data.data)
                    }
                }).catch(err=>{
                    this.$message.error('配送账单导出失败！请联系管理员')
                })
            }).catch(err=>{
                this.$message.warning('已取消配送账单导出')
            })
            
		},
		// 送货撤销
		DeliveryRevokeBtn(row){
			this.$confirm('确定撤销此条送货单吗？ 是否继续', '提示', {
                confirmButtonText: '确定',
                cancelButtonText: '取消',
                type: 'warning'
            }).then(() => {
				const datadd ={
					shbi_id:this.DeliveryForm.shbi_id,
					dere_id:row.dere_id
                }
                ShippingBillsdeliveryRevocation(datadd).then(success=>{
					console.log(success)
                    if(success.data.code == 200){
						this.$message.success(success.data.data);
						this.DeliveryBtn(this.DeliveryForm);
                    }else{
                        this.$message.error(success.data.data)
                    }
                }).catch(err=>{
					console.log(err)
                    this.$message.error('送货撤销失败！请联系管理员')
                })
			}).catch(err=>{
                this.$message.warning('已取消送货撤销')
			})
		},
		// 提交
        SubmitBtn(formName){
            this.$refs[formName].validate((valid) => {
				
                if(valid){
                    if(this.settingDialog.title == '账单备注'){
                        const datadd ={
                            shbi_remark:this.settingFrom.shbi_remark,
                            shbi_id:this.settingFrom.shbi_id
                        }
                        ShippingBillsremark(datadd).then(success=>{
                            if(success.data.code == 200){
                                this.$message.success(success.data.data);
                                this.getPageInfo();
                                this.settingDialog.show = false;
                            }else{
                                this.$message.error(success.data.data)
                            }
                        }).catch(err=>{
                            this.$message.error('配送备注失败！请联系管理员')
                        })
                    } else if (this.settingDialog.title == '送货备注') {
						const datadd ={
                            dere_remark:this.settingFrom.shbi_remark,
                            dere_id:this.settingFrom.shbi_id
                        }
                        ShippingBillsdeliveryRemark(datadd).then(success=>{
                            if(success.data.code == 200){
                                this.$message.success(success.data.data);
                                this.getPageInfo();
                                this.settingDialog.show = false;
                            }else{
                                this.$message.error(success.data.data)
                            }
                        }).catch(err=>{
                            this.$message.error('配送备注失败！请联系管理员')
                        })
					} else if(this.settingDialog.title == '配送单导入'){
						if(this.settingFrom.file == ''){
							this.$message.warning('请选择上传文件');
							return false;
						}
						let datadd = new FormData();
						datadd.append('file',this.settingFrom.file);
						datadd.append('api_token',localStorage.getItem('Admin-Token'));
						datadd.append('pri_id',this.$route.meta.pri_id);
						ShippingBillsimport(datadd).then(success=>{
							if(success.data.code ==200){
								this.$message.success(success.data.data);
								this.settingDialog.show = false;
							}else{
								this.$message.error(success.data.data);
							}
						}).catch(err=>{
							
							this.$message.error('导入失败！')
						})
					} else if(this.settingDialog.title == '新增送货单'){
                        if(this.addDeliveryForm.find_bill.shbi_logistic_total_money == ""){
                            this.$message.warning('请输入配送费');
                            return false;
                        }
                        let quantity = [];
                        for(let i=0;i<this.addDeliveryForm.find_bill_goods.length;i++){
                            quantity.push(this.addDeliveryForm.find_bill_goods[i].quantity)
                        }
                        const datadd ={
                            shbi_id:this.DeliveryForm.shbi_id,
                            type:2,
                            dego_logistic_money:this.addDeliveryForm.find_bill.shbi_logistic_total_money,
                            quantity,
                        }
                        ShippingBillsdeliveryAdd(datadd).then(success=>{
                            if(success.data.code==200){
                                this.$message.success(success.data.data);
                                this.DeliveryBtn(this.DeliveryForm);
                            }else{
                                this.$message.error(success.data.data)
                            }
                        }).catch(err=>{
                            this.$message.error('添加失败！')
                        })
                    }
                }
            })
        }

    }
}
</script>
<style scoped>
    .red{
        color: red
    }
  
    .h80{
        height: 80px;
    }
</style>
<style>
      .btnbom .el-button{
        margin-bottom: 10px;
    }
</style>