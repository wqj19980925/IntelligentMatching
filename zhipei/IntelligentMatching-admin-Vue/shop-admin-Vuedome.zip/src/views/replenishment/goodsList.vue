<template>
	<div>
		<!-- 信息筛选 -->
		<el-row class="mainContentItemBox">
			<div class="mainHeaderTitleBox">
				<div class="titleNameBox">信息筛选</div>
				<div class="buttonBox"></div>
			</div>
			<el-form ref="formList" :model="formList" size="medium" label-width="100px" class="mainSearchItemBox">
				<el-row>
					
					<el-col :span="6">
						<el-form-item label="商品名称:" prop="rego_goo_name">
							<el-input v-model="formList.rego_goo_name" placeholder="请输入商品名称" clearable :maxlength="20" class="mainIptSelBox"/>
						</el-form-item>
					</el-col>
					<el-col :span="6">
						<el-form-item label="检索编号:" prop="rego_goo_encode">
							<el-input v-model="formList.rego_goo_encode" placeholder="请输入检索编号" clearable :maxlength="13" class="mainIptSelBox"/>
						</el-form-item>
					</el-col>
					<el-col :span="6">
						<el-form-item label="商品品类:" prop="rego_cate_name">
							<el-select v-model="formList.rego_cate_name" placeholder="请选择商品品类" @click.native="getCategoryDataBtn()" clearable filterable :multiple="false" remote :remote-method="getCategoryDataBtn" class="mainIptSelBox">
								<el-option v-for="item in classList" :key="item.cate_id" :label="item.cate_name" :value="item.cate_id" />
							</el-select>
						</el-form-item>
					</el-col>
					<el-col :span="6">
						<el-form-item label="商品品牌:" prop="rego_bra_name">
							<el-select v-model="formList.rego_bra_name" placeholder="请选择商品品牌" @click.native="getBrandDataBtn()" clearable filterable :multiple="false" remote :remote-method="getBrandDataBtn" class="mainIptSelBox">
								<el-option v-for="item in brandList" :key="item.bra_id" :label="item.bra_name" :value="item.bra_id" />
							</el-select>
						</el-form-item>
					</el-col>
				</el-row>
				<el-row type="flex" justify="end">
					<el-col :span="6" align="right">
						<el-button type="primary" @click="searchList('formList')">搜&nbsp;&nbsp;索</el-button>
						<el-button @click="resetForm('formList')">重&nbsp;&nbsp;置</el-button>
					</el-col>
				</el-row>
			</el-form>
		</el-row>
		<!-- 列表 -->
		<el-row class="mainContentItemBox">
			<div class="mainHeaderTitleBox">
				<div class="titleNameBox">补货商品列表</div>
				<div class="buttonBox"></div>
			</div>
			<el-table :data="listData" width="100%" @selection-change="handleSelectionChange">
				<el-table-column type="selection" width="55"/>
				<el-table-column label="商品图片" prop="" min-width align="center">
					<template slot-scope="scope">
						<div class="mainGoddsImgBox" v-if="scope.row.regd_small_img"><img :src="baseUrl+scope.row.regd_small_img" /></div>
						<img width="100px" height="100px" src="@/assets/img/goods_img_none.jpg" v-else />
					</template>
				</el-table-column>
				<el-table-column label="商品名称" prop="rego_goo_name" align="center"/>
				<el-table-column label="商品编号" prop="rego_goo_encode" align="center"/>
				<el-table-column label="品类" prop="rego_cate_name" align="center"/>
				<el-table-column label="品牌" prop="rego_bra_name" align="center"/>
				<el-table-column label="安装费" prop="" align="center">
					<template slot-scope="scope">
						{{ scope.row.regd_install_fee/100 }}
					</template>
				</el-table-column>
				<el-table-column label="质保费" prop="" align="center">
					<template slot-scope="scope">
						{{ scope.row.regd_warranty_fee/100 }}
					</template>
				</el-table-column>
				<el-table-column label="配送费" prop="" align="center">
					<template slot-scope="scope">
						{{ scope.row.regd_shipping_fee/100 }}
					</template>
				</el-table-column>
				<el-table-column label="操作" width="260" align="center">
					<template slot-scope="scope">
						<el-button type="primary" v-if="btnShow.editBtn" @click="editGoodsBtn(scope.row)">维护</el-button>
					</template>
				</el-table-column> 
			</el-table>
			<div v-if="listData.length>0" class="mainPageTurningBox">
				<el-pagination :current-page="currentPage" :page-size="pageSize" :total="totalNum" layout="total, prev, pager, next, jumper" background @current-change="handleCurrentChange"/>
			</div>
		</el-row>
		<!-- 维护 -->
		<el-dialog :visible.sync="maintainDialog.show" :title="maintainDialog.title" :close-on-click-modal="false" :width="maintainDialog.width" @close="resetForm('maintainFrom')">
			<el-form ref="maintainFrom" :model="maintainFrom"  :rules="formRules" label-width="90px">
				<el-row>
					<el-col :span="10">
						<div class="mainDetailGoodsImgBox">
							<img :src="baseUrl+maintainFrom.regd_original_img" alt="" v-if="maintainFrom.regd_original_img" />
							<img src="@/assets/img/goods_img_none.jpg" v-else />
						</div>
					</el-col>
					<el-col :span="14">
						<el-col :span="24">
							<el-form-item label="商品名称:" prop="" class="mainFormSeeInfoBox">
								{{ maintainFrom.rego_goo_name }}
							</el-form-item>
						</el-col>
						<el-col :span="24">
							<el-form-item label="检索编码:" prop="" class="mainFormSeeInfoBox">
								{{ maintainFrom.rego_goo_encode }}
							</el-form-item>
						</el-col>
						<el-col :span="24">
							<el-form-item label="配送费用:" prop="regd_shipping_fee">
								<el-input v-model="maintainFrom.regd_shipping_fee" placeholder="请输入配送费用" clearable :maxlength="20" @input="validatePriceBtn($event,1)" class="mainIptSelBox"/>
							</el-form-item>
						</el-col>
						<el-col :span="24">
							<el-form-item label="安装费用:" prop="regd_install_fee">
								<el-input v-model="maintainFrom.regd_install_fee" placeholder="请输入安装费用" clearable :maxlength="20" @input="validatePriceBtn($event,2)" class="mainIptSelBox"/>
							</el-form-item>
						</el-col>
						<el-col :span="24">
							<el-form-item label="质保费用:" prop="regd_warranty_fee">
								<el-input v-model="maintainFrom.regd_warranty_fee" placeholder="请输入质保费用" clearable :maxlength="20" @input="validatePriceBtn($event,3)" class="mainIptSelBox"/>
							</el-form-item>
						</el-col>
					</el-col>
				</el-row>
			</el-form>
			<span slot="footer">
				<el-button @click="maintainDialog.show = false">取 消</el-button>
				<el-button type="primary" @click="addSubmitBtn('maintainFrom')">提 交</el-button>
			</span>
		</el-dialog>
	</div>

</template>
<script>
import { relationGoodsList,relationVindicate } from '@/api/replenishment'
import { getBrandInfo,getCategoryInfo } from '@/api/commonAction'

import { validatePrice } from '@/utils/validate'
import { errorStatus } from '@/utils/index'
export default {
	name: 'ClassList',
	data() {
		const validatePri = (rule, value, callback) => {
			if (!validatePrice(value)) {
				return callback(new Error('请输入正确价格'))
			}else{
                callback()
            }
        }
		return {
			baseUrl:process.env.BASE_API.replace("/index.php/api", "/"),
			// 搜索参数
			formList: {
				rego_goo_name: '',
				rego_goo_encode: '',
				rego_cate_name: '',
				rego_bra_name: '',
			},
			formRules:{
				 regd_install_fee: [
                    { required: true, message: '请输入正确价格',validator:validatePri, trigger: 'blur' }
				],
				 regd_shipping_fee: [
                    { required: true, message: '请输入正确价格',validator:validatePri, trigger: 'blur' }
				],
				 regd_warranty_fee: [
                    { required: true, message: '请输入正确价格',validator:validatePri, trigger: 'blur' }
                ],
			},
			brandList:[],//商品品牌下拉菜单
			classList:[],//商品品类下拉菜单
			listData: [],//信息列表
			chosed: '',
			currentPage: 1,//当前页码
			pageSize: null,//每页多少条
			totalNum: null,//总共多少条
			// 维护弹窗
			maintainDialog: {
				title:'信息维护',
				show:false,
				width:'600px',
			},
			// 维护表单
			maintainFrom: {
				rego_id:'',
				rego_goo_name:'',
				rego_goo_encode:'',
				regd_shipping_fee:'',
				regd_install_fee:'',
				regd_warranty_fee:'',
			},
			// 按钮权限
			btnShow: {
				editBtn: false,
			},
		}
	},
	created() {
		// 页面加载时
		this.getPageInfo()
	},
	methods: {
		// 获取列表
		getPageInfo() {
			const loading = this.$loading({
				lock: true,
				text: 'Loading',
				spinner: 'el-icon-loading',
				background: 'rgba(0, 0, 0, 0.7)'
			})
			const data = this.formList;
			data.page = this.currentPage;
			data.pri_id = this.$route.meta.pri_id;
			relationGoodsList(data).then(response => {
				const dataRep = response.data
				if (errorStatus(dataRep)) {
					this.listData = dataRep.data.data;
					this.currentPage = dataRep.data.current_page
					this.pageSize = dataRep.data.current_number
					this.totalNum = dataRep.data.total
					const btnList = dataRep.list_button
					for (const i in btnList) {
						if (btnList[i].pri_method_name === '维护') {
							this.btnShow.editBtn = true
						}
					}
				}
				loading.close()
			})
			.catch(Error => {
				loading.close()
				this.$message.error('请求失败!')
				// console.log("获取列表err", err);
			})
		},
		// 搜索
		searchList(formName) {
			this.currentPage = 1
			this.getPageInfo()
		},
		// 重置
		resetForm(formName) {
			this.$refs[formName].resetFields()
		},
		// 选中状态
		handleSelectionChange(val) {
			this.chosed = val
		},
		// 页面--分页器
		handleCurrentChange(val) {
			// console.log(`当前页: ${val}`)
			this.currentPage = val
			this.getPageInfo()
		},
		// 获取品牌
		getBrandDataBtn(val) {
			const data = {};
			data.search_data = val;
			getBrandInfo(data).then(response => {
				const dataRep = response.data
				if (errorStatus(dataRep)) {
					this.brandList = dataRep.data.data;
				}
			});
		},
		// 获取品类
		getCategoryDataBtn(val) {
			const data = {};
			data.search_data = val;
			getCategoryInfo(data).then(response => {
				const dataRep = response.data
				if (errorStatus(dataRep)) {
					this.classList = dataRep.data.data;
				}
			});
		},
		// 维护 - 打开
		editGoodsBtn(val){
			this.maintainFrom.rego_id = val.rego_id;
			this.maintainFrom.regd_original_img = val.regd_original_img;
			this.maintainFrom.rego_goo_name = val.rego_goo_name;
			this.maintainFrom.rego_goo_encode = val.rego_goo_encode;
			this.maintainDialog.show = true;
		},
		// 维护 - 提交
		addSubmitBtn(formName){
			this.$refs[formName].validate((valid) => {
				if(valid){
					const data = this.maintainFrom;
					relationVindicate(data).then(response => {
						const dataRep = response.data
						if (errorStatus(dataRep)) {
							this.$message.success('信息维护成功！');
							this.getPageInfo();
							this.maintainDialog.show = false;
						}
					})
					.catch(Error => {
						loading.close()
						this.$message.error('请求失败!')
					})
				}
			})

			
		},
		// 价格正则验证
		validatePriceBtn(val,type){
			if(!validatePrice(val)){
				// 1配送费用  2安装费用  3质保费用
				if(type == 1){
					this.$nextTick(() => {
						this.maintainFrom.regd_shipping_fee = '';
					})
				}
				if(type == 2){
					this.$nextTick(() => {
						this.maintainFrom.regd_install_fee = '';
					})
				}
				if(type == 3){
					this.$nextTick(() => {
						this.maintainFrom.regd_warranty_fee = '';
					})
				}
			}
		},
	}
}
</script>
<style scoped >
/* 维护弹窗图片 */
.mainDetailGoodsImgBox{width:230px;height:230px;display:table-cell;vertical-align:middle;text-align:center;}
.mainDetailGoodsImgBox img{max-width:100%;max-height:100%;}
</style>
