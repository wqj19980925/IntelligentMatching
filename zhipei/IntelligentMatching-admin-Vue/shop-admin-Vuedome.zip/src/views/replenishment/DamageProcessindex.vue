<template>
    <div>
        <!-- 信息筛选 -->
		<el-row class="mainContentItemBox" >
			<div class="mainHeaderTitleBox">
				<div class="titleNameBox">信息筛选</div>
				<div class="buttonBox">
					<el-button v-if="btnShow.addListBtn" @click="addDamaged" type="primary">新增残损单</el-button>
				</div>
			</div>
			<el-form ref="formList" :model="formList" size="medium" label-width="100px" class="mainSearchItemBox">
				<el-row>
					<el-col :span="6">
						<el-form-item  label="申请单位:" prop="dadw_shop_id">
							<el-select v-model="formList.dadw_shop_id" placeholder="请选择申请单位" class="mainIptSelBox"  @click.native ="getDistributors('',1)" clearable filterable  :multiple="false" remote :remote-method="(query)=>{getDistributors(query,1)}">
								<el-option v-for="item in channelList" :key="item.chan_id" :label="item.chan_unit_name" :value="item.chan_id"/>
							</el-select>
						</el-form-item>
					</el-col>
                    <el-col :span="6">
                        <el-form-item label="残损单号:" prop="dadw_damaged_number">
							<el-input v-model="formList.dadw_damaged_number" class="mainIptSelBox" clearable placeholder="请输入残损单号" ></el-input>
						</el-form-item>
                    </el-col>
                     <el-col :span="6">
                        <el-form-item label="补货账单:" prop="dare_replenishment_bills_number">
							<el-input v-model="formList.dare_replenishment_bills_number" class="mainIptSelBox" clearable placeholder="请输入补货单号" ></el-input>
						</el-form-item>
                    </el-col>
					<el-col :span="6">
						<el-form-item label="补货方式:" prop="dare_replenishment_way">
							 <el-select v-model="formList.dare_replenishment_way" class="mainIptSelBox" placeholder="请选择补货职务"> 
                                <el-option value="2" label="单独补发"></el-option>
                                <el-option value="1" label="合并补发"></el-option>
                            </el-select>
						</el-form-item>
					</el-col>
					
					<el-col :span="6">
						<el-form-item label="处理结果:"  prop="dare_result">
                            <el-select v-model="formList.dare_result" class="mainIptSelBox" placeholder="请选择处理结果"> 
                                <el-option value="1" label="折现"></el-option>
                                <el-option value="2" label="退回"></el-option>
                            </el-select>
						</el-form-item>
					</el-col>
					<el-col :span="6">
						<el-form-item label="状态:" prop="shbi_replenish_state">
                            <el-select v-model="formList.shbi_replenish_state" class="mainIptSelBox" placeholder="请选择补货进度">
                                <el-option value="1" label="待审核"></el-option>
                                <el-option value="2" label="未完成"></el-option>
                                <el-option value="3" label="已完成"></el-option>
                                <el-option value="4" label="已驳回"></el-option>
                            </el-select>
						</el-form-item>
					</el-col>
					<el-col :span="6">
						<el-form-item label="申请时间:" prop="Time">
                            <el-date-picker v-model="formList.Time" type="daterange" class="mainIptSelBox" value-format="yyyy-MM-dd" range-separator="至" start-placeholder="开始日期" end-placeholder="结束日期" ></el-date-picker>
						</el-form-item>
					</el-col>
					<el-col :span="5">
						<el-button type="primary" @click="getPageInfo">搜&nbsp;&nbsp;索</el-button>
						<el-button @click="resetForm('formList')">重&nbsp;&nbsp;置</el-button>
					</el-col>
				</el-row>
			</el-form>
		</el-row>
        <!-- 列表 -->
		<el-row class="mainContentItemBox" >
			<div class="mainHeaderTitleBox">
				<div class="titleNameBox">残损列表</div>
				<div class="buttonBox"></div>
			</div>
			<el-table :data="listData" width="100%" >
				<el-table-column label="申请时间" width="100" prop="dare_create_time"  align="center"/>
				<el-table-column label="申报单位" width="120" prop="dare_shop_name" align="center"/>
				<el-table-column label="残损单号" width="120" prop="dare_number" align="center"></el-table-column>
				<el-table-column label="残损数量" width="100" prop="dare_spoiled_quantity" align="center"></el-table-column>
				<el-table-column label="处理结果" width="120" prop="dare_result" align="center">
					<template slot-scope="scope">
						{{scope.row.dare_result == 1?"折现":"退回"}}
					</template>
				</el-table-column>
				<el-table-column label="折现金额（分）" width="120" prop="dare_discount_amount"  align="center"/>
				<el-table-column label="实收数量" width="80" prop="dare_actual_quantity" class="red" align="center"/>
				<el-table-column label="补货方式" width="80" prop="shbi_no_replenishment" class="red" align="center">
					<template slot-scope="scope">
						{{scope.row.shbi_no_replenishment == 1?"单独补发":"合并补发"}}
					</template>
				</el-table-column>
				<el-table-column label="（残损）补货账单" width="150" prop="dare_replenishment_bills_number" align="center"/>
				<el-table-column label="备注" width="120" prop="dare_remark" align="center"></el-table-column>
				<el-table-column label="状态" width="80" prop="shbi_delivery_order_quantity" align="center">
					<template slot-scope="scope">
						{{scope.row.dare_state == 1?'待审核': scope.row.dare_state == 2?'未完成': scope.row.dare_state == 3?'已完成':'已驳回'}}
					</template>
				</el-table-column>
				<el-table-column label="操作"  fixed='right' width="200" align="center">
					<template slot-scope="scope" >
                        <div class="mainOperationBtnBox">
                            <el-button class="btn-delete" v-if="btnShow.RemarksBtn" @click="RemarksBtn(scope.row,1)">残损备注</el-button>
                            <el-button type="primary" v-if="btnShow.detailsBtn" @click="detailsBtn(scope.row)">残损详情</el-button>
                            <el-button class="btn-delete" v-if="btnShow.toExamineBtn" @click="toExamineBtn(scope.row)">残损审核</el-button>
                            <el-button class="btn-delete" v-if="btnShow.replenishmentdetalisBtn" @click="replenishmentdetalisBtn(scope.row)">补货详情</el-button>
                            
                        </div>
					</template>
				</el-table-column> 
			</el-table>
			<div v-if="listData.length>0" class="mainPageTurningBox">
				<el-pagination :current-page="currentPage" :page-size="pageSize" :total="totalNum" layout="total, prev, pager, next, jumper" background @current-change="handleCurrentChange"/>
			</div>
		</el-row>
		<el-dialog :visible.sync="settingDialog.show" :title="settingDialog.title" :close-on-click-modal="false"  :width="settingDialog.width" @closed="closedialog('settingFrom')">
            <el-form ref="settingFrom" :model="settingFrom"  label-width="120px" :rules="formRules">
				<div v-if="settingDialog.title == '新增残损'">
					<el-form-item  label="安装门店:" prop="darb_shop_id">
						<el-select v-model="settingFrom.darb_shop_id" placeholder="请选择安装门店" class="mainIptSelBox"  @click.native ="getShops('',1)" clearable filterable  :multiple="false" remote :remote-method="(query)=>{getShops(query,1)}">
							<el-option v-for="item in find_chan" :key="item.chan_id" :label="item.chan_unit_name" :value="item.chan_id"/>
						</el-select>
					</el-form-item>
					<el-form-item  label="残损商品:" prop="drgb_goo_id">
						<el-select v-model="settingFrom.drgb_goo_id" placeholder="请选择残损商品" class="mainIptSelBox" @change="goodsdetails"  @click.native ="getGoods('',1)" clearable filterable  :multiple="false" remote :remote-method="(query)=>{getGoods(query,1)}">
							<el-option v-for="item in GoodsList" :key="item.rebg_id" :label="item.rebg_goo_name" :value="item.rebg_id"/>
						</el-select>
						<el-row v-if="settingFrom.drgb_goo_id != ''">
							<el-col :span="12">
								商品名称：{{settingFrom.drgb_goo_name}}
							</el-col>
							<el-col :span="12">
								商品编码：{{settingFrom.drgb_goo_encode}}
							</el-col>
							<el-col :span="12">
								品类：{{settingFrom.drgb_cate_name}}
							</el-col>
							<el-col :span="12">
								品牌：{{settingFrom.drgb_bra_name}}
							</el-col>
						</el-row>
					</el-form-item>
					<el-form-item label="处理结果:"  prop="drgb_result_type">
						<el-select v-model="settingFrom.drgb_result_type" clearable class="mainIptSelBox" placeholder="请选择处理结果"> 
							<el-option value="1" label="折现"></el-option>
							<el-option value="2" label="退回"></el-option>
						</el-select>
					</el-form-item>
					<el-form-item  v-if="settingFrom.drgb_result_type == '1'" label="折现金额:" class="mainIptSelBox"  prop="drgb_discount_amount">
						<el-input v-model="settingFrom.drgb_discount_amount" clearable placeholder="请输入折现金额"></el-input>
					</el-form-item>
					<el-form-item label="补货方式:" prop="drgb_way_type">
							<el-select v-model="settingFrom.drgb_way_type" clearable placeholder="请选择补货方式"> 
							<el-option value="2" label="单独补发"></el-option>
							<el-option value="1" label="合并补发"></el-option>
						</el-select>
					</el-form-item>
					<el-form-item label="电瓶条码号:"  prop="drgb_storage_code">
						<el-input v-model="settingFrom.drgb_storage_code" class="mainIptSelBox" clearable placeholder="请输入电瓶条码号"></el-input>
					</el-form-item>
					<el-form-item label="图片资料:">
						<input type="file" id="uploadImg" @change="uploadchange">
						<el-row>
							<el-col :span="20">
								<el-row>
									<el-col :span="8" v-for="(item, index) in imgUpList" :key="index" class="uploadimg">
										<el-row class="loadIcon">
											<div class="loadimg" v-if="item.imgbase64 != ''">
												<img :src="item.imgbase64" >
												<i class="el-icon-close icon-close" @click="item.imgbase64 = ''"></i>
											</div>
											<i v-else @click="uploadimg(index)" class="el-icon-plus icon-plus"></i>
										</el-row>
										<el-row>
											{{item.title}}
										</el-row>
									</el-col>
								</el-row>
							</el-col>
						</el-row>
					</el-form-item>
				</div>
				<div v-if="settingDialog.title == '残损备注' || settingDialog.title == '审核驳回'">
					<el-form-item label="备 注：" prop="dare_remark">
						<el-input
							class="mainIptSelBox"
							type="textarea"
							:autosize="{ minRows: 2, maxRows: 4}"
							placeholder="请输入备注"
							v-model="settingFrom.dare_remark">
						</el-input>
					</el-form-item>
				</div>
				<div v-if="settingDialog.title == '残损审核'">
					<el-row>
						<el-col :span="12">
							<el-form-item label="残损单号">
								{{auditform.dare_data.dare_number}}
							</el-form-item>
						</el-col>
						<el-col :span="12">
							<el-form-item label="申请单位">
								{{auditform.dare_data.shop_name}}
							</el-form-item>
						</el-col>
						<el-col :span="12">
							<el-form-item label="申请时间">
								{{auditform.dare_data.dare_create_time}}
							</el-form-item>
						</el-col>
						<el-col :span="12">
							<el-form-item label="电瓶条码号">
								{{auditform.dago_data.dago_storage_code || '无'}}
							</el-form-item>
						</el-col>
					</el-row>
					<el-form-item label="图片资料:">
						<el-row>
							<el-col :span="20">
								<el-row>
									<el-col :span="8" v-for="(item, index) in auditform.dago_data.dago_goo_img" :key="index" class="uploadimg">
										<el-row class="loadIcon">
											<div class="loadimg" >
												<img :src="'http://gtest.bluearp.com/'+item" >
												<!-- <i class="el-icon-close icon-close" @click="item.imgbase64 = ''"></i> -->
											</div>
											<!-- <i v-else @click="uploadimg(index)" class="el-icon-plus icon-plus"></i> -->
										</el-row>
										<el-row>
											<!-- {{item.title}} -->
										</el-row>
									</el-col>
								</el-row>
							</el-col>
						</el-row>
					</el-form-item>
				</div>
				<div v-if="settingDialog.title == '审核通过'">
					<el-form-item  label="残损商品:" prop="drgb_goo_id">
						<el-select v-model="settingFrom.drgb_goo_id" placeholder="请选择残损商品" class="mainIptSelBox" @change="goodsdetails"  @click.native ="getGoods('',1)" clearable filterable  :multiple="false" remote :remote-method="(query)=>{getGoods(query,1)}">
							<el-option v-for="item in GoodsList" :key="item.rebg_id" :label="item.rebg_goo_name" :value="item.rebg_id"/>
						</el-select>
						<el-row v-if="settingFrom.drgb_goo_id != ''">
							<el-col :span="12">
								商品名称：{{settingFrom.drgb_goo_name}}
							</el-col>
							<el-col :span="12">
								商品编码：{{settingFrom.drgb_goo_encode}}
							</el-col>
							<el-col :span="12">
								品类：{{settingFrom.drgb_cate_name}}
							</el-col>
							<el-col :span="12">
								品牌：{{settingFrom.drgb_bra_name}}
							</el-col>
						</el-row>
					</el-form-item>
					<el-form-item label="处理结果:"  prop="drgb_result_type">
						<el-select v-model="settingFrom.drgb_result_type" clearable class="mainIptSelBox" placeholder="请选择处理结果"> 
							<el-option value="1" label="折现"></el-option>
							<el-option value="2" label="退回"></el-option>
						</el-select>
					</el-form-item>
					<el-form-item  v-if="settingFrom.drgb_result_type == '1'" label="折现金额:" class="mainIptSelBox"  prop="drgb_discount_amount">
						<el-input v-model="settingFrom.drgb_discount_amount" clearable placeholder="请输入折现金额"></el-input>
					</el-form-item>
					<el-form-item label="补货方式:" prop="drgb_way_type">
						<el-select v-model="settingFrom.drgb_way_type"  class="mainIptSelBox" clearable placeholder="请选择补货方式"> 
							<el-option value="2" label="单独补发"></el-option>
							<el-option value="1" label="合并补发"></el-option>
						</el-select>
					</el-form-item>
					<!-- <el-form-item label="处理结果:"  prop="drgb_way_type">
						<el-select v-model="settingFrom.drgb_way_type" clearable class="mainIptSelBox" placeholder="请选择处理结果"> 
							<el-option value="1" label="折现"></el-option>
							<el-option value="2" label="退回"></el-option>
						</el-select>
					</el-form-item> -->
				</div>
				<div v-if="settingDialog.title == '残损详情'">
					<el-row>
						<el-col :span="12">
							<el-form-item label="商品名称">
								{{DeliveryForm.find_bill.dago_goo_name}}
							</el-form-item>
						</el-col>
						<el-col :span="12">
							<el-form-item label="商品品牌">
								{{DeliveryForm.find_bill.dago_bra_name}}
							</el-form-item>
						</el-col>
						<el-col :span="12">
							<el-form-item label="商品品类">
								{{DeliveryForm.find_bill.dago_cate_name}}
							</el-form-item>
						</el-col>
						
						<el-col :span="12">
							<el-form-item label="残损数量">
								{{DeliveryForm.find_bill.dago_goo_encode}}
							</el-form-item>
						</el-col>
						<el-col :span="8">
							<el-form-item label="电瓶条码">
								{{DeliveryForm.find_bill.dago_storage_code}}
							</el-form-item>
						</el-col>
					
					</el-row>
					<el-form-item label="图片资料:">
						<el-row>
							<el-col :span="20">
								<el-row>
									<el-col :span="8" v-for="(item, index) in imgUpListtow" :key="index" class="uploadimg">
										<el-row class="loadIcon">
											<div class="loadimg" >
												<img :src="'http://gtest.bluearp.com/'+item" >
											</div>
										</el-row>
										<el-row>
											<!-- {{item.title}} -->
										</el-row>
									</el-col>
								</el-row>
							</el-col>
						</el-row>
					</el-form-item>
				</div>
				<div v-if="settingDialog.title == '残损补货详情'">
					<el-row>
						<el-col :span="12">
							<el-form-item label="残损补货">
								{{DeliveryForm.find_bill.dare_number}}
							</el-form-item>
						</el-col>
						<el-col :span="12">
							<el-form-item label="创建时间">
								{{DeliveryForm.find_bill.dare_create_time}}
							</el-form-item>
						</el-col>
						<el-col :span="12">
							<el-form-item label="收货对象">
								{{DeliveryForm.find_bill.dare_shop_name}}
							</el-form-item>
						</el-col>
						
						<el-col :span="12">
							<el-form-item label="商品总量">
								{{DeliveryForm.find_bill.dare_actual_quantity}}
							</el-form-item>
						</el-col>
						<el-col :span="8">
							<el-form-item label="备注">
								{{DeliveryForm.find_bill.dare_remark}}
							</el-form-item>
						</el-col>
					</el-row>
					 <el-row class="mainContentItemBox" >
                        <div class="mainHeaderTitleBox">
                            <div class="titleNameBox">商品信息</div>
                            <div class="buttonBox">
							</div>
                        </div>
                    </el-row>
                     <el-row>
                        <el-table border  :data="DeliveryForm.find_bill_goods" style="width: 100%">
                            <el-table-column prop="darg_goo_name" align="center" label="商品名称" />
                            <el-table-column prop="darg_goo_encode" align="center" label="商品编号" />
                            <el-table-column prop="darg_bra_name" align="center" label="品牌" />
                            <el-table-column prop="darg_cate_name" align="center" label="品类" />
                            <el-table-column prop="dare_goods_quantity" align="center" label="商品数量" />
                            <el-table-column align="center" key="dare_delivery_quantity" label="已送货" />
                        </el-table>
                    </el-row>
				</div>
            </el-form>
			<span slot="footer" v-if="settingDialog.title != '残损审核' && settingDialog.title != '残损详情'&& settingDialog.title != '残损补货详情'">
                <el-button @click="settingDialog.show = false">取 消</el-button>
				<el-button type="primary" @click="SubmitBtn('settingFrom')">提 交</el-button>
            </span>
            <span slot="footer" v-if="settingDialog.title == '残损审核'">
                <el-button @click="auditBtn(1)" type="danger">驳 回</el-button>
                <el-button @click="auditBtn(2)" type="primary">通 过</el-button>
            </span>
		</el-dialog>
    </div>
</template>
<script>
import { errorStatus } from '@/utils/index'

import {getDistributors, getShops, getGoods} from '@/api/commonAction'
import {DamageProcessindex, DamageProcess_add, DamageProcess_remark, DamageProcess_audit, DamageProcess_info, DamageProcess_damageDetail } from '@/api/replenishment'
import { validatePrice } from '@/utils/validate'

export default {
    data(){
		const picezz = (rule, value, callback) => {
			if(!validatePrice(value)){
				callback(new Error(''))
			}else{
				callback()
			}
		}
		const remarktype = (rule, value, callback) => {
			if(this.settingDialog.title == '审核驳回'||this.settingDialog.title == '审核通过'){
				if(this.auditform.dare_data.dare_state == 4){
					return true
				}else{
					return false
				}
			}else{
				return true
			}
		}
        return{
			btnShow:{},
            formList:{
				Time:"",
				dadw_shop_id:"",
				dadw_damaged_number:"",
				dare_replenishment_bills_number:""
			},
			formRules:{
				darb_shop_id:[
                    { required: true, message: '请选择门店', trigger: 'blur' }
				],
				drgb_goo_id:[
                    { required: true, message: '请选择商品', trigger: 'blur' }
				],
				drgb_result_type:[
                    { required: true, message: '请选择结果', trigger: 'blur' }
				],
				drgb_discount_amount:[
                    { required: true, message: '请输入折现金额', validator:picezz, trigger: 'blur' }
				],
				drgb_storage_code:[
                    { required: true, message: '请输入电瓶条码', trigger: 'blur' }
				],
				dare_remark:[
                    { required: remarktype, message: '请输入备注', trigger: 'blur' }
				],
				drgb_way_type:[
                    { required: true, message: '请选择补货方式', trigger: 'blur' }
				],
			},
            StoreList:[],
			channelList:[],
			GoodsList:[],
			listData:[],
			find_chan:[],
			settingDialog:{
				title:"",
				show:false,
				width:"",
			},
			settingFrom:{
				darb_shop_id:"",
				drgb_goo_id:"",
				drgb_goo_name:"",
				drgb_goo_encode:"",
				drgb_bra_name:"",
				drgb_cate_name:"",
				drgb_result_type:"",
				drgb_discount_amount:"",
				drgb_way_type:"",
				drgb_storage_code:"",
				img:[],
				dare_id:"",
				dare_remark:"",
			},
			imgUpListtow:[],
			imgUpList:[
				{
					title:"电瓶条码",
					imgbase64:''
				},
				{
					title:"检测图片",
					imgbase64:''
				},
				{
					title:"极柱图片",
					imgbase64:''
				},
				{
					title:"产品图片",
					imgbase64:''
				},
				{
					title:"整体图片",
					imgbase64:''
				},
			],
			DeliveryForm:{
				find_bill:{},
				find_bill_Goods:[]
			},
			auditform:{},
			detailsForm:{},
			imgUpIndex:'',
			currentPage: 1,//当前页码
			pageSize: null,//每页多少条
            totalNum: null,//总共多少条
        }
	},
	created(){
		this.getPageInfo();
	},
	methods:{
		  // 获取列表
		getPageInfo() {
			const loading = this.$loading({
				lock: true,
				text: 'Loading',
				spinner: 'el-icon-loading',
				background: 'rgba(0, 0, 0, 0.7)'
			})
            const data = {...this.formList};
            if(this.formList.Time.length != 0){
                data.start_time = this.formList.Time[0];
                data.end_time = this.formList.Time[1];
            }
            data.page = this.currentPage;
            // data.dare_state = this.shbi_state;
			data.pri_id = this.$route.meta.pri_id;
			DamageProcessindex(data).then(response => {
				const dataRep = response.data
				if (errorStatus(dataRep)) {
					this.listData = dataRep.data.data;
					for(let i in this.listData){
						for(let j in dataRep.data.find_chan){
							if(this.listData[i].dare_shop_id ==  dataRep.data.find_chan[j].chan_id){
                                this.listData[i].dare_shop_name = dataRep.data.find_chan[j].chan_unit_name;
							}
                        }
                    }
                    
					this.find_chan = dataRep.data.find_chan
					this.currentPage = dataRep.data.current_page
					this.pageSize = dataRep.data.current_number
					this.totalNum = dataRep.data.total
					// 操作按钮
					const btnList = dataRep.list_button;
					for (const i in btnList) {
						if (btnList[i].pri_method_name === '备注') {
							this.btnShow.RemarksBtn = true
						}  else if (btnList[i].pri_method_name === '审核') {
							this.btnShow.toExamineBtn = true
						} else  if (btnList[i].pri_method_name === '详情') {
							this.btnShow.detailsBtn = true
						} else if (btnList[i].pri_method_name === '新增') {
							this.btnShow.addListBtn = true
						} else if (btnList[i].pri_method_name === '残损补货详情') {
							this.btnShow.replenishmentdetalisBtn = true
						} 
						
                        
						
					}
				}
				loading.close()
			})
			.catch(err => {
				console.log(err)
				loading.close()
				this.$message.error('请求失败!')
				// console.log("获取列表err", err);
			})
        },
		 // 获取配送商渠道
		getDistributors(query,type,Id) {
			const data = {}
			data.app_role = type
			if(query){
				data.search_data =query
			}
			getDistributors(data)
			.then(response => {
				console.log(response.data)
				if(errorStatus(response.data)){
					this.channelList = response.data.data.data
				}
			})
		},
		 // 获取安装门店渠道
		getShops(query,type,Id) {
			const data = {}
			data.app_role = type
			if(query){
				data.search_data =query
			}
			getShops(data)
			.then(response => {
				console.log(response.data)
				if(errorStatus(response.data)){
					this.find_chan = response.data.data.data
				}
			})
		},
		// 图片上传
		uploadimg(index){
			document.getElementById('uploadImg').click();
			this.imgUpIndex = index;
		},
		uploadchange(e){
			const _this = this;
			var file = e.target.files[0];
			var reader = new FileReader();
			reader.readAsDataURL(file);
			reader.onload = function(e) {
				// 读取到的图片base64 数据编码 将此编码字符串传给后台即可
				var img = e.target.result;
				_this.imgUpList[_this.imgUpIndex].imgbase64 = img;
				document.getElementById('uploadImg').value = '';
			}
		},
		 // 获取商品渠道
		getGoods(query,type,Id) {
			const data = {}
			data.app_role = type
			if(query){
				data.search_data =query
			}
			getGoods(data)
			.then(response => {
				console.log(response.data)
				if(errorStatus(response.data)){
					this.GoodsList = response.data.data.data
				}
			})
		},
		// 商品信息匹配
		goodsdetails(e){
			if(e != ''){
				for(let i=0;i<this.GoodsList.length;i++){
					if(this.GoodsList[i].rebg_id == e){
						this.settingFrom.drgb_goo_name = this.GoodsList[i].rebg_goo_name;
						this.settingFrom.drgb_goo_encode = this.GoodsList[i].rebg_goo_encode;
						this.settingFrom.drgb_bra_name = this.GoodsList[i].rebg_bra_name;
						this.settingFrom.drgb_cate_name = this.GoodsList[i].rebg_cate_name;
					}
				}
			}else{
				this.settingFrom.drgb_goo_name = '';
				this.settingFrom.drgb_goo_encode = '';
				this.settingFrom.drgb_bra_name = '';
				this.settingFrom.drgb_cate_name = '';
			}
		},
		// 残损处理补货详情
		replenishmentdetalisBtn(row){
			this.settingDialog.title = '残损补货详情';
			this.settingDialog.width = '800px';
			const datadd = {
				dare_id:row.dare_id
			}
			DamageProcess_damageDetail(datadd).then(success=>{
				if(success.data.code == 200){
					this.DeliveryForm.find_bill = row;
					this.DeliveryForm.find_bill_goods = [];
					this.DeliveryForm.find_bill_goods.push(success.data.data);
					this.settingDialog.show = true;
				}else{
					this.$message.error(success.data.data)
				}
			}).catch(err=>{
				this.$message.error('残损补货详情获取失败！')
			})
		},
		// 新增
		addDamaged(){
			this.settingDialog.title = '新增残损';
			this.settingDialog.width = '800px';
			this.settingDialog.show = true;
		},
		// 备注
		RemarksBtn(row){
			this.settingDialog.title = '残损备注';
			this.settingDialog.width = '600px';
			this.settingFrom.dare_id = row.dare_id;
			this.settingDialog.show = true;
		},
		// 残损审核
		toExamineBtn(row){
			this.settingFrom.dare_id = row.dare_id;
			let datadd = {
				dare_id:row.dare_id,
				type:1
			}
			DamageProcess_audit(datadd).then(success=>{
				if(success.data.code == 200){
					this.settingDialog.title = '残损审核';
					this.settingDialog.show = true;
					this.settingDialog.width = '600px';
					this.auditform = success.data.data;
				}else{
					this.$message.error(success.data.data);
				}
			}).catch(err=>{
				this.$message.error('审核信息获取失败！')
			})
		},
		// 审核操作
		auditBtn(type){
			if(type == 1){
				this.settingDialog.title = '审核驳回';
				this.settingDialog.width = '600px';
			}else{
				this.settingDialog.title = '审核通过';
				this.settingDialog.width = '600px';
			}
		},
		// 翻页
		handleCurrentChange(e){
			this.currentPage = e;
			this.getPageInfo();
		},
		// 残损详情
		detailsBtn(row){
			let datadd ={
				dare_id:row.dare_id
			}
			DamageProcess_info(datadd).then(success=>{
				if(success.data.code == 200){
					this.detailsForm = success.data.data;
					this.settingDialog.title = '残损详情';
					this.settingDialog.show = true;
					this.DeliveryForm.find_bill.dago_goo_name = success.data.data.dago_goo_name;
					this.DeliveryForm.find_bill.dago_bra_name = success.data.data.dago_bra_name;
					this.DeliveryForm.find_bill.dago_cate_name = success.data.data.dago_cate_name;
					this.DeliveryForm.find_bill.dago_goo_encode = success.data.data.dago_goo_encode;
					this.DeliveryForm.find_bill.dago_storage_code = success.data.data.dago_storage_code;
					this.imgUpListtow = success.data.dago_goo_img;
				}else{	
					this.$message.error(success.data.data)
				}
			}).catch(err=>{
				console.log(err)
					this.$message.error('详情获取失败！')
			})
		},
		// 弹窗关闭
        closedialog(formName){
			if(this.settingDialog.title == '审核驳回'||this.settingDialog.title == '审核通过'){
				this.settingDialog.title = '残损审核';
				this.settingDialog.width = '800px';
				this.settingDialog.show = true;
				if(this.settingDialog.title == '审核通过'){
					let dare_id = this.settingFrom.dare_id;
					this.$refs[formName].resetFields();
					this.settingFrom.dare_id = dare_id;
				}
			}else{
				this.$refs[formName].resetFields();
				this.auditform = {}
			}
		},
		// 重置
		resetForm(formName) {
            this.$refs[formName].resetFields()
		},
		// 提交
		SubmitBtn(formName){
			this.$refs[formName].validate((valid) => {
				if(valid){
					if(this.settingDialog.title == '新增残损'){
						
						let num = 0,imgs = [];
						for(var i=0;i<this.imgUpList.length;i++){
							if(this.imgUpList[i].imgbase64 != ''){
								num ++;
								imgs.push(this.imgUpList[i].imgbase64);
							}
						}
						if(num == 0){
							this.$message.warning('至少上传一张图片信息！');
							return false;
						}
						const datadd = JSON.parse(JSON.stringify(this.settingFrom))
						datadd.img = imgs;
						DamageProcess_add(datadd).then(success=>{
							if(success.data.code == 200){
								this.$message.success(success.data.data);
								this.getPageInfo();
								this.settingDialog.show = false;
							}else{
								this.$message.error(success.data.data);
							}
						}).catch(err=>{
							this.$message.error('添加失败！')
						})
					}else if(this.settingDialog.title == '残损备注'){
						let  datadd = {
							dare_id:this.settingFrom.dare_id,
							dare_remark:this.settingFrom.dare_remark,
						}
						DamageProcess_remark(datadd).then(success=>{
							if(success.data.code == 200){
								this.$message.success(success.data.data);
								this.getPageInfo();
								this.settingDialog.show = false;
							}else{
								this.$message.error(success.data.data);
							}
						}).catch(err=>{
							this.$message.error('备注失败！')
						})
					}else if(this.settingDialog.title == '审核驳回'){
					
						let datadd = {
							dare_type:2,
							type:2,
							dare_id:this.settingFrom.dare_id,
							dare_state:this.auditform.dare_data.dare_state,
							dare_remark:this.settingFrom.dare_remark

						}
						DamageProcess_audit(datadd).then(success=>{
							if(success.data.code == 200){
								this.$message.success(success.data.data);
								this.getPageInfo();
								this.settingDialog.title = '残损审核';
								this.settingDialog.show = false;
							}else{
								this.$message.error(success.data.data);
							}
						}).catch(err=>{
							this.$message.error('审核驳回失败！')
						})
					}else if(this.settingDialog.title == '审核通过'){
						if(this.settingFrom.drgb_way_type == ''){
							this.$message.warning('请选择补货方式');
							return false
						}
						let datadd ={
							dare_type:1,
							type:2,
							dare_id:this.settingFrom.dare_id,
							dare_state:this.auditform.dare_data.dare_state,
							dare_result:this.settingFrom.drgb_result_type,
							dare_replenishment_way:this.settingFrom.drgb_way_type,
							dare_discount_amount:this.settingFrom.drgb_discount_amount,
							dago_goo_id:this.settingFrom.drgb_goo_id,
							dago_goo_name:this.settingFrom.drgb_goo_name,
							dago_bra_name:this.settingFrom.drgb_bra_name,
							dago_cate_name:this.settingFrom.drgb_cate_name,
							dago_goo_encode:this.settingFrom.drgb_goo_encode,
						}
						DamageProcess_audit(datadd).then(success=>{
							if(success.data.code == 200){
								this.$message.success(success.data.data);
								this.getPageInfo();
								this.settingDialog.title = '残损审核';
								this.settingDialog.show = false;
							}else{
								this.$message.error(success.data.data);
							}
						}).catch(err=>{
							this.$message.error('审核通过失败！')
						})
					}
				}else{
					this.$message.warning('请填写全部信息，再提交！')
				}
			})
		}
	}
}
</script>
<style scoped>
	#uploadImg{
		display: none
	}
	.uploadimg{
		padding:  15px 10px;
		text-align: center;
	}
	.loadIcon  .icon-plus{
		font-size: 30px;
		padding: 40px;
		border: 1px dashed #ccc;
		border-radius: 6px;
		color: #ccc;
		cursor: pointer;
	}
	.loadimg {
		position: relative;
	}
	.loadimg img{
		width: 98px;
		height: 98px;
	}
	.loadimg:hover .icon-close{
		display: block;
	}
	.icon-close{
		position: absolute;
		padding: 5px;
		background: rgba(0,0,0,.2);
		color: #fff;
		font-size: 16px;
		border-radius: 4px;
		right: 0;
		top: 0;
		display: none;
	}
</style>