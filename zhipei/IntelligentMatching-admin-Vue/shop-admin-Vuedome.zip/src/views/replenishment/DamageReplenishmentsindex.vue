<template>
    <div>
        <!-- 信息筛选 -->
		<el-row class="mainContentItemBox" >
			<div class="mainHeaderTitleBox">
				<div class="titleNameBox">信息筛选</div>
				<div class="buttonBox">
				</div>
			</div>
			<el-form ref="formList" :model="formList" size="medium" label-width="100px" class="mainSearchItemBox">
				<el-row>
					<el-col :span="6">
						<el-form-item  label="收货对象:" prop="dare_chan_id">
							<el-select v-model="formList.dare_chan_id" clearable placeholder="请选择收货对象" class="mainIptSelBox"  @click.native ="getDistributors('',1)"  filterable  :multiple="false" remote :remote-method="(query)=>{getDistributors(query,1)}">
								<el-option v-for="item in channelList" :key="item.chan_id" :label="item.chan_unit_name" :value="item.chan_id"/>
							</el-select>
						</el-form-item>
					</el-col>
                    <el-col :span="6">
                        <el-form-item label="补货单号:" prop="dare_replenishment_bills_number">
							<el-input v-model="formList.dare_replenishment_bills_number" placeholder="请输入单号" clearable ></el-input>
						</el-form-item>
                    </el-col>
                     <el-col :span="6">
                        <el-form-item label="补货职能:" prop="dare_duty_state">
							<el-select v-model="formList.dare_duty_state" placeholder="请选择补货职能" class="mainIptSelBox" clearable >
								<el-option  label="安装门店" :value="1"/>
								<el-option  label="配送商" :value="2"/>
								<el-option  label="安装门店+配送商" :value="3"/>
							</el-select>
						</el-form-item>
                    </el-col>
				
					<el-col :span="6">
						<el-form-item label="处理结果:"  prop="dare_result">
                            <el-select v-model="formList.dare_result" class="mainIptSelBox" clearable placeholder="请选择补货职务"> 
                                <el-option value="3" label="折现"></el-option>
                                <el-option value="2" label="退回"></el-option>
                            </el-select>
						</el-form-item>
					</el-col>
					<el-col :span="6">
						<el-form-item label="状态:" prop="dare_state">
                            <el-select v-model="formList.dare_state" class="mainIptSelBox" placeholder="请选择状态">
                                <el-option value="1" label="待审核"></el-option>
                                <el-option value="2" label="未完成"></el-option>
                                <el-option value="3" label="已完成"></el-option>
                                <el-option value="4" label="已驳回"></el-option>
                            </el-select>
						</el-form-item>
					</el-col>
					<el-col :span="6">
						<el-form-item label="创建时间:" prop="Time">
                            <el-date-picker v-model="formList.Time" type="daterange" value-format="yyyy-MM-dd" range-separator="至" start-placeholder="开始日期" end-placeholder="结束日期" class="mainIptSelBox"></el-date-picker>
						</el-form-item>
					</el-col>
					<el-col :span="5">
						<el-button type="primary" @click="getPageInfo">搜&nbsp;&nbsp;索</el-button>
						<el-button @click="resetForm('formList')">重&nbsp;&nbsp;置</el-button>
					</el-col>
				</el-row>
			</el-form>
		</el-row>
        <!-- 列表 -->
		<el-row class="mainContentItemBox" >
			<div class="mainHeaderTitleBox">
				<div class="titleNameBox">残损列表</div>
				<div class="buttonBox"></div>
			</div>
			<el-table :data="listData" width="100%" >
				<el-table-column label="创建时间" width="100" prop="dare_create_time"  align="center"/>
				<el-table-column label="收货对象" width="120" prop="dare_chan_name" align="center"/>
				<el-table-column label="残损补货" width="120" prop="dare_replenishment_bills_number"  align="center"></el-table-column>
				<el-table-column label="补货职务" width="200"  align="center">
					<template slot-scope="scope">
						{{scope.row.dare_duty_state == 1? '安装门店': scope.row.dare_duty_state == 2?'配送商':'安装门店+配送商'}}
					</template>
				</el-table-column>
				<el-table-column label="商品数量" width="120" prop="dare_goods_amount" align="center"/>
				<el-table-column label="已送货" width="80" prop="dare_delivery_amount"  align="center"/>
				<el-table-column label="配送费" width="80" prop="dare_logistic_total_money" class="red" align="center"/>
				<el-table-column label="残损单号" width="80" prop="dare_number" class="red" align="center"/>
				<el-table-column label="备注" width="120" prop="dare_remark" align="center"/>
				<el-table-column label="状态" width="80" prop="dare_state" align="center">
					<template slot-scope="scope">
						{{scope.row.dare_state == 1?'未发货': scope.row.dare_state  == 2 ? "待收货":'已完成'}}
					</template>
				</el-table-column>
				<el-table-column label="操作"  fixed='right' width="200" align="center">
					<template slot-scope="scope" >
                        <div class="mainOperationBtnBox">
                            <el-button class="btn-delete" v-if="btnShow.RemarksBtn" @click="RemarksBtn(scope.row,1)">账单备注</el-button>
                            <el-button class="btn-delete"  @click="confirmDeliveryBtn(scope.row,1)">确认送货</el-button>
                            <el-button class="btn-delete" v-if="btnShow.RevokeBtn"  @click="RevokeBtn(scope.row)">残损撤销</el-button>
                            <el-button class="btn-delete" v-if="btnShow.detailsBtn"  @click="detailsBtn(scope.row)">残损详情</el-button>
                            <el-button class="btn-delete" v-if="btnShow.replenishmentdetalisBtn"  @click="replenishmentdetalisBtn(scope.row)">补货详情</el-button>
							

                        </div>
					</template>
				</el-table-column> 
			</el-table>
			<div v-if="listData.length>0" class="mainPageTurningBox">
				<el-pagination :current-page="currentPage" :page-size="pageSize" :total="totalNum" layout="total, prev, pager, next, jumper" background @current-change="handleCurrentChange"/>
			</div>
		</el-row>
		<el-dialog  :visible.sync="settingDialog.show" :title="settingDialog.title" :close-on-click-modal="false"  :width="settingDialog.width" @closed="closedialog('settingFrom')">
            <el-form ref="settingFrom" :model="settingFrom"  label-width="120px" :rules="formRules">
				<div v-if="settingDialog.title == '残损备注'">
					<el-form-item label="备 注：" prop="dare_remark">
						<el-input
							class="mainIptSelBox"
							type="textarea"
							:autosize="{ minRows: 2, maxRows: 4}"
							placeholder="请输入备注"
							v-model="settingFrom.dare_remark">
						</el-input>
					</el-form-item>
				</div>
				<div v-if="settingDialog.title == '确认送货'">
					  <el-row>
						  <el-col :span="8">
                            <el-form-item label="残损单号：">
                                {{DeliveryForm.find_bill.dare_number}}
                            </el-form-item>                            
                        </el-col>
                        <el-col :span="8">
                            <el-form-item label="创建时间：">
                                {{DeliveryForm.find_bill.dare_create_time}}
                            </el-form-item>                            
                        </el-col>
                        
                        <el-col :span="6">
                             <el-form-item label="商品数量：">
                                {{DeliveryForm.find_bill.dare_goods_amount}}
                            </el-form-item> 
                        </el-col>
                        <el-col :span="8">
                             <el-form-item label="收货对象：">
                                {{DeliveryForm.find_bill.dare_chan_name}}
                            </el-form-item> 
                        </el-col>
                     
                         <el-col :span="8">
                             <el-form-item label="物流费：">
                                 <el-input placeholder="请输入物流费" @blur="/(^[1-9]\d*(\.\d{1,2})?$)|(^0(\.\d{1,2})?$)/.test(DeliveryForm.find_bill.dare_logistic_total_money) ? '' : DeliveryForm.find_bill.dare_logistic_total_money = ''" v-model="DeliveryForm.find_bill.dare_logistic_total_money"></el-input>
                            </el-form-item> 
                        </el-col>
                    </el-row>
                    <el-row class="mainContentItemBox" >
                        <div class="mainHeaderTitleBox">
                            <div class="titleNameBox">商品信息</div>
                            <div class="buttonBox">
							</div>
                        </div>
                    </el-row>
                     <el-row>
                        <el-table border  :data="DeliveryForm.find_bill_goods" style="width: 100%">
                            <el-table-column prop="darg_goo_name" align="center" label="商品名称" />
                            <el-table-column prop="darg_goo_encode" align="center" label="商品编号" />
                            <el-table-column prop="darg_bra_name" align="center" label="品牌" />
                            <el-table-column prop="darg_cate_name" align="center" label="品类" />
                            <el-table-column prop="dare_delivery_quantity" align="center" label="送货量" />
                            <el-table-column align="center" prop="dare_goods_quantity" label="商品数量" />
                        </el-table>
                    </el-row>
				</div>
				<div v-if="settingDialog.title == '残损详情'">
					 <el-row>
						  <el-col :span="24">
                            <el-form-item label="残损单号：">
                                {{DeliveryForm.find_bill.dare_number}}
                            </el-form-item>                            
                        </el-col>
						<el-col :span="8">
                             <el-form-item label="申请单位：">
                                {{DeliveryForm.find_bill.dare_chan_id}}
                            </el-form-item> 
                        </el-col>
                        <el-col :span="8">
                            <el-form-item label="创建时间：">
                                {{DeliveryForm.find_bill.dare_create_time}}
                            </el-form-item>                            
                        </el-col>
						<el-col :span="8">
                            <el-form-item label="商品名称：">
                                {{DeliveryForm.find_bill.darg_goo_name}}
                            </el-form-item>                            
                        </el-col>
						<el-col :span="8">
                            <el-form-item label="品牌：">
                                {{DeliveryForm.find_bill.darg_bra_name || '无'}}
                            </el-form-item>                            
                        </el-col>
						<el-col :span="8">
                            <el-form-item label="品类：">
                                {{DeliveryForm.find_bill.darg_cate_name || '无'}}
                            </el-form-item>                            
                        </el-col>
						<el-col :span="8">
                            <el-form-item label="商品编码：">
                                {{DeliveryForm.find_bill.darg_goo_encode}}
                            </el-form-item>                            
                        </el-col>
                        <el-col :span="8">
                             <el-form-item label="电瓶条码：">
                                {{DeliveryForm.find_bill.darg_storage_code}}
                            </el-form-item> 
                        </el-col>
						<el-col :span="8">
                             <el-form-item label="处理结果：">
                                {{DeliveryForm.find_bill.dare_result ==1 ? '折现' : '退回' }}
                            </el-form-item> 
                        </el-col>
                        <el-col :span="8" v-if="DeliveryForm.find_bill.dare_result ==1">
                             <el-form-item label="折现金额：">
                                {{DeliveryForm.find_bill.dare_discount_amount}}
                            </el-form-item> 
                        </el-col>
						<el-col :span="8" v-if="DeliveryForm.find_bill.dare_result ==1">
                             <el-form-item label="残损数量：">
                                {{DeliveryForm.find_bill.dare_replenishment_bills_number}}
                            </el-form-item> 
                        </el-col>
						
                    </el-row>
					<el-form-item label="图片资料:">
						<el-row>
							<el-col :span="20">
								<el-row>
									<el-col :span="8" v-for="(item, index) in imgUpList" :key="index" class="uploadimg">
										<el-row class="loadIcon">
											<div class="loadimg" >
												<img :src="'http://gtest.bluearp.com/'+item" >
											</div>
										</el-row>
										<el-row>
											<!-- {{item.title}} -->
										</el-row>
									</el-col>
								</el-row>
							</el-col>
						</el-row>
					</el-form-item>
				</div>
				<div v-if="settingDialog.title == '残损补货详情'">
					<el-row>
						<el-col :span="12">
							<el-form-item label="残损补货">
								{{DeliveryForm.find_bill.dare_number}}
							</el-form-item>
						</el-col>
						<el-col :span="12">
							<el-form-item label="收货对象">
								{{DeliveryForm.find_bill.dare_chan_name}}
							</el-form-item>
						</el-col>
						<el-col :span="8">
							<el-form-item label="创建时间">
								{{DeliveryForm.find_bill.dare_create_time}}
							</el-form-item>
						</el-col>
						
						<el-col :span="8">
							<el-form-item label="商品总量">
								{{DeliveryForm.find_bill.dare_goods_amount}}
							</el-form-item>
						</el-col>
						<el-col :span="24">
							<el-form-item label="备 注">
								{{DeliveryForm.find_bill.dare_remark}}
							</el-form-item>
						</el-col>
					</el-row>
					 <el-row class="mainContentItemBox" >
                        <div class="mainHeaderTitleBox">
                            <div class="titleNameBox">商品信息</div>
                            <div class="buttonBox">
							</div>
                        </div>
                    </el-row>
                     <el-row>
                        <el-table border  :data="DeliveryForm.find_bill_goods" style="width: 100%">
                            <el-table-column prop="darg_goo_name" align="center" label="商品名称" />
                            <el-table-column prop="darg_goo_encode" align="center" label="商品编号" />
                            <el-table-column prop="darg_bra_name" align="center" label="品牌" />
                            <el-table-column prop="darg_cate_name" align="center" label="品类" />
                            <el-table-column prop="dare_goods_quantity" align="center" label="商品数量" />
                            <el-table-column align="center" key="dare_delivery_quantity" label="已送货" />

                        </el-table>
                        
                    </el-row>
				</div>
			</el-form>
			<span slot="footer" v-if="settingDialog.title != '残损详情' && settingDialog.title != '残损补货详情'">
                <el-button @click="settingDialog.show = false">取 消</el-button>
				<el-button type="primary" @click="SubmitBtn('settingFrom')">提 交</el-button>
            </span>
		</el-dialog>
    </div>
</template>
<script>
import { errorStatus } from '@/utils/index'
import {getDistributors, getShops, getGoods} from '@/api/commonAction'
import {DamageReplenishments_index, DamageReplenishmentsrecall, DamagedeliveryAdd, DamageReplenishments_remark, DamageReplenishments_info, DamageReplenishments_damageDetail} from '@/api/replenishment'
export default {
    data(){
        return{
            formList:{
				Time:"",
				dare_chan_id:"",
				dare_duty_state:"",
				dare_result:"",
			},
			settingDialog:{
				title:"",
				show:false,
				width:""
			},
			settingFrom:{
				dare_remark:"",
				dare_id:"",
			},
			formRules:{
				dare_remark:[
                    { required: true, message: '请输入备注', trigger: 'blur' }
				],
			},
			DeliveryForm:{
				find_bill_goods:[],
				find_bill:""
			},
			imgUpList:[],
			btnShow:{},
            StoreList:[],
            channelList:[],
			listData:[],
			
			currentPage: 1,//当前页码
			pageSize: null,//每页多少条
            totalNum: null,//总共多少条
        }
	},
	created(){
		this.getPageInfo();
	},
	methods:{
		  // 获取列表
		getPageInfo() {
			const loading = this.$loading({
				lock: true,
				text: 'Loading',
				spinner: 'el-icon-loading',
				background: 'rgba(0, 0, 0, 0.7)'
			})
            const data = {...this.formList};
            if(this.formList.Time.length != 0){
                data.start_time = this.formList.Time[0];
                data.end_time = this.formList.Time[1];
            }
            data.page = this.currentPage;
            // data.dare_state = this.shbi_state;
			data.pri_id = this.$route.meta.pri_id;
			DamageReplenishments_index(data).then(response => {
				const dataRep = response.data
				if (errorStatus(dataRep)) {
					this.listData = dataRep.data.data;
					for(let i in this.listData){
						for(let j in dataRep.data.find_chan){
							if(this.listData[i].dare_chan_id ==  dataRep.data.find_chan[j].chan_id){
                                this.listData[i].dare_chan_name = dataRep.data.find_chan[j].chan_unit_name;
							}
                        }
                    }
                    
					this.currentPage = dataRep.data.current_page
					this.pageSize = dataRep.data.current_number
					this.totalNum = dataRep.data.total
					// 操作按钮
					const btnList = dataRep.list_button;
					for (const i in btnList) {
						if (btnList[i].pri_method_name === '备注') {
							this.btnShow.RemarksBtn = true
						} else  if (btnList[i].pri_method_name === '详情') {
							this.btnShow.detailsBtn = true
						} else  if (btnList[i].pri_method_name === '撤回') {
							this.btnShow.RevokeBtn = true
						} else  if (btnList[i].pri_method_name === '确认送货') {
							this.btnShow.confirmDeliveryBtn = true
						} else  if (btnList[i].pri_method_name === '残损补货详情') {
							this.btnShow.replenishmentdetalisBtn = true
						} 
						
                        
						
					}
				}
				loading.close()
			})
			.catch(err => {
				console.log(err)
				loading.close()
				this.$message.error('请求失败!')
				// console.log("获取列表err", err);
			})
		},
		replenishmentdetalisBtn(row){
			this.settingDialog.title = '残损补货详情';
			this.settingDialog.width = '800px';
			const datadd = {
				dare_id:row.dare_id
			}
			DamageReplenishments_damageDetail(datadd).then(success=>{
				if(success.data.code == 200){
					this.DeliveryForm.find_bill = row;
					this.DeliveryForm.find_bill_goods = [];
					this.DeliveryForm.find_bill_goods.push(success.data.data);
					this.settingDialog.show = true;
				}else{
					this.$message.error(success.data.data)
				}
			}).catch(err=>{
				this.$message.error('残损补货详情获取失败！')
			})
		},
		// 备注
		RemarksBtn(row){
			this.settingDialog.title = '残损备注';
			this.settingDialog.width = '600px';
			this.settingDialog.show = true;
			this.settingFrom.dare_id = row.dare_id;
		},
			// 撤销
		RevokeBtn(row){
			this.$confirm('确定撤销此条数据吗？, 是否继续?', '提示', {
				confirmButtonText: '确定',
				cancelButtonText: '取消',
				type: 'warning'
			}).then(() => {
				let datadd = {
					dare_id:row.dare_id
				};
				DamageReplenishmentsrecall(datadd).then(success=>{
					if(success.data.code == 200){
						this.$message.success(success.data.data);
						this.getPageInfo()
					}else{
						this.$message.error(success.data.data);
					}
				}).catch(err=>{
					this.$message.error('撤销失败！')
				})
			}).catch(() => {
				this.$message({
					type: 'info',
					message: '已取消撤销'
				});          
			});
		},
		detailsBtn(row){
			this.settingDialog.title = '残损详情';
			this.settingDialog.width = '800px';
			this.settingDialog.show = true;
			this.DeliveryForm.find_bill = row;
			// this.settingDialog.
			let datadd ={
				dare_id:row.dare_id
			}
			DamageReplenishments_info(datadd).then(success=>{
				if(success.data.code == 200){
					this.imgUpList = success.data.data.darg_goo_img;
					this.DeliveryForm.find_bill.darg_goo_name = success.data.data.darg_goo_name;
					this.DeliveryForm.find_bill.darg_bra_name = success.data.data.darg_bra_name;
					this.DeliveryForm.find_bill.darg_cate_name = success.data.data.darg_cate_name;
					this.DeliveryForm.find_bill.darg_goo_encode = success.data.data.darg_goo_encode;
					this.DeliveryForm.find_bill.darg_storage_code = success.data.data.darg_storage_code;
				}else{
					this.$message.error(success.data.data)
				}
			}).catch(err=>{
				console.log(err)
				this.$message.error('详情信息获取失败！')
			})
		},
		// 确认送货
		confirmDeliveryBtn(row){
			this.settingDialog.title = '确认送货';
			this.settingFrom.dare_id = row.dare_id;
			this.DeliveryForm.find_bill = {...row};
			this.settingDialog.width = '800px';
			let datadd = {
				type:1,
				dare_id:row.dare_id
			}
			DamagedeliveryAdd(datadd).then(success=>{
				if(success.data.code ==200){
					this.DeliveryForm.find_bill_goods = [];
					this.DeliveryForm.find_bill_goods.push(success.data.data);
					this.settingDialog.show = true;
				}else{
					this.$message.error(success.data.data)
				}
			}).catch(err=>{
				this.$message.error('送货信息获取失败！')
			})
		},
		// 翻页
		handleCurrentChange(e){
			this.currentPage = e;
			this.getPageInfo();
		},
		// 关闭弹窗
		closedialog(formName){
            this.$refs[formName].resetFields()
		},
		// 重置
		resetForm(formName) {
			this.$refs[formName].resetFields()
			this.DeliveryForm.find_bill = {};
		},
			 // 获取配送商渠道
		getDistributors(query,type,Id) {
			const data = {}
			data.app_role = type
			if(query){
				data.search_data =query
			}
			getDistributors(data)
			.then(response => {
				console.log(response.data)
				if(errorStatus(response.data)){
					this.channelList = response.data.data.data
				}
			})
		},
		// 弹窗提交
		SubmitBtn(formName){
			this.$refs[formName].validate((valid) => {
				if(valid){
					if(this.settingDialog.title == '确认送货'){
						if(this.DeliveryForm.find_bill.dare_logistic_total_money != ''){
							let datadd ={
								type:2,
								dare_id:this.settingFrom.dare_id,
								dare_logistic_total_money:this.DeliveryForm.find_bill.dare_logistic_total_money
							}
							DamagedeliveryAdd(datadd).then(success=>{
								if(success.data.code == 200){
									this.$message.success(success.data.data);
									this.getPageInfo();
									this.settingDialog.show = false
								}else{
									this.$message.error(success.data.data);
								}
							}).catch(err=>{
								this.$message.error('确认送货失败!')
							})
						}else{
							this.$message.warning('请输入配送费')
						}
					}else if(this.settingDialog.title == '残损备注'){
						let datadd ={
							dare_id:this.settingFrom.dare_id,
							dare_remark:this.settingFrom.dare_remark
						}
						DamageReplenishments_remark(datadd).then(success=>{
							if(success.data.code == 200){
								this.$message.success(success.data.data);
								this.getPageInfo();
								this.settingDialog.show = false
							}else{
								this.$message.error(success.data.data);
							}
						}).catch(err=>{
							this.$message.error('备注失败！')
						})
					}
				}
			})
		}
	}
}
</script>
<style scoped>
	.uploadimg{
		padding:  15px 10px;
		text-align: center;
	}
	.loadIcon  .icon-plus{
		font-size: 30px;
		padding: 40px;
		border: 1px dashed #ccc;
		border-radius: 6px;
		color: #ccc;
		cursor: pointer;
	}
	.loadimg {
		position: relative;
	}
	.loadimg img{
		width: 98px;
		height: 98px;
	}
	.loadimg:hover .icon-close{
		display: block;
	}
	.icon-close{
		position: absolute;
		padding: 5px;
		background: rgba(0,0,0,.2);
		color: #fff;
		font-size: 16px;
		border-radius: 4px;
		right: 0;
		top: 0;
		display: none;
	}
</style>