<template>
	<div>
		<!-- 信息筛选 -->
		<el-row class="mainContentItemBox">
			<div class="mainHeaderTitleBox">
				<div class="titleNameBox">信息筛选</div>
				<div class="buttonBox"></div>
			</div>
			<el-form ref="formList" :model="formList" size="medium" label-width="100px" class="mainSearchItemBox">
				<el-row>
					<el-col :span="24">
						<el-form-item label="状态:" prop="reor_state">
                            <el-badge v-for="(item,index) in reorStateInfo" :key="index" :value="item.value" class="mainStateBtnBox">
                                <el-button :type="item.state ? 'primary':''" @click="setReorStateBtn(item.id,index)">{{ item.name }}</el-button>
                            </el-badge>
                            <!-- <el-badge class="mainStateBtnBox">
                                <el-button @click="getdatastate(1)" :type="reor_state ==1 ? 'primary':''">未完成</el-button>
                            </el-badge>
                            <el-badge class="mainStateBtnBox">
                                <el-button @click="getdatastate(2)" :type="reor_state ==2 ? 'primary':''">未过审</el-button>
                            </el-badge>
                            <el-badge class="mainStateBtnBox">
                                <el-button @click="getdatastate(3)" :type="reor_state ==3 ? 'primary':''">已过审</el-button>
                            </el-badge> -->
						</el-form-item>
					</el-col>
					<el-col :span="6">
						<el-form-item label="订单单号:" prop="reor_order_number">
							<el-input v-model="formList.reor_order_number" placeholder="请输入订单单号" clearable :maxlength="20" class="mainIptSelBox"/>
						</el-form-item>
					</el-col>
					<el-col :span="6">
						<el-form-item label="原始单号:" prop="reor_original_number">
							<el-input v-model="formList.reor_original_number" placeholder="请输入原始单号" clearable :maxlength="13" class="mainIptSelBox"/>
						</el-form-item>
					</el-col>
					<el-col :span="6">
						<el-form-item label="商品名称:" prop="reod_goo_name">
							<el-input v-model="formList.reod_goo_name" placeholder="请输入商品名称" clearable :maxlength="20" class="mainIptSelBox"/>
						</el-form-item>
					</el-col>
					<el-col :span="6">
						<el-form-item label="单位名称:" prop="reor_shop_id">
							<el-input v-model="formList.reor_shop_id" placeholder="请输入检索编号" clearable :maxlength="13" class="mainIptSelBox"/>
						</el-form-item>
					</el-col>
					<el-col :span="6">
						<el-form-item label="过审日期:" prop="startEndTime">
                            <el-date-picker v-model="formList.startEndTime" type="daterange" range-separator="至" start-placeholder="开始日期" end-placeholder="结束日期" value-format="yyyy-MM-dd" class="mainIptSelBox"></el-date-picker>
						</el-form-item>
					</el-col>
					<el-col :span="6">
						<el-button type="primary" @click="searchList('formList')">搜&nbsp;&nbsp;索</el-button>
						<el-button @click="resetForm('formList')">重&nbsp;&nbsp;置</el-button>
					</el-col>
				</el-row>
			</el-form>
		</el-row>
		<!-- 列表 -->
		<el-row class="mainContentItemBox">
			<div class="mainHeaderTitleBox">
				<div class="titleNameBox">补货订单列表</div>
				<div class="buttonBox"></div>
			</div>
			<el-table :data="listData" width="100%" @selection-change="handleSelectionChange">
				<el-table-column type="selection" width="55"/>
				<el-table-column label="订单编号" prop="reor_order_number" align="center"/>
				<el-table-column label="原始单号" prop="reor_original_number" align="center"/>
				<el-table-column label="商品名称" prop="reod_goo_name" align="center"/>
				<el-table-column label="商品数量" prop="reod_goo_quantity" align="center"/>
				<el-table-column label="质保费" prop="reod_warranty_fee" align="center"/>
				<el-table-column label="安装费" prop="reod_install_fee" align="center"/>
				<el-table-column label="安装门店" prop="reor_shop_name" align="center"/>
				<el-table-column label="过审时间" prop="reor_on_time" align="center"/>
				<el-table-column label="状态"  align="center">
					<template slot-scope="scope">
						<span v-if="scope.row.reor_state">{{ reorStateInfo[scope.row.reor_state-1].name }}</span>
					</template>
				</el-table-column>
			</el-table>
			<div v-if="listData.length>0" class="mainPageTurningBox">
				<el-pagination :current-page="currentPage" :page-size="pageSize" :total="totalNum" layout="total, prev, pager, next, jumper" background @current-change="handleCurrentChange"/>
			</div>
		</el-row>
	</div>

</template>
<script>
import { relationOrdersList } from '@/api/replenishment'
import { errorStatus } from '@/utils/index'
export default {
	name: 'ordersList',
	data() {
		return {
			// 搜索参数
			formList: {
                startEndTime:[],
                starttime:'',
                end_time:'',
				reor_order_number: '',
				reor_shop_id: '',
				reor_original_number: '',
				reod_goo_name: '',
				reor_state: 1,
			},
			listData: [],//信息列表
			chosed: '',
			currentPage: 1,//当前页码
			pageSize: null,//每页多少条
			totalNum: null,//总共多少条
			// 订单状态
			reorStateInfo:[
				{id:"1",name:"未完成",value:0,state:true},
				{id:"2",name:"未过审",value:0,state:false},
				{id:"3",name:"已过审",value:0,state:false},
			],
		}
	},
	created() {
		// 页面加载时
		this.getPageInfo()
	},
	methods: {
		// 获取列表
		getPageInfo() {
			const loading = this.$loading({
				lock: true,
				text: 'Loading',
				spinner: 'el-icon-loading',
				background: 'rgba(0, 0, 0, 0.7)'
			})
			const data = {...this.formList};
			if(this.formList.startEndTime){
				data.start_time = this.formList.startEndTime[0];
                data.end_time = this.formList.startEndTime[1];
			}
			data.page = this.currentPage;
			data.pri_id = this.$route.meta.pri_id;
			relationOrdersList(data).then(response => {
				loading.close()
				const dataRep = response.data;
				if (errorStatus(dataRep)) {
                    this.listData = dataRep.data.data;
					this.currentPage = dataRep.data.current_page;
					this.pageSize = dataRep.data.current_number;
					this.totalNum = dataRep.data.total;
					const shopList = dataRep.data.find_chan;//安装门店列表
					for(let i in this.listData){
						var shopId = this.listData[i].reor_shop_id;
						for(let j in shopList){
							if(shopId == shopList[j].chan_id){
								this.listData[i].reor_shop_name = shopList[j].chan_unit_name;
								break;
							}
						}
					}
					// 状态数量统计
					const stateCount = dataRep.data.state_count
					for(let i in this.reorStateInfo){
						var exist = true;
						for(let j in stateCount){
							if(this.reorStateInfo[i].id == stateCount[j].reor_state){
								this.reorStateInfo[i].value = stateCount[j].count;
								exist = false;
								break;
							}
						}
						if(exist){
							this.reorStateInfo[i].value = 0;
						}
					}
				}
				
			})
			.catch(Error => {
				loading.close()
				this.$message.error('请求失败!')
			})
		},
		// 状态-点击状态搜索
		setReorStateBtn(val,index){
			// val=状态值，index=点击按钮数组的下标
			for(let i in this.reorStateInfo){
				this.reorStateInfo[i].state = false;//所有的都是false
			}
			this.reorStateInfo[index].state = true;//把当前的改成true
			this.formList.reor_state = val;
			this.getPageInfo();
		},
		// 搜索
		searchList(formName) {
			this.currentPage = 1
			this.getPageInfo()
		},
		// 重置
		resetForm(formName) {
			this.$refs[formName].resetFields()
		},
		// 选中状态
		handleSelectionChange(val) {
			this.chosed = val
		},
		// 页面--分页器
		handleCurrentChange(val) {
			this.currentPage = val
			this.getPageInfo()
		},
	}
}
</script>
