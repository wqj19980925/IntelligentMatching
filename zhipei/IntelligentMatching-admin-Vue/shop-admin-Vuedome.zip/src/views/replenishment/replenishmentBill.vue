<template>
	<div>
		<!-- 信息筛选 -->
		<el-row class="mainContentItemBox" >
			<div class="mainHeaderTitleBox">
				<div class="titleNameBox">信息筛选</div>
				<div class="buttonBox"></div>
			</div>
			<el-form ref="formList" :model="formList" size="medium" label-width="100px" class="mainSearchItemBox">
				<el-row>
					<el-col :span="24">
						<el-form-item label="状态:" prop="rebi_state">
							<el-badge class="mainStateBtnBox" >
								<el-button :type="rebi_state ==1 ? 'primary':''" @click="getdatastate(1)">待确认</el-button>
							</el-badge>
							<el-badge class="mainStateBtnBox">
								<el-button  @click="getdatastate(2)" :type="rebi_state ==2 ? 'primary':''">待审核</el-button>
							</el-badge>
							<el-badge class="mainStateBtnBox">
								<el-button @click="getdatastate(3)" :type="rebi_state ==3 ? 'primary':''">通过/未完成</el-button>
							</el-badge>
							<el-badge class="mainStateBtnBox">
								<el-button @click="getdatastate(4)" :type="rebi_state ==4 ? 'primary':''">已完成</el-button>
							</el-badge>
							 <el-badge class="mainStateBtnBox">
								<el-button @click="getdatastate(5)" :type="rebi_state ==5 ? 'primary':''">已驳回</el-button>
							</el-badge>
						</el-form-item>
					</el-col>
					
					<el-col :span="6">
						<el-form-item label="补货单号:" prop="rebi_sd_replenishment_number">
							<el-input v-model="formList.rebi_sd_replenishment_number" placeholder="请输入补货单号" clearable  class="mainIptSelBox"/>
						</el-form-item>
					</el-col>
					<el-col :span="6">
						<el-form-item label="配送商:" prop="rebi_chan_id">
							<el-select v-model="formList.rebi_chan_id" placeholder="请选择配送商"   @click.native ="getDistributors('',1)" clearable filterable  :multiple="false" remote :remote-method="(query)=>{getDistributors(query,1)}">
								<el-option v-for="item in channelList" :key="item.chan_id" :label="item.chan_unit_name" :value="item.chan_id"/>
							</el-select>
						</el-form-item>
					</el-col>
					 <el-col :span="6">
						<el-form-item label="安装门店:" prop="rebi_shop_id">
							<el-select v-model="formList.rebi_shop_id" placeholder="请选择安装门店"   @click.native ="getShops('',1)" clearable filterable  :multiple="false" remote :remote-method="(query)=>{getShops(query,1)}">
								<el-option v-for="item in StoreList" :key="item.chan_id" :label="item.chan_unit_name" :value="item.chan_id"/>
							</el-select>
						</el-form-item>
					</el-col>
					<el-col :span="6">
						<el-form-item label="补货进度:" prop="rebi_replenish_state">
							<el-select v-model="formList.rebi_replenish_state">
								<el-option value="3" label="全部"></el-option>
								<el-option value="2" label="部分"></el-option>
								<el-option value="1" label="未补"></el-option>
							</el-select>
						</el-form-item>
					</el-col>
					<el-col :span="6">
						<el-form-item label="创建时间:" prop="Time">
							<el-date-picker v-model="formList.Time" type="daterange" value-format="yyyy-MM-dd" range-separator="至" start-placeholder="开始日期" end-placeholder="结束日期" class="mainIptSelBox"></el-date-picker>
						</el-form-item>
					</el-col>
					<el-col :span="6">
						<el-button type="primary" @click="searchList('formList')">搜&nbsp;&nbsp;索</el-button>
						<el-button @click="resetForm('formList')">重&nbsp;&nbsp;置</el-button>
					</el-col>
				</el-row>
			</el-form>
		</el-row>
		<!-- 列表 -->
		<el-row class="mainContentItemBox" >
			<div class="mainHeaderTitleBox">
				<div class="titleNameBox">补货账单列表</div>
				<div class="buttonBox"></div>
			</div>
			<el-table :data="listData" width="100%" >
				<el-table-column label="补货单号" width="120" prop="rebi_sd_replenishment_number" align="center"/>
				<el-table-column label="创建时间" width="100" prop="rebi_create_time"  align="center"/>
				<el-table-column label="配送商" width="120" prop="rein_chan_name"  align="center"/>
				<el-table-column label="安装门店" width="120" prop="rebi_shop_name"  align="center"/>
				<el-table-column label="商品总量" width="80" prop="rebi_goods_amount" align="center"/>
				<el-table-column label="已送货" width="80" prop="rebi_delivery_quantity"  align="center"/>
				<el-table-column label="未补货" width="80" prop="rebi_no_replenishment" class="red" align="center"/>
				<el-table-column label="合计配送费" width="120" prop="rebi_shipping_total_money" align="center"/>
				<el-table-column label="备注" width="120" prop="rebi_remark" align="center"/>
				<el-table-column label="送货单" width="120" prop="rebi_delivery_order_quantity" align="center"/>
				<el-table-column label="补货进度" width="120" align="center">
					<template slot-scope="scope">
						<div>
							{{scope.row.rebi_replenish_state == 1?'未补':scope.row.rebi_replenish_state == 2?'部分':'全部'}}
						</div>
					</template>
				</el-table-column>
				<el-table-column label="状态" width="120" align="center">
					<template slot-scope="scope">
						<div>
							{{scope.row.rebi_state == 1?'待确认':scope.row.rebi_state == 2?'待审核':scope.row.rebi_state == 3 ? '通过/未完成' :scope.row.rebi_state == 4 ? '已完成' : '已驳回'}}
						</div>
					</template>
				</el-table-column>
				<el-table-column label="操作"  fixed='right' width="200" align="center">
					<template slot-scope="scope" >
						<div class="mainOperationBtnBox">
							<el-button class="btn-delete" v-if="btnShow.RemarksBtn" @click="RemarksBtn(scope.row)">备 &nbsp;&nbsp; &nbsp;&nbsp;&nbsp; 注</el-button>
							<el-button type="primary" v-if="btnShow.toExamineBtn" @click="toExamineBtn(scope.row)">账单审核</el-button>
							<el-button class="btn-delete" v-if="btnShow.ReverseAuditBtn" @click="ReverseAuditBtn(scope.row)">反 &nbsp;审&nbsp;核</el-button>
							<el-button type="primary" v-if="btnShow.detailsBtn" @click="detailsBtn(scope.row)">账单详情</el-button>
							<el-button type="primary" v-if="btnShow.exportBtn" @click="exportBtn(scope.row)">详情导出</el-button>
							<el-button type="primary"  v-if="btnShow.DeliverytBtn" @click="DeliveryBtn(scope.row)">送货账单</el-button> 
						</div>
					</template>
				</el-table-column> 
			</el-table>
			<div v-if="listData.length>0" class="mainPageTurningBox">
				<el-pagination :current-page="currentPage" :page-size="pageSize" :total="totalNum" layout="total, prev, pager, next, jumper" background @current-change="handleCurrentChange"/>
			</div>
		</el-row>
		<el-dialog :visible.sync="settingDialog.show" :title="settingDialog.title" :close-on-click-modal="false"  :width="settingDialog.width" @closed="closedialog('settingFrom')" >
			<el-form ref="settingFrom" :model="settingFrom"  label-width="120px" :rules="formRules">
				<div v-if="settingDialog.title == '备注'">
					<el-form-item label="备注内容" prop="rebi_remark">
						<textarea   type="textarea" class="w340 h80"   :autosize="{ minRows: 2, maxRows: 4}" placeholder="请输入备注内容" v-model="settingFrom.rebi_remark"></textarea>
					</el-form-item>
				</div>
				<div v-if="settingDialog.title == '补货账单审核'|| settingDialog.title == '补货账单详情'|| settingDialog.title ==  '送货账单详情'">
					<el-row>
						<el-col :span="8">
							<el-form-item v-if="settingDialog.title == '补货账单审核'|| settingDialog.title == '补货账单详情'" label="补货账单：">
								{{settingFrom.find_bill.rebi_sd_replenishment_number}}
							</el-form-item>
							<el-form-item label="送货单：" v-else>
								{{settingFrom.find_bill.derw_number}}
							</el-form-item>						 
						</el-col>
						<el-col :span="8">
							 <el-form-item label="创建时间：" v-if="settingDialog.title == '补货账单审核'|| settingDialog.title == '补货账单详情'">
								{{settingFrom.find_bill.rebi_create_time}}
							</el-form-item> 
							<el-form-item label="送货时间：" v-else>
								{{settingFrom.find_bill.derw_create_time}}
							</el-form-item>
						</el-col>
						<el-col :span="8">
							 <el-form-item label="商品总量："  v-if="settingDialog.title == '补货账单审核'|| settingDialog.title == '补货账单详情'">
								{{settingFrom.find_bill.rebi_goods_amount}}
							</el-form-item> 
							<el-form-item label="送货量" v-else>
								{{settingFrom.find_bill.derw_plan_send_amount}}
							</el-form-item>
						</el-col>
						<el-col :span="8">
							 <el-form-item label="配送商："  v-if="settingDialog.title == '补货账单审核'|| settingDialog.title == '补货账单详情'">
								{{settingFrom.find_bill.rebi_chan_name}}
							</el-form-item> 
							<el-form-item label="配送费：" v-else>
								{{settingFrom.find_bill.derw_total_shipping_fee}}
							</el-form-item>
						</el-col>
						<el-col :span="8">
							 <el-form-item label="安装门店：" v-if="settingDialog.title == '补货账单审核'|| settingDialog.title == '补货账单详情'">
								{{settingFrom.find_bill.rebi_shop_name}}
							</el-form-item>
							<el-form-item label="安装门店：" v-else>
								{{DeliveryForm.rebi_shop_name}}
							</el-form-item>
							
						</el-col>
						<el-col :span="24">
							 <el-form-item label="备注：" v-if="settingDialog.title == '补货账单审核'|| settingDialog.title == '补货账单详情'">
								{{settingFrom.find_bill.rebi_remark}}
							</el-form-item> 
							<el-form-item label="备注：" v-else>
								 {{settingFrom.find_bill.derw_remark}}
							</el-form-item>
						</el-col>
					</el-row>
					<el-row>
						<el-table border  :data="settingFrom.find_bill_goods" style="width: 100%">
							<el-table-column prop="date" align="center" v-if="settingDialog.title != '送货账单详情'" label="能否补货" width="180">
								<template slot-scope="scope">
									<span :class="scope.row.rebg_replenishment_state == 1 ? '':'red'">
										{{scope.row.rebg_replenishment_state == 1 ? '能':"否"}}
									</span>
								</template>
							</el-table-column>
							<el-table-column align="center" label="商品名称" >
								<template slot-scope="scope">
								   {{settingDialog.title != '送货账单详情'? scope.row.rebg_goo_name:scope.row.drgw_goo_name}}
								</template>
							</el-table-column>
							<el-table-column align="center" label="商品编码" >
								 <template slot-scope="scope">
								   {{settingDialog.title != '送货账单详情'? scope.row.rebg_goo_encode:scope.row.drgw_goo_encode}}
								</template>
							</el-table-column>
							<el-table-column align="center" label="品类" >
								 <template slot-scope="scope">
								   {{settingDialog.title != '送货账单详情'? scope.row.rebg_cate_name:scope.row.drgw_cate_name}}
								</template>
							</el-table-column>
							<el-table-column align="center" label="品牌" >
								<template slot-scope="scope">
								   {{settingDialog.title != '送货账单详情'? scope.row.rebg_bra_name:scope.row.drgw_bra_name}}
								</template>
							</el-table-column>
							<el-table-column align="center" label="配送费" >
								 <template slot-scope="scope">
								   {{settingDialog.title != '送货账单详情'? scope.row.rebg_shipping_fee:scope.row.drgw_shipping_fee}}
								</template>
							</el-table-column>
							<el-table-column prop="drgw_actual_send_quantity" align="center" v-if="settingDialog.title == '送货账单详情'"  label="已送货" />
							<el-table-column prop="rebg_goods_quantity" align="center"  v-if="settingDialog.title != '送货账单详情'" label="商品数量" />
							<el-table-column align="center"  label="操作" >
								<template slot-scope="">
									<div>
										<!-- <el-button type="text" @click="goodsdeteli(scope.row)">商品详情</el-button> -->
									</div>
								</template>
							</el-table-column>
						</el-table>
						 <div v-if="settingDialog.title == '补货账单详情'">
							<div v-if="settingFrom.find_bill_goods.length>0" class="mainPageTurningBox">
								<el-pagination :current-page="detailscurrentPage" :page-size="detailspageSize" :total="detailstotalNum" layout="total, prev, pager, next, jumper" background @current-change="detailshandleCurrentChange"/>
							</div>
						</div>
					</el-row>
				</div>
				<div v-if="settingDialog.title == '送货账单'">
					  <el-row>
						<el-col :span="6">
							<el-form-item label="补货账单：">
								{{DeliveryForm.rebi_sd_replenishment_number}}
							</el-form-item>							
						</el-col>
						<el-col :span="6">
							 <el-form-item label="配送商：">
								{{DeliveryForm.rein_chan_name}}
							</el-form-item> 
						</el-col>
						<el-col :span="6">
							 <el-form-item label="安装门店：">
								{{DeliveryForm.rebi_shop_name}}
							</el-form-item> 
						</el-col>
						<el-col :span="6">
							 <el-form-item label="补货进度：">
								{{DeliveryForm.rebi_replenish_state == 1?'未补':DeliveryForm.rebi_replenish_state == 2?'部分':'全部'}}
							</el-form-item> 
						</el-col>
						<el-col :span="6">
							 <el-form-item label="商品总量：">
								{{DeliveryForm.rebi_goods_amount}}
							</el-form-item> 
						</el-col>
						<el-col :span="6">
							 <el-form-item label="未补货：">
								{{DeliveryForm.rebi_no_replenishment}}
							</el-form-item> 
						</el-col>
						 <el-col :span="6">
							 <el-form-item label="已送货：">
								{{DeliveryForm.rebi_delivery_quantity}}
							</el-form-item> 
						</el-col>
						 <el-col :span="6">
							 <el-form-item label="合计配送费：">
								{{DeliveryForm.rebi_shipping_total_money}}
							</el-form-item> 
						</el-col>
						 <el-col :span="6">
							 <el-form-item label="状态：">
								{{DeliveryForm.rebi_state == 1?'待确认':DeliveryForm.rebi_state == 2?'待审核':DeliveryForm.rebi_state == 3 ? '通过/未完成' :DeliveryForm.rebi_state == 4 ? '已完成' : '已驳回'}}
							</el-form-item> 
						</el-col>
					</el-row>
					<el-row class="mainContentItemBox" >
						<div class="mainHeaderTitleBox">
							<div class="titleNameBox">信息筛选</div>
							<div class="buttonBox"></div>
						</div>
						<el-form ref="dialogformlist" :model="dialogformlist" size="medium" label-width="100px" class="mainSearchItemBox">
							<el-row>
								<el-col :span="6">
									<el-form-item label="送货单:" prop="derw_number">
										<el-input v-model="dialogformlist.derw_number" placeholder="请输入送货单" clearable  class="mainIptSelBox"/>
									</el-form-item>
								</el-col>
								
								<el-col :span="6">
									<el-form-item label="补货进度:" prop="derw_state">
										<el-select v-model="dialogformlist.derw_state">
											<el-option value="4" label="未发货"></el-option>
											<el-option value="3" label="已撤销"></el-option>
											<el-option value="2" label="已完成"></el-option>
											<el-option value="1" label="待收货"></el-option>
										</el-select>
									</el-form-item>
								</el-col>
								<el-col :span="7">
									<el-form-item label="创建时间:" prop="Time">
										<el-date-picker v-model="dialogformlist.Time" type="daterange" range-separator="至" start-placeholder="开始日期" end-placeholder="结束日期" value-format="yyyy-MM-dd"  class="mainIptSelBox"></el-date-picker>
									</el-form-item>
								</el-col>
								<el-col :span="5">
									<el-button type="primary" @click="dialogsearchList('dialogformlist')">搜&nbsp;&nbsp;索</el-button>
									<el-button @click="resetForm('dialogformlist')">重&nbsp;&nbsp;置</el-button>
								</el-col>
							</el-row>
						</el-form>
					</el-row>
					<el-row>
						<el-table border  :data="diatabledata" style="width: 100%">
							<el-table-column prop="derw_create_time" align="center" label="送货时间" />
							<el-table-column prop="derw_number" align="center" label="送货单" />
							<el-table-column prop="derw_total_shipping_fee" align="center" label="配送费" />
							<el-table-column prop="derw_plan_send_amount" align="center" label="送货量" />
							<el-table-column prop="derw_actual_send_amount" align="center" label="签收量" />
							<el-table-column prop="derw_remark" align="center" label="备注" />
							<el-table-column align="center" label="状态" >
								<template slot-scope="scope">
									{{scope.row.derw_state == 1?"待收货":scope.row.derw_state == 2?'已完成':'已撤销'}}
								</template>
							</el-table-column>
							<el-table-column align="center"  label="操作" >
								<template slot-scope="scope">
									<div class="mainOperationBtnBox">
										<el-button @click="Deliverydeteli(scope.row)">送货详情</el-button>
										<!-- <el-button @click="Deliveryexport(scope.row)">送货导出</el-button> -->
									</div>
								</template>
							</el-table-column>
						</el-table>
						<div v-if="diatabledata.length>0" class="mainPageTurningBox">
							<el-pagination :current-page="diacurrentPage" :page-size="diapageSize" :total="diatotalNum" layout="total, prev, pager, next, jumper" background @current-change="diahandleCurrentChange"/>
						</div>
					</el-row>
				</div>
			</el-form>
			<span slot="footer" v-if="settingDialog.title != '补货账单审核' && settingDialog.title != '补货账单详情' && settingDialog.title != '送货账单' && settingDialog.title !=  '送货账单详情'">
				<el-button @click="settingDialog.show = false">取 消</el-button>
				<el-button type="primary" @click="SubmitBtn('settingFrom')">提 交</el-button>
			</span>
			<span slot="footer" v-if="settingDialog.title == '补货账单审核'">
				<el-button @click="auditBtn(5)" type="danger">驳 回</el-button>
				<el-button @click="auditBtn(3)" type="primary">同 意</el-button>
			</span>
		</el-dialog>
		<!-- <el-dialog :visible.sync="goodsDetailShow.show" :title="goodsDetailShow.title" :close-on-click-modal="false" :width="goodsDetailShow.width">
			<el-form size="medium" label-width="80px">
				<el-row>
					<el-col :span="12">
						<div class="mainDetailGoodsImgBox">
							<img :src="baseUrl+goodsDetailData.goaf_original_img" alt="" v-if="goodsDetailData.goaf_original_img" />
							<img src="@/assets/img/goods_img_none.jpg" v-else />
						</div>
					</el-col>
					<el-col :span="12">
						<el-col :span="24">
							<el-form-item label="商品名称:" prop="" class="mainFormSeeInfoBox">
								{{ goodsDetailData.goo_name }}
							</el-form-item>
						</el-col>
						<el-col :span="24">
							<el-form-item label="检索编码:" prop="" class="mainFormSeeInfoBox">
								{{ goodsDetailData.goo_goods_encode }}
							</el-form-item>
						</el-col>
						<el-col :span="24">
							<el-form-item label="品牌名称:" prop="" class="mainFormSeeInfoBox">
								{{ goodsDetailData.goo_bra_name }}
							</el-form-item>
						</el-col>
						<el-col :span="24">
							<el-form-item label="品类名称:" prop="" class="mainFormSeeInfoBox">
								{{ goodsDetailData.goo_cate_name }}
							</el-form-item>
						</el-col>
						<el-col :span="24">
							<el-form-item label="采购价格:" prop="" class="mainFormSeeInfoBox">
								¥{{ goodsDetailData.goo_purchase_price/100 }}
							</el-form-item>
						</el-col>
						<el-col :span="24">
							<el-form-item label="批发价格:" prop="" class="mainFormSeeInfoBox">
								¥{{ goodsDetailData.goo_wholesale_price/100 }}
							</el-form-item>
						</el-col>
					</el-col>
				</el-row>
			</el-form>
			<el-card class="box-card" shadow="none">
				<div slot="header" class="clearfix">
					<span>商品属性</span>
				</div>
				<el-form size="medium" label-width="120px" v-if="goodsDetailData.goaf_attribute">
					<el-row>
						<el-col :span="24" v-for="(item,index) in goodsDetailData.goaf_attribute" :key="index">
							<el-form-item :label="item.key" prop="" class="mainFormSeeInfoBox">
								{{ item.value }}
							</el-form-item>
						</el-col>
					</el-row>
				</el-form>
				<div v-else>暂无属性信息</div>
			</el-card>
		</el-dialog> -->
	</div>
</template>
<script>
import { errorStatus } from '@/utils/index'
import {getDistributors, getShops } from '@/api/commonAction'
import {replensBillindex, replensBillremark, replensBillaudit, replensBillcancelAudit, replensBillexport, replensBilldeliveryList, replensBillinfo, replensBilldeliveryDetails} from '@/api/replenishment'
export default {
	data(){
		return {
			listData:[],
			diatabledata:[],
			btnShow:{},
			channelList:[],//配送商List
			StoreList:[],//安装门店List
			rebi_state:'',//账单状态
			goodsDetailData:{},//商品详情
			// 商品详情
			goodsDetailShow:{
				title:'商品详情',
				show:false,
				width:'560px',
			},
			baseUrl:process.env.BASE_API.replace("/index.php/api", "/"),
			formList:{
				rebi_replenish_state:"",
				rebi_sd_replenishment_number:"",
				Time:"",
				rebi_chan_id:"",
				rebi_shop_id:"",
			},
			dialogformlist:{
				Time:"",
				derw_number:"",
				derw_state:"",
			},
			settingDialog:{
				show:false,
				title:"",
				width:'800px',
			},
			settingFrom:{
				rebi_id:"",
				rebi_remark:"",
				find_bill:{},
				find_bill_goods:[],
			},
			formRules:{
				rebi_remark:[
					{ required: true, message: '请输入备注', trigger: 'blur' }
				],
			},
			DeliveryForm:{},
			Deliverytabeldata:[],
			deliverydeteli:{},
			currentPage: 1,//当前页码
			pageSize: null,//每页多少条
			totalNum: null,//总共多少条
			// 送货单分页
			diacurrentPage: 1,//送货单当前页码
			diapageSize: null,//送货单每页多少条
			diatotalNum: null,//送货单总共多少条
			// 详情分页
			detailscurrentPage: 1,//送货单当前页码
			detailspageSize: null,//送货单每页多少条
			detailstotalNum: null,//送货单总共多少条
		}
	},
	created(){
		this.getPageInfo();
	},
	methods:{
		// 获取列表
		getPageInfo() {
			const loading = this.$loading({
				lock: true,
				text: 'Loading',
				spinner: 'el-icon-loading',
				background: 'rgba(0, 0, 0, 0.7)'
			})
			const data = {...this.formList};
			if(this.formList.Time){
				data.start_time = this.formList.Time[0];
				data.end_time = this.formList.Time[1];
			}
			data.page = this.currentPage;
			data.rebi_state = this.rebi_state;
			data.pri_id = this.$route.meta.pri_id;
			replensBillindex(data).then(response => {
                loading.close()
				const dataRep = response.data
				if (errorStatus(dataRep)) {
					this.listData = dataRep.data.data;
					for(let i in this.listData){
						for(let j in dataRep.data.find_chan){
							if(this.listData[i].rebi_chan_id ==  dataRep.data.find_chan[j].chan_id){
								this.listData[i].rein_chan_name = dataRep.data.find_chan[j].chan_unit_name;
							}
						}
						for(let j in dataRep.data.find_shop){
							if(this.listData[i].rebi_shop_id ==  dataRep.data.find_shop[j].chan_id){
								this.listData[i].rebi_shop_name = dataRep.data.find_shop[j].chan_unit_name;
							}
						}
					}
					this.find_chan = dataRep.data.find_chan
					this.currentPage = dataRep.data.current_page
					this.pageSize = dataRep.data.current_number
					this.totalNum = dataRep.data.total
					// 操作按钮
					const btnList = dataRep.list_button;
					for (const i in btnList) {
						if (btnList[i].pri_method_name === '备注') {
							this.btnShow.RemarksBtn = true
						} else if (btnList[i].pri_method_name === '审核') {
							this.btnShow.toExamineBtn = true
						} else if (btnList[i].pri_method_name === '反审核') {
							this.btnShow.ReverseAuditBtn = true
						} else if (btnList[i].pri_method_name === '详情') {
							this.btnShow.detailsBtn = true
						} else if (btnList[i].pri_method_name === '导出') {
							this.btnShow.exportBtn = true
						} else if(btnList[i].pri_method_name === '送货单列表'){
							this.btnShow.DeliverytBtn = true
						}
					}
				}
				
			})
			.catch(Error => {
				loading.close()
				this.$message.error('请求失败!')
				// console.log("获取列表err", err);
			})
		},
		resetForm(formName){
			this.$refs[formName].resetFields()
		},
		closedialog(formName){
			if(this.settingDialog.title == '送货账单'){
				this.DeliveryForm = {};
				this.$refs['dialogformlist'].resetFields();
				this.diatabledata = [];
				
			}else if(this.settingDialog.title == '补货账单审核'|| this.settingDialog.title == '补货账单详情'|| this.settingDialog.title ==  '送货账单详情'){
				this.$refs['settingFrom'].resetFields();
				if(this.settingDialog.title == '送货账单详情'){
					this.settingDialog.show = true;
					this.settingDialog.width = '1000px';
					this.settingDialog.title = '送货账单';
					this.deliverydeteli = {};
					this.settingFrom.find_bill = {...this.DeliveryForm}
					this.settingFrom.find_bill_goods = this.Deliverytabeldata;
					this.Deliverytabeldata = [];
				}
			}else{
				this.$refs[formName].resetFields()
			}
			this.detailscurrentPage = 0;
			this.detailspageSize = null;
			this.detailstotalNum = null;
		},
		// 商品详情
		// viewGoodsBtn(val){
		// 	const data = {};
		// 	data.goo_id = val;
		// 	infoGoods(data).then(response => {
		// 		const dataRep = response.data
		// 		this.goodsDetailData = {};
		// 		if (errorStatus(dataRep)) {
		// 			this.goodsDetailData = dataRep.data;
		// 			this.goodsDetailData.goaf_attribute = eval(dataRep.data.goaf_attribute);
		// 			this.goodsDetailShow.show = true;
		// 		}
		// 	})
		// 	.catch(Error => {
		// 		this.$message.error('请求失败!')
		// 	})
		// },
		 // 获取配送商渠道
		getDistributors(query,type,Id) {
			const data = {}
			data.app_role = type
			if(query){
				data.search_data =query
			}
			getDistributors(data)
			.then(response => {
				console.log(response.data)
				if(errorStatus(response.data)){
					this.channelList = response.data.data.data
				}
			})
		},
		// 安装门店
		getShops(query,type,Id) {
			const data = {}
			data.app_role = type
			if(query){
				data.search_data =query
			}
			getShops(data)
			.then(response => {
				console.log(response.data)
				if(errorStatus(response.data)){
					this.StoreList = response.data.data.data
				}
			})
		},
		getdatastate(state){
			this.rebi_state = state;
			this.getPageInfo();
		},
		// 审核提交
		auditBtn(type){
			const datadd = {
				type:2,
				rebi_state:type,
				rebi_id:this.settingFrom.rebi_id,
			}
			replensBillaudit(datadd).then(success=>{
				if(success.data.code== 200){
					this.$message.success(success.data.data);
					this.getPageInfo();
					this.settingDialog.show = false;
				}else{
					this.$message.error(success.data.data);
				}
			}).catch(err=>{
				this.$message.error('操作失败！请联系管理员')
			})
		},
		// 重置
		resetForm(formName) {
			this.$refs[formName].resetFields()
			if(formName == 'formList'){
				this.rebi_state = '';
			}
		},
		// 搜索
		searchList(){
			this.currentPage = 1;
			this.getPageInfo();
		},
		// 弹框数据搜索
		dialogsearchList(){
			// this.$message.
			// 
		   this.DeliveryBtn(this.DeliveryForm);
		},
		// 翻页
		handleCurrentChange(e){
			this.currentPage = e;
			this.getPageInfo()
		},
		// 送货单翻页
		diahandleCurrentChange(e){
			this.diacurrentPage = e;
			this.DeliveryBtn(this.DeliveryForm);
		},
		// 详情分页
		detailshandleCurrentChange(e){
			this.detailscurrentPage = e;
			if(this.settingDialog.title == '补货账单详情'){
				this.detailsBtn()
			}
		},
		//备注
		RemarksBtn(row){
			this.settingDialog.title = '备注';
			this.settingDialog.width = '600px';
			this.settingFrom.rebi_id = row.rebi_id;
			this.settingDialog.show = true;
		},
		// 审核
		toExamineBtn(row){
			const loading = this.$loading({
				lock: true,
				text: 'Loading',
				spinner: 'el-icon-loading',
				background: 'rgba(0, 0, 0, 0.7)'
			})
			this.settingDialog.title = '补货账单审核';
			this.settingDialog.width = '800px';
			this.settingFrom.rebi_id = row.rebi_id;
			
			const datadd = {
				rebi_id:row.rebi_id,
				type:1
			}
			replensBillaudit(datadd).then(success=>{
				loading.close();
				if(success.data.code == 200){
					this.settingFrom.find_bill = success.data.data.rebi_data;
					this.settingFrom.find_bill.rebi_shop_name = success.data.data.rebi_data.shop_name;
					this.settingFrom.find_bill.rebi_chan_name = success.data.data.rebi_data.chan_name;
					this.settingFrom.find_bill_goods = success.data.data.find_bill_goods;
					console.log(this.settingFrom)
					this.settingDialog.show = true;
				}else{
					this.$message.error(success.data.data);
				}
			}).catch(err=>{
				loading.close();
				this.$message.error('审核信息获取失败！请联系管理员')
			})
		},
		// 反审核
		ReverseAuditBtn(row){
			// 
			// this.corebi_id
			
			 this.$confirm('确定将此条数据进行反审核操作么？是否继续', '提示', {
				confirmButtonText: '确定',
				cancelButtonText: '取消',
				type: 'warning'
			}).then(() => {
				const datadd ={
					rebi_id:row.rebi_id
				}
				replensBillcancelAudit(datadd).then(success=>{
					if(success.data.code == 200){
						this.$message.success(success.data.data);
						this.getPageInfo();
					}else{
						this.$message.error(success.data.data);
					}
				}).catch(err=>{
					this.$message.error('反审核操作失败！')
				})
			}).catch(() => {
				this.$message({
					type: 'info',
					message: '已取消反审核'
				});		  
			});
		},
		// 详情
		detailsBtn(row){
			const loading = this.$loading({
				lock: true,
				text: 'Loading',
				spinner: 'el-icon-loading',
				background: 'rgba(0, 0, 0, 0.7)'
			})
			this.settingDialog.title = '补货账单详情';
			this.settingDialog.width = '800px';
			if(row != undefined){
				this.settingFrom.rebi_id = row.rebi_id;
			}
			
			const datadd = {
				rebi_id:this.settingFrom.rebi_id,
				type:1,
				page:this.detailscurrentPage
			}
			replensBillinfo(datadd).then(success=>{
				loading.close();
				if(success.data.code == 200){
					if(row != undefined){
						this.settingFrom.find_bill = {...row};
						this.settingFrom.find_bill.rebi_chan_name = row.rein_chan_name;
					}
					this.settingFrom.find_bill_goods = success.data.data.data;
					this.settingDialog.show = true;

					this.detailscurrentPage = success.data.data.current_page
					this.detailspageSize = success.data.data.current_number
					this.detailstotalNum = success.data.data.total
				}else{
					this.$message.error(success.data.data);
				}
			}).catch(err=>{
				loading.close();
				this.$message.error('审核信息获取失败！请联系管理员')
			})
		},
		// 送货详情
		Deliverydeteli(row){
			 const loading = this.$loading({
				lock: true,
				text: 'Loading',
				spinner: 'el-icon-loading',
				background: 'rgba(0, 0, 0, 0.7)'
			})
			this.settingDialog.title = '送货账单详情';
			this.settingDialog.width = '800px';
			// this.deliverydeteli = {...row};
			
			const datadd = {
				derw_id:row.derw_id,
			}
			replensBilldeliveryDetails(datadd).then(success=>{
				loading.close();
				if(success.data.code == 200){
					this.settingFrom.find_bill = {...row};
					// console.log(row,';;;')
					this.settingFrom.find_bill.rebi_chan_name = this.DeliveryForm.rein_chan_name;
					this.settingFrom.find_bill_goods = success.data.data;
					// this.settingDialog.show = true;
					console.log(this.settingFrom,';;;;000')
				}else{
					this.$message.error(success.data.data);
				}
			}).catch(err=>{
				loading.close();
				console.log(err)
				this.$message.error('审核信息获取失败！请联系管理员')
			})
		},
		// Deliveryexport
		// 送货账单
		DeliveryBtn(row){
			const loading = this.$loading({
				lock: true,
				text: 'Loading',
				spinner: 'el-icon-loading',
				background: 'rgba(0, 0, 0, 0.7)'
			})
			this.settingDialog.title = '送货账单';
			this.settingDialog.width = '1000px';
			this.DeliveryForm = {...row};
			const datadd = {...this.dialogformlist};
			if(this.dialogformlist.Time.length == 2){
				datadd.start_time = this.dialogformlist.Time[0];
				datadd.end_time = this.dialogformlist.Time[1];
			}
			datadd.rebi_id = row.rebi_id;
			datadd.page = this.diacurrentPage;
			replensBilldeliveryList(datadd).then(success=>{
				loading.close();
				if(success.data.code == 200){
					this.diatabledata = success.data.data.data
					this.Deliverytabeldata = success.data.data.data
					this.diacurrentPage = success.data.data.current_page
					this.diapageSize = success.data.data.current_number
					this.diatotalNum = success.data.data.total
					this.settingDialog.show = true;
				}else{
					this.diatabledata = [];
					this.$message.error(success.data.data);
				}
			}).catch(err=>{
				loading.close();
				this.$message.error('送货账单获取失败！')
				this.diatabledata = []
			})
		},
	 
		// 导出
		exportBtn(row){
			this.$confirm('确定导出此条数据详情吗？ 是否继续', '提示', {
				confirmButtonText: '确定',
				cancelButtonText: '取消',
				type: 'warning'
			}).then(() => {
				const datadd ={
					rebi_id:row.rebi_id
				}
				replensBillexport(datadd).then(success=>{
					if(success.data.code == 200){
						this.$message.success('导出成功！')
						// window.location.href = 'http://gtest.bluearp.com/'+success.data.data;
						window.open('http://gtest.bluearp.com/'+success.data.data);  
					}else{
						this.$message.error(success.data.data)
					}
				}).catch(err=>{
					this.$message.error('详情导出失败！请联系管理员')
				})
			}).catch(err=>{
				this.$message.warning('已取消详情导出')
			})
			
		},
		SubmitBtn(formName){
			this.$refs[formName].validate((valid) => {
				if(valid){
					if(this.settingDialog.title == '备注'){
						const datadd ={
							rebi_remark:this.settingFrom.rebi_remark,
							rebi_id:this.settingFrom.rebi_id
						}
						replensBillremark(datadd).then(success=>{
							if(success.data.code == 200){
								this.$message.success(success.data.data);
								this.getPageInfo();
								this.settingDialog.show = false;
							}else{
								this.$message.error(success.data.data)
							}
						}).catch(err=>{
							this.$message.error('备注失败！请联系管理员')
						})
					}
				}
			})
		}

	}
}
</script>