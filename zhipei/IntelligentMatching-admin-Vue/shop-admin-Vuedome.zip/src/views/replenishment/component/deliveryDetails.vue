<template>
    <div>
        <el-row class="mainContentItemBox">
			<div class="mainHeaderTitleBox">
				<div class="titleNameBox">库存详情 >> {{prentdata.rein_chan_name}}</div>
				<div class="buttonBox">
                    <el-button type="primary" @click="reprot">导 出</el-button>
				    <el-button @click="returnprent">返 回</el-button>
                </div>
				
			</div>
			<el-form label-width="100px" class="mainSearchItemBox">
				<el-row>
					<el-col :span="6">
						<el-form-item label="配送商：">
							{{Distributor}}
						</el-form-item>					
					</el-col>
					<el-col :span="6">
						<el-form-item label="赊欠库存：">
							{{prentdata.rein_credit_amount}}
						</el-form-item>					
					</el-col>
					<el-col :span="6">
						<el-form-item label="盈余库存：">
							{{prentdata.rein_surplus_amount}}
						</el-form-item>					
					</el-col>
				</el-row>
			</el-form>
			<el-form ref="formList" :model="formList" size="medium" label-width="100px" class="mainSearchItemBox">
				<el-row>
					<el-col :span="6">
						<el-form-item label="商品名称：" prop="reid_goo_name">
							<el-input v-model="formList.reid_goo_name" placeholder="请输入商品名称"></el-input>
						</el-form-item>
					</el-col>
					<el-col :span="6">
						<el-form-item label="商品编码：" prop="reid_goo_encode">
							<el-input v-model="formList.reid_goo_encode" placeholder="请输入商品编码"></el-input>
						</el-form-item>
					</el-col>
					<el-col :span="6">
						<el-form-item label="品类名称：" prop="reid_cate_name">
							<el-select v-model="formList.reid_cate_name" placeholder="请选择品类" @click.native="getCategoryInfo()" clearable filterable :multiple="false" remote :remote-method="getCategoryInfo" class="mainIptSelBox">
								<el-option v-for="item in categoryList" :key="item.cate_id" :label="item.cate_name" :value="item.cate_name" />
							</el-select>
						</el-form-item>
					</el-col>
					<el-col :span="6">
						<el-form-item label="品牌名称：" prop="reid_bra_name">
							<el-select v-model="formList.reid_bra_name" placeholder="请选择品牌" @click.native="getBrandInfo()" clearable filterable :multiple="false" remote :remote-method="getBrandInfo" class="mainIptSelBox">
								<el-option v-for="item in brandList" :key="item.bra_id" :label="item.bra_name" :value="item.bra_name" />
							</el-select>
						</el-form-item>
					</el-col>
					
					<el-col :span="6">
						<el-form-item label="库存状态:" prop="rein_type">
							<el-select v-model="formList.reid_type" placeholder="请选择配送商" clearable class="mainIptSelBox">
								<el-option v-for="item in stockStateInfo" :key="item.id" :label="item.name" :value="item.id" />
							</el-select>
						</el-form-item>
					</el-col>
					<el-col :span="6">
						<el-button type="primary" @click="searchList('formList')">搜&nbsp;&nbsp;索</el-button>
						<el-button @click="resetForm('formList')">重&nbsp;&nbsp;置</el-button>
					</el-col>
				</el-row>
			</el-form>
		</el-row>
    	<!-- 信息筛选 -->
		<!-- <el-row class="mainContentItemBox">
			<div class="mainHeaderTitleBox">
				<div class="titleNameBox">信息筛选</div>
				<div class="buttonBox"></div>
			</div>
			
		</el-row> -->
		<!-- 列表 -->
		<el-row class="mainContentItemBox" >
			<div class="mainHeaderTitleBox">
				<div class="titleNameBox">经销商库存</div>
				<div class="buttonBox"></div>
			</div>
			<el-table :data="listData" width="100%">
				<el-table-column label="序号" type="index" width="80" align="center"/>
				<el-table-column label="商品名称" prop="reid_goo_name" align="center"/>
				<el-table-column label="商品编码" prop="reid_goo_encode" align="center"/>
				<el-table-column label="品类" prop="reid_cate_name" align="center"/>
				<el-table-column label="当前库存"  align="center">
					<template slot-scope="scope">
						<div :class="scope.row.reid_stock_quantity < 0 ? 'red':''"> 
							{{scope.row.reid_stock_quantity}}
						</div>
					</template>
				</el-table-column>
				<el-table-column label="在途商品" prop="reid_enroute_quantity" align="center"/>
				
				<el-table-column label="已补货量" prop="reid_delivery_quantity" align="center"/>
			</el-table>
			<div v-if="listData.length>0" class="mainPageTurningBox">
				<el-pagination :current-page="currentPage" :page-size="pageSize" :total="totalNum" layout="total, prev, pager, next, jumper" background @current-change="handleCurrentChange"/>
			</div>
		</el-row>
    </div>
</template>
<script>
import { relationexport, relationinfo } from '@/api/replenishment'
import { errorStatus } from '@/utils/index'
import {getBrandInfo,getCategoryInfo} from '@/api/commonAction'
export default {
    props:{
        prentdata:{
            type:Object
		},
		Distributor:{
			type:String
		}
    },
    data(){
        return{
			// 库存状态
			stockStateInfo:[
				{id:1,name:'正'},
				{id:2,name:'负'},
				{id:3,name:'平'},
			],
            formList: {
				reid_goo_name:'',
				reid_goo_encode:"",
				reid_cate_name:"",
				reid_bra_name:"",
			},
			listData:[],
			currentPage: 1,//当前页码
			pageSize: null,//每页多少条
			totalNum: null,//总共多少条
			categoryList:[],//品类LIst
			brandList:[],//品牌List
        }
	},
	created(){
		this.getPageInfo();
	},
    methods:{
			// 获取列表
		getPageInfo() {
			const loading = this.$loading({
				lock: true,
				text: 'Loading',
				spinner: 'el-icon-loading',
				background: 'rgba(0, 0, 0, 0.7)'
			})
			const data = this.formList;
			data.page = this.currentPage;
			data.rein_id = this.prentdata.rein_id;
			data.pri_id = this.$route.meta.pri_id;
			relationinfo(data).then(response => {
				const dataRep = response.data
				if (errorStatus(dataRep)) {
					this.listData = dataRep.data.data;
					this.currentPage = dataRep.data.current_page
					this.pageSize = dataRep.data.current_number
					this.totalNum = dataRep.data.total
					
				}
				loading.close()
			})
			.catch(Error => {
				loading.close()
				this.$message.error('请求失败!')
				// console.log("获取列表err", err);
			})
		},
        // 返回父组件
        returnprent(){
            this.$emit('retue');
		},
		// 搜索
		searchList(formName) {
			this.currentPage = 1
			this.getPageInfo()
		},
        // 导出
        reprot(){
            const datadd = {
				rein_id:this.prentdata.rein_id,
				chan_id:this.prentdata.rein_chan_id
			}
			relationexport(datadd).then(success=>{
				if(success.data.code == 200){
					this.$message.success('导出成功！');
					window.location.href = success.data.data;
				}
			}).catch(err=>{
				this.$message.error('导出失败！')
			})
		},
		// 品类-下拉菜单
		getCategoryInfo(val){
			const data = {};
			data.search_data = val;
			getCategoryInfo(data).then(response => {
				const dataRep = response.data
				if (errorStatus(dataRep)) {
					this.categoryList = dataRep.data.data;
				}
			})
			.catch(err => {
				console.log(err)
				this.$message.error('请求失败!')
			})
		},
		
		// 品牌-下拉菜单
		getBrandInfo(val){
			const data = {};
			data.search_data = val;
			getBrandInfo(data).then(response => {
				const dataRep = response.data
				if (errorStatus(dataRep)) {
					this.brandList = dataRep.data.data;
				}
			})
			.catch(err => {
				console.log(err)
				this.$message.error('请求失败!')
			})
		},
		// 翻页
		handleCurrentChange(e){
			this.currentPage = e;
			this.getBrandInfo();
		}
    }
}
</script>
<style scoped>
    .mainContentItemBox .mainSearchItemBox{
		padding: 10px 10px 0 10px
	}
</style>