<template>
	<div>
		<!-- 信息筛选 -->
		<el-row class="mainContentItemBox" v-if="!detailstype">
			<div class="mainHeaderTitleBox">
				<div class="titleNameBox">信息筛选</div>
				<div class="buttonBox"></div>
			</div>
			<el-form ref="formList" :model="formList" size="medium" label-width="100px" class="mainSearchItemBox">
				<el-row>
					<el-col :span="6">
						<el-form-item label="配送商:" prop="rein_chan_id">
							<el-select v-model="formList.rein_chan_id" placeholder="请选择配送商" @click.native="getDistributorDataBtn()" clearable filterable :multiple="false" remote :remote-method="getDistributorDataBtn" class="mainIptSelBox">
								<el-option v-for="item in distributorInfo" :key="item.chan_id" :label="item.chan_unit_name" :value="item.chan_id" />
							</el-select>
						</el-form-item>
					</el-col>
					<el-col :span="6">
						<el-form-item label="库存状态:" prop="rein_type">
							<el-select v-model="formList.rein_type" placeholder="请选择配送商" clearable class="mainIptSelBox">
								<el-option v-for="item in stockStateInfo" :key="item.id" :label="item.name" :value="item.id" />
							</el-select>
						</el-form-item>
					</el-col>
					<el-col :span="6">
						<el-button type="primary" @click="searchList('formList')">搜&nbsp;&nbsp;索</el-button>
						<el-button @click="resetForm('formList')">重&nbsp;&nbsp;置</el-button>
					</el-col>
				</el-row>
			</el-form>
		</el-row>
		<!-- 列表 -->
		<el-row class="mainContentItemBox"  v-if="!detailstype">
			<div class="mainHeaderTitleBox">
				<div class="titleNameBox">配送商库存</div>
				<div class="buttonBox"></div>
			</div>
			<el-table :data="listData" width="100%" @selection-change="handleSelectionChange">
				<el-table-column type="selection" width="55"/>
				<el-table-column label="配送商" prop="rein_chan_name" align="center"/>
				<el-table-column label="赊欠库存" prop="rein_credit_amount" align="center"/>
				<el-table-column label="盈余库存" prop="rein_surplus_amount" align="center"/>
				<el-table-column label="在途商品" prop="rein_enroute_amount" align="center"/>
				<el-table-column label="库存情况" align="left">
					<template slot-scope="scope">
						<p>
							赊欠类型：
							<span :class="scope.row.rein_credit_type == 1 ? 'green' : scope.row.rein_credit_type == 2? 'red' : ''">
								{{scope.row.rein_credit_type == 1? '正':scope.row.rein_credit_type == 2? '负':'平'}}
							</span> 
						</p>
						<p >
							盈亏类型：
							<span :class="scope.row.rein_surplus_type == 1 ? 'green' : scope.row.rein_surplus_type == 2? 'red' : ''">
								{{scope.row.rein_surplus_type == 1? '正':scope.row.rein_surplus_type == 2? '负':'平'}}
							</span>
						</p>
					</template>
				</el-table-column>
				<el-table-column label="操作" width="260" align="center">
					<template slot-scope="scope">
						<el-button type="primary" v-if="btnShow.detailBtn" @click="setDetailBtn(scope.row)">详情</el-button>
						<el-button class="btn-delete" v-if="btnShow.exportBtn" @click="setExportBtn(scope.row)">导出</el-button>
					</template>
				</el-table-column>
			</el-table>
			<div v-if="listData.length>0" class="mainPageTurningBox">
				<el-pagination :current-page="currentPage" :page-size="pageSize" :total="totalNum" layout="total, prev, pager, next, jumper" background @current-change="handleCurrentChange"/>
			</div>
		</el-row>
		<deliveryDetails  v-if="detailstype" :Distributor="Distributor" :prentdata="childdata" @retue="childreturn"/>
	</div>
</template>
<script>
import { relationDistributorList, relationexport } from '@/api/replenishment'
import { getChannelInfo } from '@/api/commonAction'
import { errorStatus } from '@/utils/index'
import deliveryDetails from './component/deliveryDetails'
export default {
	name: 'distributorList',
	components:{deliveryDetails},
	data() {
		return {
			detailstype:false,
			childdata:{},
			Distributor:"",
			// 搜索参数
			formList: {
				rein_chan_id:'',
				rein_type:'',
			},
			listData: [],//信息列表
			find_chan:[],//配送商List
			chosed: '',
			currentPage: 1,//当前页码
			pageSize: null,//每页多少条
			totalNum: null,//总共多少条
			distributorInfo:[],//配送商
			// 库存状态
			stockStateInfo:[
				{id:1,name:'正'},
				{id:2,name:'负'},
				{id:3,name:'平'},
			],
			// 按钮权限
			btnShow:{
				detailBtn:false,
				exportBtn:false,
			}
		}
	},
	created() {
		// 页面加载时
		this.getPageInfo()
	},
	methods: {
		// 获取列表
		getPageInfo() {
			const loading = this.$loading({
				lock: true,
				text: 'Loading',
				spinner: 'el-icon-loading',
				background: 'rgba(0, 0, 0, 0.7)'
			})
			const data = this.formList;
			data.page = this.currentPage;
			data.pri_id = this.$route.meta.pri_id;
			relationDistributorList(data).then(response => {
				const dataRep = response.data
				if (errorStatus(dataRep)) {
					this.listData = dataRep.data.data;
					for(let i in this.listData){
						for(let j in dataRep.data.find_chan){
							if(this.listData[i].rein_chan_id ==  dataRep.data.find_chan[j].chan_id){
								this.listData[i].rein_chan_name = dataRep.data.find_chan[j].chan_unit_name;
								break;
							}
						}
					}
					this.find_chan = dataRep.data.find_chan
					this.currentPage = dataRep.data.current_page
					this.pageSize = dataRep.data.current_number
					this.totalNum = dataRep.data.total
					// 操作按钮
					const btnList = dataRep.list_button;
					for (const i in btnList) {
						if (btnList[i].pri_method_name === '详情') {
							this.btnShow.detailBtn = true
						} else if (btnList[i].pri_method_name === '导出') {
							this.btnShow.exportBtn = true
						}
					}
				}
				loading.close()
			})
			.catch(Error => {
				loading.close()
				this.$message.error('请求失败!')
				// console.log("获取列表err", err);
			})
		},
		// 搜索
		searchList(formName) {
			this.currentPage = 1
			this.getPageInfo()
		},
		// 重置
		resetForm(formName) {
			this.$refs[formName].resetFields()
		},
		// 选中状态
		handleSelectionChange(val) {
			this.chosed = val
		},
		// 页面--分页器
		handleCurrentChange(val) {
			// console.log(`当前页: ${val}`)
			this.currentPage = val
			this.getPageInfo()
		},
		// 导出
		setExportBtn(row){
			const datadd = {
				rein_id:row.rein_id,
				chan_id:row.rein_chan_id
			}
			relationexport(datadd).then(success=>{
				if(success.data.code == 200){
					this.$message.success('导出成功！');
					window.location.href = success.data.data;
				}
			}).catch(err=>{
				this.$message.error('导出失败！')
			})
		},
		// 详情
		setDetailBtn(row){
			this.childdata = row;
			this.detailstype = true;
			for(let i=0;i<this.find_chan.length;i++){
				if(row.rein_chan_id == this.find_chan[i].chan_id){
					this.Distributor = this.find_chan[i].chan_unit_name;
				}
			}
			console.log(row)
		},
		childreturn(e){
			this.detailstype = false;
		},
		// 配送商-下拉菜单
		getDistributorDataBtn(val){
			const data = {};
			data.search_data = val;
			getChannelInfo(data).then(response => {
				const dataRep = response.data
				if (errorStatus(dataRep)) {
					this.distributorInfo = dataRep.data.data;
				}
			})
			.catch(Error => {
				this.$message.error('请求失败!')
			})
		},
	}
}
</script>
<style scoped>
	.green{
		color: green
	}
	.red{
		color: red
	}
</style>