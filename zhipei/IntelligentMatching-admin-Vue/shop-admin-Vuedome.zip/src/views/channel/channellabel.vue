<template>
    <div>
        <!-- 信息筛选 -->
		<el-row class="mainContentItemBox">
			<div class="mainHeaderTitleBox">
				<div class="titleNameBox">信息筛选</div>
				<div class="buttonBox"></div>
			</div>
            <el-form ref="formList" :model="formList" size="medium" label-width="100px" class="mainSearchItemBox">
                <el-row>
                    <el-col :span="6">
                        <el-form-item label="渠道标签:" prop="chla_name">
                            <el-input v-model="formList.chla_name" placeholder="请输入" clearable class="mainIptSelBox"/>
                        </el-form-item>
                    </el-col>
                    <el-col :span="6">
                        <el-form-item label="状态:" prop="chla_state">
                            <el-select v-model="formList.chla_state" placeholder="请选择状态" clearable class="mainIptSelBox">
                                <el-option v-for="item in stateSelectInfo" :key="item.id" :label="item.name" :value="item.id"/>
                            </el-select>
                        </el-form-item>
                    </el-col>          
                    <el-col :span="6">
                        <el-button type="primary" @click="searchList('formList')">搜&nbsp;&nbsp;索</el-button>
                        <el-button @click="resetForm('formList')">重&nbsp;&nbsp;置</el-button>
                    </el-col> 
                </el-row>
            </el-form>
        </el-row>
        <!-- 列表 -->
        <el-row class="mainContentItemBox">
			<div class="mainHeaderTitleBox">
				<div class="titleNameBox">渠道列表</div>
				<div class="buttonBox">
                    <el-button type="primary" v-if="btnShow.addBtn" @click="addChannelBtn()">新增</el-button>
                    <el-button v-if="btnShow.startBtn" class="btn-staCol" @click="setBatchEnableBtn()">启用</el-button>
                    <el-button v-if="btnShow.stopBtn" class="btn-delete" @click="setBatchStopBtn()">停用</el-button>
                </div>
			</div>
			<el-table :data="listData"  @selection-change="handleSelectionChange">
                <el-table-column type="selection" width="55"/>
				<el-table-column label="渠道标签" prop="chla_name" align="center" min-width/>
                <el-table-column label="渠道数量" prop="chla_channel_quantity" align="center" min-width/>
                <el-table-column label="状态" prop="oplo_module" align="center" min-width>
                    <template slot-scope="scope">
                        <span v-if="scope.row.chla_state">{{ stateSelectInfo[scope.row.chla_state-1].name }}</span>
                    </template>    
                </el-table-column>
                <el-table-column label="操作" prop="oplo_module" align="center" min-width>
                     <template slot-scope="scope">
                        <div class="opr-btn-box">
                        <el-button type="primary" v-if="btnShow.editBtn" @click="editRow(scope.row)">编辑</el-button>
                        <el-button v-if="scope.row.chla_state == 2 && btnShow.startBtn" class="btn-staCol" @click="enableThisClas(scope.row,1)">启用</el-button>
                        <el-button v-if="scope.row.chla_state == 1 && btnShow.stopBtn" class="btn-delete" @click="enableThisClas(scope.row,2)">停用</el-button>
                        </div>
                    </template>
                    </el-table-column>
			</el-table>
			<div v-if="listData.length>0" class="mainPageTurningBox">
				<el-pagination :current-page="currentPage" :page-size="pageSize" :total="totalNum" layout="total, prev, pager, next, jumper" background @current-change="handleCurrentChange"/>
			</div>
		</el-row>
        <!-- 新增/编辑 -->
        <el-dialog :visible.sync="dialog.show" :title="dialog.title" :width="dialog.width" :close-on-click-modal="false" @close="resetForm('formdialog')">
            <el-form ref="formdialog" :model="formdialog" :rules="formRules" label-width="120px">
                <el-form-item label="渠道标签" prop="chla_name">
                    <el-input v-model="formdialog.chla_name" placeholder="请输入标签" maxlength="10" clearable class="mainIptSelBox"/>
                </el-form-item>
            </el-form>
            <span slot="footer">
				<el-button @click="dialog.show = false">取 消</el-button>
				<el-button type="primary" @click="SubmitBtn('formdialog')">提 交</el-button>
			</span>
        </el-dialog>
    </div>
</template>
<script>
import { channelLabelsList,chlastop,chlastart,chlaedit,chlaadd } from '@/api/channel'
import { errorStatus } from '@/utils/index'
export default {
    name: 'ChannelLabelsindex',
    data(){
        return{
            listData:[],//列表
            currentPage:1,
            pageSize:"",
            totalNum:"",
            // 搜索表单
            formList: {
                chla_name: '',
                chla_state: '',
            },
            // 状态
			stateSelectInfo: [
				{ id: 1, name: '启用' },
				{ id: 2, name: '停用' }
			],
            formdialog:{
                chla_id:"",
                chla_name:"",
            },
            formRules:{
                chla_name: [
                    { required: true, message: '请输入标签', trigger: 'blur' }
                ],
            },
            dialog:{
                title:"",
                show:false,
                width:"400px"
            },
            chosed:[],
            // 按钮权限
            btnShow:{
                addBtn:false,
                editBtn:false,
                startBtn:false,
                stopBtn:false,
            },
        }
    },
    created(){
        this.getPageInfo();
    },
    methods:{
        // 列表
        getPageInfo(){
            const  loading = this.$loading({
                lock: true,
                text: 'Loading',
                spinner: 'el-icon-loading',
                background: 'rgba(0, 0, 0, 0.7)'
            })
            const datadd = this.formList;
            datadd.page = this.currentPage;
            datadd.pri_id = this.$route.meta.pri_id// 传入按钮id
            channelLabelsList(datadd).then(response=>{
                loading.close();
                const dataRep = response.data
                if (errorStatus(dataRep)) {
                    this.listData = dataRep.data.data
                    this.currentPage = dataRep.data.current_page
                    this.pageSize = dataRep.data.current_number
                    this.totalNum = dataRep.data.total
                    const btnList = dataRep.list_button
                    for (const i in btnList) {
                        if (btnList[i].pri_method_name === '新增') {
                           this.btnShow.addBtn = true;
                        }  else if (btnList[i].pri_method_name === '编辑') {
                            this.btnShow.editBtn = true;
                        } else if (btnList[i].pri_method_name === '启用') {
                            this.btnShow.startBtn = true;
                        } else if (btnList[i].pri_method_name === '停用') {
                            this.btnShow.stopBtn = true;
                        }
                    }
                }
            }).catch(err=>{

            })
        },
        // 搜索
		searchList(formName) {
			this.currentPage = 1
			this.getPageInfo()
		},
        // 重置
        resetForm(formName) {
            this.$refs[formName].resetFields();
        },
        // 页面--分页器
		handleCurrentChange(val) {
			// console.log(`当前页: ${val}`)
			this.currentPage = val
			this.getPageInfo()
		},
        // 启用/停用
        enableThisClas(row, num) {
            const data = {}
            data.chla_id = [row.chla_id]
            if (num === 1) {
                // 启用
                chlastart(data)
                .then(response => {
                    if (errorStatus(response.data)) {
                    this.$message.success('启用成功!')
                    row.chla_state = num
                    }
                })
                .catch(Error => {
                    this.$message.error('请求失败!')
                })
            } else if (num === 2) {
                // 停用
                chlastop(data)
                .then(response => {
                    if (errorStatus(response.data)) {
                    this.$message.success('停用成功!')
                    row.chla_state = num
                    }
                })
                .catch(Error => {
                    this.$message.error('请求失败!')
                })
            }
        },
        // 批量启用
        setBatchEnableBtn() {
            if (this.chosed.length == 0) {
                this.$message.error('请选择要启用的渠道标签!')
                return false;
            }
            const chlaId = [];
            for (const i in this.chosed) {
                if (this.chosed[i].chla_state === 2) {
                    chlaId.push(this.chosed[i].chla_id)
                }
            }
            if(chlaId.length == 0){
                this.$message.warning('您选中的标签全部为“启用”状态，无需更改!')
				return false;
            }
            const data = {}
            data.chla_id = chlaId
            this.$confirm('请确认,是否启用选中的渠道标签?', '提示', {
                confirmButtonText: '确定',
                cancelButtonText: '取消',
                type: 'warning'
            }).then(() => {
                chlastart(data).then(response => {
                    const dataRep = response.data
                    if (errorStatus(dataRep)) {
                        this.$message.success(dataRep.data);
                        this.getPageInfo();
                    }
                })
                .catch(err => {
                    this.$message.error('启用请求失败!')
                })
            })
            .catch(() => {
                // console.log("取消停用");
            })
        },
        // 批量停用
        setBatchStopBtn() {
            if (this.chosed.length == 0) {
                this.$message.error('请选择要停用的渠道标签!');
                return false;
            }
            const chlaId = [];
            for (const i in this.chosed) {
                if (this.chosed[i].chla_state === 1) {
                    chlaId.push(this.chosed[i].chla_id)
                }
            }
            if(chlaId.length == 0){
                this.$message.warning('您选中的标签全部为“停用”状态，无需更改!')
				return false;
            }
            const data = {}
            data.chla_id = chlaId
            this.$confirm('请确认,是否停用选中渠道标签?', '提示', {
                confirmButtonText: '确定',
                cancelButtonText: '取消',
                type: 'warning'
            }).then(() => {
                chlastop(data).then(response => {
                    const dataRep = response.data
                    if (errorStatus(dataRep)) {
                        this.$message.success(dataRep.data);
                        this.getPageInfo();
                    }
                })
                .catch(err => {
                    this.$message.error('停用请求失败!')
                })
            })
            .catch(() => {
            // console.log("取消停用");
            })
        },
        // 选中状态
        handleSelectionChange(val) {
            this.chosed = val
        },
        // 新增-打开
        addChannelBtn(){
            this.dialog.title = '新增';
            this.dialog.show = true;
            this.dialog.width = '400px'
        },
        // 编辑-打开
        editRow(row){
            this.dialog.title = '编辑';
            this.dialog.show = true;
            this.dialog.width = '400px'
            this.formdialog.chla_id = row.chla_id;
            this.formdialog.chla_name = row.chla_name;
        },
        // 提交-新增/编辑
        SubmitBtn(formName){
            this.$refs[formName].validate((valid) => {
                if(valid){
                    const datta = {
                        chla_name:this.formdialog.chla_name,
                        chla_id:this.formdialog.chla_id
                    }
                    if(this.dialog.title == '新增'){
                        chlaadd(datta).then(success=>{
                            if(success.data.code == 200){
                                this.$message.success(success.data.data)
                                this.dialog.show = false;
                                this.getPageInfo();
                            }else{
                                this.$message.error(success.data.data)
                            }
                        }).catch(err=>{
                            this.$message.error('新增失败！请重新添加')
                        })
                    }else{
                        chlaedit(datta).then(success=>{
                            if(success.data.code == 200){
                                this.$message.success(success.data.data)
                                this.dialog.show = false;
                                this.getPageInfo();
                            }else{
                                this.$message.error(success.data.data)
                            }
                        }).catch(err=>{
                            this.$message.error('编辑失败！请重新添加')
                        })
                    }
                }
            })
        },
    }

}
</script>