<template>
	<div>
		<!-- 信息筛选 -->
		<el-row class="mainContentItemBox">
			<div class="mainHeaderTitleBox">
				<div class="titleNameBox">信息筛选</div>
				<div class="buttonBox"></div>
			</div>
			<el-form ref="formList" :model="formList" size="medium" label-width="100px" class="mainSearchItemBox">
				<el-row>
					<el-col :span="6">
						<el-form-item label="渠道名称:" prop="chan_unit_name">
							<el-input v-model="formList.chan_unit_name" placeholder="请输入渠道名称" clearable class="mainIptSelBox"/>
						</el-form-item>
					</el-col>
					<el-col :span="6">
						<el-form-item label="联系人:" prop="chan_name">
							<el-input v-model="formList.chan_name" placeholder="请输入联系人" clearable class="mainIptSelBox"/>
						</el-form-item>
					</el-col>
					<el-col :span="6">
						<el-form-item label="联系电话:" prop="chan_phone">
							<el-input v-model="formList.chan_phone" placeholder="请输入电话" clearable class="mainIptSelBox"/>
						</el-form-item>
					</el-col>
					<el-col :span="6">
						<el-form-item label="身份ID:" prop="chan_bound_id">
							<el-input v-model="formList.chan_bound_id" placeholder="请输入身份ID" clearable class="mainIptSelBox"/>
						</el-form-item>
					</el-col>
					<el-col :span="6">
						<el-form-item label="用户名:" prop="chan_account">
							<el-input v-model="formList.chan_account" placeholder="请输入用户名" clearable class="mainIptSelBox"/>
						</el-form-item>
					</el-col>
					<el-col :span="6">
						<el-form-item label="渠道标签:" prop="chan_chla_id">
							<el-select v-model="formList.chan_chla_id" placeholder="请选择标签"  @click.native ="getChannelLabel('',1)" clearable filterable  :multiple="false" remote :remote-method="(query)=>{getChannelLabel(query,1)}" class="mainIptSelBox">
								<el-option v-for="item in channelLabelInfo" :key="item.chla_id" :label="item.chla_name" :value="item.chla_id"/>
							</el-select>
						</el-form-item>
					</el-col>
					<el-col :span="6">
						<el-form-item label="签约补货:" prop="chan_replenishment_state">
							<el-select v-model="formList.chan_replenishment_state" placeholder="请选择" clearable class="mainIptSelBox" >
								<el-option label="开启" value="1"/>
								<el-option label="关闭" value="2"/>
							</el-select>
						</el-form-item>
					</el-col>   
					<el-col :span="6">
						<el-form-item label="门店运营:" prop="chan_shop_state">
							<el-select v-model="formList.chan_shop_state" placeholder="请选择" clearable  class="mainIptSelBox">
								<el-option label="开启" value="1"/>
								<el-option label="关闭" value="2"/>
							</el-select>
						</el-form-item>
					</el-col>
					<el-col :span="6">
						<el-form-item label="状态:" prop="chan_state">
							<el-select v-model="formList.chan_state" placeholder="请选择状态" clearable  class="mainIptSelBox">
								<el-option v-for="item in stateList" :key="item.id" :label="item.value" :value="item.id"/>
							</el-select>
						</el-form-item>
					</el-col>
					<el-col :span="6">
						<el-button type="primary" @click="getSearchListBtn('formList')">搜&nbsp;&nbsp;索</el-button>
						<el-button @click="resetForm('formList')">重&nbsp;&nbsp;置</el-button>
					</el-col>
				</el-row>
			</el-form>
		</el-row>
		<!-- 列表 -->
		<el-row class="mainContentItemBox">
			<div class="mainHeaderTitleBox">
				<div class="titleNameBox">渠道列表</div>
				<div class="buttonBox">
					<el-button type="primary" v-if="btnShow.addBtn" @click="addChannelBtn()">新增</el-button>
					<el-button v-if="btnShow.startBtn" class="btn-staCol" @click="setBatchEnableBtn()">启用</el-button>
					<el-button v-if="btnShow.stopBtn" class="btn-delete" @click="setBatchStopBtn()">停用</el-button>
				</div>
			</div>
			<el-table :data="listData"  @selection-change="handleSelectionChange">
				<el-table-column type="selection" width="55"></el-table-column>
				<el-table-column label="用户名" prop="chan_account" align="center" min-width='100'></el-table-column>
				<el-table-column label="渠道信息" align="left" header-align="center" min-width='250'>
					<template slot-scope="scope">
						<div>单位名称：{{scope.row.chan_unit_name}}</div>
						<div>身份ID：{{scope.row.chan_bound_id}}</div>
						<div>联系人：{{scope.row.chan_name}}</div>
						<div>联系电话：{{scope.row.chan_phone}}</div>
						<div>联系地址：{{scope.row.chan_province+scope.row.chan_city+scope.row.chan_county+scope.row.chan_address}}</div>
					</template>
				</el-table-column>
				<el-table-column label="渠道标签"  align="center" prop='chla_name' min-width ></el-table-column>
				<el-table-column label="上级渠道"  align="center" prop='' min-width>
					<template slot-scope="scope">
						<span v-if="scope.row.chan_parent_id === 0">顶级渠道商</span>
						<span v-else>{{ scope.row.parent_unit_name }}</span>
					</template>
				</el-table-column>
				<el-table-column label="签约补货"  align="center" >
					<template slot-scope="scope">
						<div :class="scope.row.chan_replenishment_state == 1 ? 'green' : 'red'">
							{{scope.row.chan_replenishment_state == 1 ? '开启' : '关闭' }}
						</div>
					</template>
				</el-table-column>
				<el-table-column label="门店运营" align="center" >
					<template slot-scope="scope">
						<div :class="scope.row.chan_shop_state == 1 ? 'green' : 'red'">
							{{scope.row.chan_shop_state == 1 ? '开启' : '关闭' }}
						</div>
					</template>
				</el-table-column> 
				<el-table-column label="状态" align="center" >
					<template slot-scope="scope">
						<div :class="scope.row.chan_state==1?'green':'red'">
							{{scope.row.chan_state==1?'启用':'停用'}}
						</div>
					</template>
				</el-table-column>			   
				<el-table-column label="操作" prop="" align="center">
					<template slot-scope="scope">
						<div class="mainOperationBtnBox">
							<el-button type="primary" v-if="btnShow.editBtn" @click="setEditBtn(scope.row)">编辑渠道</el-button>
							<el-button v-if="scope.row.chan_state==2&&btnShow.startBtn" class="btn-staCol" @click="enableThisClas(scope.row,1)">启用渠道</el-button>
							<el-button v-if="scope.row.chan_state==1&&btnShow.stopBtn" class="btn-delete" @click="enableThisClas(scope.row,2)">停用渠道</el-button>
							<el-button v-if="btnShow.resetpassBtn" class="btn-delete" @click="resetpassword(scope.row)">重置密码</el-button>
							<el-button v-if="btnShow.deleteBtn" class="btn-delete" @click="setDeleteBtn(scope.row)">删除渠道</el-button>
						</div>
					</template>
				</el-table-column>
			</el-table>
			<div v-if="listData.length>0" class="mainPageTurningBox">
				<el-pagination :current-page="currentPage" :page-size="pageSize" :total="totalNum" layout="total, prev, pager, next, jumper" background @current-change="handleCurrentChange"/>
			</div>
		</el-row>
		<!-- 新增 -->
		<el-dialog :visible.sync="addDialog.show" :title="addDialog.title" :width="addDialog.width" :close-on-click-modal="false" @close="resetForm('addForm')">
			<el-form label-width="120px" ref="addForm" :model="addForm" :rules="formRules">
				<el-form-item label="上级渠道:" prop="chan_parent_id" >
					<el-select v-model="addForm.chan_parent_id" placeholder="请选择渠道" @click.native ="getChannel('',1)" clearable filterable  :multiple="false" remote :remote-method="(query)=>{getChannel(query,1)}" class="mainIptSelBox">
						<el-option label="顶级渠道商" value="0"/>
                        <el-option v-for="item in channelList" :key="item.chan_id" :label="item.chan_unit_name" :value="item.chan_id"/>
					</el-select>
				</el-form-item>
				<el-form-item label="渠道标签:" prop="chan_chla_id">
					<el-select v-model="addForm.chan_chla_id" placeholder="请选择标签" @click.native ="getChannelLabel('',1)" clearable filterable  :multiple="false" remote :remote-method="(query)=>{getChannelLabel(query,1)}" class="mainIptSelBox">
						<el-option v-for="item in channelLabelInfo" :key="item.chla_id" :label="item.chla_name" :value="item.chla_id"/>
					</el-select>
				</el-form-item>
				<el-form-item label="单位名称:" prop="chan_unit_name">
					<el-input v-model="addForm.chan_unit_name" placeholder="请输入单位名称" maxlength="20" clearable class="mainIptSelBox"/>
				</el-form-item>
				<el-form-item label="用户名:" prop="adm_account" class="mainFormSeeInfoBox">
					{{ addForm.adm_account }}
				</el-form-item>
				<el-form-item label="初始密码:" prop="adm_account" >
					111111
				</el-form-item>
				<el-form-item label="联系姓名:" prop="chan_name">
					<el-input v-model="addForm.chan_name" placeholder="请输入姓名" maxlength="4" clearable class="mainIptSelBox"/>
				</el-form-item>
				<el-form-item label="联系电话:" prop="chan_phone">
					<el-input v-model="addForm.chan_phone" placeholder="请输入联系电话" @change="setPhoneValidate" maxlength="11" clearable class="mainIptSelBox"/>
				</el-form-item>
				<el-form-item label="地址区域:" prop="address">
					<el-cascader placeholder="请选择省市区" v-model="addForm.address" ref="citydataes" :options="CityInfo" clearable @change="censusLandChange" class="mainIptSelBox"></el-cascader>
				</el-form-item>
				<el-form-item label="详细地址:" prop="chan_address">
					<el-input v-model="addForm.chan_address" placeholder="请输入详细地址" clearable class="mainIptSelBox"/>
				</el-form-item>
				<el-form-item label="选择类型:" prop="">
					<el-form-item prop="chan_replenishment_state" class="mainFormInlineBox">
						<el-switch v-model="addForm.chan_replenishment_state" active-value="1" inactive-value="2" active-text="签约补货" @change="onChangeChanStateBtn"></el-switch> 
					</el-form-item>
					<el-form-item prop="chan_shop_state" class="mainFormInlineBox">
						<el-switch v-model="addForm.chan_shop_state" active-value="1" inactive-value="2" active-text="门店运营"></el-switch>
					</el-form-item>
					<div class="red">至少选择一项</div>
				</el-form-item>
				<el-form-item label="绑定身份ID:" v-if="addForm.chan_replenishment_state == 1" prop="chan_bound_id">
					<el-input v-model="addForm.chan_bound_id" placeholder="请输入绑定身份ID" clearable @input="onInputChanIdBtn" class="mainIptSelBox"><el-button slot="append" @click="verificationIdBtn">{{ verificationDialog.btnName }}</el-button></el-input>
				</el-form-item>
			</el-form>
			<span slot="footer">
				<el-button @click="addDialog.show = false">取 消</el-button>
				<el-button type="primary" @click="setAddSubmitBtn('addForm')">提 交</el-button>
			</span>
		</el-dialog>
		<!-- 新增-绑定身份ID验证 -->
		<el-dialog :visible.sync="verificationDialog.show" :title="verificationDialog.title" :width="verificationDialog.width" :close-on-click-modal="false" @close="resetForm('verificationFormData')">
			<el-form label-width="100px" ref="verificationFormData" :model="verificationFormData" :rules="formRules">
				<el-form-item label="门店名称:" class="mainFormSeeInfoBox">
					{{ verificationFormData.company_name }}
				</el-form-item>
				<el-form-item label="门店类型:" class="mainFormSeeInfoBox">
					{{ verificationFormData.is_lidao }}
				</el-form-item>
				<el-form-item label="负责人姓名:" class="mainFormSeeInfoBox">
					{{ verificationFormData.admin_acc }}
				</el-form-item>
				<el-form-item label="门店地址:" class="mainFormSeeInfoBox">
					{{ verificationFormData.admin_dress }}
				</el-form-item>
			</el-form>
			<span slot="footer">
				<el-button type="primary" @click="setVerificationSubmitBtn('verificationFormData')">核实</el-button>
			</span>
		</el-dialog>
		<!-- 编辑 -->
		<el-dialog :visible.sync="editDialog.show" :title="editDialog.title" :width="editDialog.width" :close-on-click-modal="false" @close="resetForm('editForm')">
			<el-form label-width="120px" ref="editForm" :model="editForm" :rules="formRules">
				<el-form-item label="上级渠道:" prop="chan_parent_id" >
					<el-select v-model="editForm.chan_parent_id" placeholder="请选择渠道" @click.native ="getChannel('',1)" clearable filterable  :multiple="false" remote :remote-method="(query)=>{getChannel(query,1)}" class="mainIptSelBox">
						<el-option label="顶级渠道商" value="0"/>
                        <el-option v-for="item in channelList" :key="item.chan_id" :label="item.chan_unit_name" :value="item.chan_id"/>
					</el-select>
				</el-form-item>
				<el-form-item label="渠道标签:" prop="chan_chla_id">
					<el-select v-model="editForm.chan_chla_id" placeholder="请选择标签" @click.native ="getChannelLabel('',1)" clearable filterable  :multiple="false" remote :remote-method="(query)=>{getChannelLabel(query,1)}" class="mainIptSelBox">
						<el-option v-for="item in channelLabelInfo" :key="item.chla_id" :label="item.chla_name" :value="item.chla_id"/>
					</el-select>
				</el-form-item>
				<el-form-item label="单位名称:" prop="chan_unit_name">
					<el-input v-model="editForm.chan_unit_name" placeholder="请输入单位名称" maxlength="20" clearable class="mainIptSelBox"/>
				</el-form-item>
				<el-form-item label="用户名:" prop="chan_account" required>
					{{ editForm.chan_account }}
				</el-form-item>
				<el-form-item label="联系姓名:" prop="chan_name">
					<el-input v-model="editForm.chan_name" placeholder="请输入姓名" maxlength="4" clearable class="mainIptSelBox"/>
				</el-form-item>
				<el-form-item label="联系电话:" prop="chan_phone">
					<el-input v-model="editForm.chan_phone" placeholder="请输入联系电话" @change="setPhoneValidate" maxlength="11" clearable class="mainIptSelBox"/>
				</el-form-item>
				<el-form-item label="地址区域:" prop="address">
					<el-cascader placeholder="请选择省市区" filterable v-model="editForm.address" ref="citydataes" :options="CityInfo" clearable @change="censusLandChange" class="mainIptSelBox"></el-cascader>
				</el-form-item>
				<el-form-item label="详细地址:" prop="chan_address">
					<el-input v-model="editForm.chan_address" placeholder="请输入详细地址" clearable class="mainIptSelBox"/>
				</el-form-item>
				<el-form-item label="选择类型:" prop="">
					<el-form-item prop="chan_replenishment_state" class="mainFormInlineBox">
						<el-switch v-model="editForm.chan_replenishment_state" active-value="1" inactive-value="2" active-text="签约补货"></el-switch> 
					</el-form-item>
					<el-form-item prop="chan_shop_state" class="mainFormInlineBox">
						<el-switch v-model="editForm.chan_shop_state" active-value="1" inactive-value="2" active-text="门店运营"></el-switch>
					</el-form-item>
					<div class="red">至少选择一项</div>
				</el-form-item>
			</el-form>
			<span slot="footer">
				<el-button @click="editDialog.show = false">取 消</el-button>
				<el-button type="primary" @click="setEditSubmitBtn('editForm')">提 交</el-button>
			</span>
		</el-dialog>
	</div>
</template>
<script>
import { errorStatus } from '@/utils/index'
import { getChannelLabel,getChannelInfo} from "@/api/commonAction";
import {ChannelLists_index,chlaListstop,chlaListstart,chlaListdelete,chlaListresetPassword,chlaListadd,chlaListedit,verifyInformation } from '@/api/channel'
import { phoneTest } from '@/utils/validate'
export default {
	name: 'ChannelLabelsindex',
	data(){
		const bodutype = (rule, value, callback) => {
			if(this.addForm.chan_replenishment_state == 1){
				if(this.editForm.chan_id == ''){
					return false
				}else{
					return true
				}
			}else{
				return false
			}
		}
		return{
			listData:[],//列表
			CityInfo:CityInfo,
			channelList:[],//渠道List
			currentPage:1,
			pageSize:"",
			totalNum:"",
			channelLabelInfo:[],//渠道标签
			// 搜索表单
			formList: {
				chan_unit_name: '',
				chan_state: '',
				chan_name:"",
				chan_phone:"",
				chan_bound_id:"",
				chan_account:"",
				chan_chla_id:"",
				chan_replenishment_state:"",
				chan_shop_state:"",
			},
			// 状态
			stateList:[
				{id:1,value:"启用"},
				{id:2,value:"停用"},
			],
			// 新增-表单
			addForm:{
				chan_unit_name:"",
				chan_name:"",
				chan_phone:"",
				adm_account:"",
				chan_parent_id:"",
				chan_chla_id:"",
				address:[],
				chan_province:"",
				chan_city:"",
				chan_county:"",
				chan_address:'',
				chan_replenishment_state:"2",
				chan_bound_id:"",
				chan_shop_state:"2",
			},
			// 新增-表单验证
			formRules:{
				chan_parent_id: [
					{ required: true, message: '请选择上级渠道', trigger: 'change' }
				],
				chan_unit_name: [
					{ required: true, message: '请输入单位名称', trigger: 'blur' }
				],
				chan_chla_id: [
					{ required: true, message: '请选择渠道标签',  trigger: 'change' }
				],
				address: [
					{ required: true, message: '请选择地址区域', trigger: 'blur' }
				],	
				chan_name: [
					{ required: true, message: '请输入联系人名字', trigger: 'blur' }
				],
				chan_address: [
					{ required: true, message: '请输入详细地址', trigger: 'blur' }
				],
				chan_bound_id:[
					{ required: bodutype, message: '请输入绑定身份ID', trigger: 'blur' }
				],
			},
			// 新增-弹框
			addDialog:{
				title:"新增",
				show:false,
				width:"500px"
			},
			// 新增-绑定身份ID验证
			verificationDialog:{
				title:"门店信息",
				show:false,
				width:"500px",
				btnName:'验证'
			},
			verificationFormData:{},// 新增-验证返回信息
			verifyState:true,//身份ID验证是否通过
			// 编辑-表单
			editForm:{
				chan_id:'',
				chan_unit_name:"",
				chan_name:"",
				chan_phone:"",
				chan_account:"",
				chan_parent_id:"",
				chan_chla_id:"",
				address:[],
				chan_province:"",
				chan_city:"",
				chan_county:"",
				chan_address:'',
				chan_replenishment_state:"",
				chan_shop_state:"",
			},
			// 编辑 弹框
			editDialog:{
				title:"编辑",
				show:false,
				width:"500px"
			},
            chosed:[],//列表多选
            // 按钮权限
            btnShow:{
                addBtn:false,
                editBtn:false,
                startBtn:false,
                stopBtn:false,
                deleteBtn:false,
                resetpassBtn:false,
            },
		}
	},
	created(){
		this.getPageInfo();
	},
	methods:{
        // 列表
		getPageInfo(){
			const  loading = this.$loading({
				lock: true,
				text: 'Loading',
				spinner: 'el-icon-loading',
				background: 'rgba(0, 0, 0, 0.7)'
			})
			const datadd = this.formList;
			datadd.page = this.currentPage;
			datadd.pri_id = this.$route.meta.pri_id// 传入按钮id
			ChannelLists_index(datadd).then(response=>{
				loading.close();
				const dataRep = response.data
				if (errorStatus(dataRep)) {
					this.listData = dataRep.data.data
					this.currentPage = dataRep.data.current_page
					this.pageSize = dataRep.data.current_number
					this.totalNum = dataRep.data.total
					const btnList = dataRep.list_button
					for (const i in btnList) {
						if (btnList[i].pri_method_name === '新增') {
							this.btnShow.addBtn = true;
						}  else if (btnList[i].pri_method_name === '编辑') {
                            this.btnShow.editBtn = true;
						} else if (btnList[i].pri_method_name === '启用') {
                            this.btnShow.startBtn = true;
						} else if (btnList[i].pri_method_name === '停用') {
                            this.btnShow.stopBtn = true;
						} else if(btnList[i].pri_method_name === '删除') {
                            this.btnShow.deleteBtn = true;
						} else if(btnList[i].pri_method_name === '重置密码'){
                            this.btnShow.resetpassBtn = true;
						}
					}
				}
			}).catch(err=>{
				loading.close();
			})
        },
        // 选择省市区县
		censusLandChange(val){
			if(val.length != 0){
				this.addForm.chan_county = this.$refs['citydataes'].getCheckedNodes()[0].label;
				this.addForm.chan_city = this.$refs['citydataes'].getCheckedNodes()[0].parent.label;
				this.addForm.chan_province = this.$refs['citydataes'].getCheckedNodes()[0].parent.parent.label;
			}else{
				this.addForm.chan_county = '';
				this.addForm.chan_city = '';
				this.addForm.chan_province = '';
			}
		},
		// 重置
		resetForm(formName) {
			this.$refs[formName].resetFields();
		},
		// 获取渠道标签
		getChannelLabel(query,type,Id) {
			const data = {}
			data.app_role = type
			if(query){
				data.search_data =query
			}
			getChannelLabel(data).then(response => {
				const dataRep = response.data;
				if(errorStatus(dataRep)){
					this.channelLabelInfo = dataRep.data.data
				}
			})
		},
		// 获取渠道
		getChannel(query,type,Id) {
			const data = {}
			data.app_role = type
			if(query){
				data.search_data =query
			}
			getChannelInfo(data).then(response => {
				if(errorStatus(response.data)){
					this.channelList = response.data.data.data
				}
			})
		},
        // 搜索
		getSearchListBtn(formName) {
			this.currentPage = 1
			this.getPageInfo()
		},
        // 页面--分页器
		handleCurrentChange(val) {
			// console.log(`当前页: ${val}`)
			this.currentPage = val
			this.getPageInfo()
		},
		// 删除
		setDeleteBtn(row){
			this.$confirm('请确认,是否删除此条渠道?', '提示', {
				confirmButtonText: '确定',
				cancelButtonText: '取消',
				type: 'warning'
			}).then(()=>{
				const datadd= {
					chan_id:row.chan_id
				}
				chlaListdelete(datadd).then(response=>{
					const dataRep = response.data;
					if (errorStatus(dataRep)) {
						this.$message.success(dataRep.data);
                        this.getPageInfo();
					}
				}).catch(err=>{
					this.$message.error('删除失败，请重试')
				})
			}).catch(()=>{
				this.$message.info('已取消删除')
			})
		},
		// 重置密码
		resetpassword(row){
			this.$confirm('请确认,是否重置此条渠道的密码?', '提示', {
				confirmButtonText: '确定',
				cancelButtonText: '取消',
				type: 'warning'
			}).then(()=>{
				const datadd= {
					chan_id:row.chan_id
				}
				chlaListresetPassword(datadd).then(response=>{
					const dataRep = response.data;
					if (errorStatus(dataRep)) {
						this.$message.success(dataRep.data)
					}
				}).catch(err=>{
					this.$message.error('密码重置失败，请重试')
				})
			}).catch(()=>{
				// this.$message.warning('已取消删除')
			})
		},
		// 启用/停用
		enableThisClas(row, num) {
			const data = {}
			data.chan_id = [row.chan_id]
			if (num === 1) {
				// 启用
				chlaListstart(data).then(response => {
					const dataRep = response.data;
					if (errorStatus(dataRep)) {
						this.$message.success('启用成功!')
						row.chan_state = num
					}
				})
				.catch(Error => {
					this.$message.error('请求失败!')
				})
			} else if (num === 2) {
				// 停用
				chlaListstop(data).then(response => {
					const dataRep = response.data;
					if (errorStatus(dataRep)) {
						this.$message.success('停用成功!')
						row.chan_state = num
					}
				})
				.catch(Error => {
					this.$message.error('请求失败!')
				})
			}
		},
		// 批量启用
		setBatchEnableBtn() {
			if (this.chosed.length < 1) {
				this.$message.warning('请选择要启用的渠道商!');
				return false;
			}
			const chanId = []
			for (const i in this.chosed) {
				if (this.chosed[i].chan_state === 2) {
					chanId.push(this.chosed[i].chan_id)
				}
			}
			if(chanId.length == 0){
                this.$message.warning('您选中的渠道商全部为“启用”状态，无需更改!')
				return false;
            }
			const data = {}
			data.chan_id = chanId
			this.$confirm('请确认,是否启用选中的渠道商?', '提示', {
				confirmButtonText: '确定',
				cancelButtonText: '取消',
				type: 'warning'
			}).then(() => {
				chlaListstart(data).then(response => {
					const dataRep = response.data;
					if (errorStatus(dataRep)) {
						this.$message.success(dataRep.data);
                        this.getPageInfo();
					}
				})
				.catch(err => {
					this.$message.error('启用请求失败!')
				})
			})
			.catch(() => {
				// console.log("取消停用");
			})
		},
		// 批量停用
		setBatchStopBtn() {
			if (this.chosed.length < 1) {
				this.$message.warning('请选择要停用的渠道商!');
				return false;
			}
			const chanId = []
			for (const i in this.chosed) {
				if (this.chosed[i].chan_state === 1) {
					chanId.push(chosed[i].chan_id)
				}
			}
			if(chanId.length == 0){
                this.$message.warning('您选中的渠道商全部为“停用”状态，无需更改!')
				return false;
            }
			const data = {}
			data.chan_id = id
			this.$confirm('请确认,是否停用选中渠道商?', '提示', {
				confirmButtonText: '确定',
				cancelButtonText: '取消',
				type: 'warning'
			}).then(() => {
				chlaListstop(data).then(response => {
					const dataRep = response.data;
					if (errorStatus(dataRep)) {
						this.$message.success(dataRep.data);
                        this.getPageInfo();
					}
				})
				.catch(err => {
					this.$message.error('停用请求失败!')
				})
			})
			.catch(() => {
				// console.log("取消停用");
			})
		},
		// 选中状态
		handleSelectionChange(val) {
			this.chosed = val
		},
		// 生成10位随机数，用户名使用
		setRandomNumber(){
			var code = "";
			for(var i = 1;i <= 10;i++){
				const num = Math.floor(Math.random()*10);
				code += num;
			}
			this.addForm.adm_account = code;
		},
		// 新增-打开
		addChannelBtn(){
			this.setRandomNumber();// 用户名，随机生成10位数
			this.verifyState = true;
			this.verificationDialog.btnName = '验证';
			this.addDialog.show = true;
		},
		// 新增-提交
		setAddSubmitBtn(formName){
			this.$refs[formName].validate((valid) => {
				if(valid){
					if(this.addForm.address.length == 0){
						this.$message.warning('请选择地址区域！')
						return false
					}
					if(this.addForm.chan_replenishment_state == 2 && this.addForm.chan_shop_state == 2){
						this.$message.warning('签约补货和门店运营，至少选择一项');
						return false
					}
					if(this.addForm.chan_bound_id != '' && this.verifyState){
						this.$message.warning('绑定身份ID未验证');
						return false
					}
					const data = {...this.addForm};
					chlaListadd(data).then(response=>{
						const dataRep = response.data;
						if (errorStatus(dataRep)) {
							if(dataRep.code == 501){
								this.$message.warning("用户名已存在，已为您重新生成用户名，请重新提交！");
								this.setRandomNumber();
							}else{
								this.$message.success(dataRep.data);
								this.addDialog.show = false;
								this.getPageInfo();
							}
						}
					}).catch(err=>{
						this.$message.error('新增失败！请重新添加')
					})
				}
			})
		},
		// 新增-绑定身份ID验证
		verificationIdBtn(val){
			if(this.addForm.chan_bound_id == ''){
				this.$message.warning('请填写绑定身份ID！')
				return false
			}
			const data = {};
			data.ser_id = this.addForm.chan_bound_id
			verifyInformation(data).then(response=>{
				const dataRep = response.data;
				if (errorStatus(dataRep)) {
					this.verificationFormData = dataRep.data
					this.verificationDialog.show = true;
				}
			}).catch(err=>{
				this.$message.error('身份ID匹配失败！')
			})
		},
		// 新增-验证通过
		setVerificationSubmitBtn(){
			this.verifyState = false;
			this.verificationDialog.btnName = '已验证'
			this.verificationDialog.show = false;
		},
		// 新增-更改选择类型
		onChangeChanStateBtn(val){
			if(val == 2){
				this.addForm.chan_bound_id = ''
				this.verifyState = true;
				this.verificationDialog.btnName = '验证';
			}
		},
		// 新增-绑定身份ID更改
		onInputChanIdBtn(){
			this.verifyState = true;
			this.verificationDialog.btnName = '验证';
		},
		// 编辑-打开
		setEditBtn(val){
			// console.log(val);
			this.editForm.chan_id = val.chan_id;
			this.editForm.chan_account = val.chan_account;
			this.editForm.chan_unit_name = val.chan_unit_name;
			this.editForm.chan_name = val.chan_name;
			this.editForm.chan_phone = val.chan_phone;
			this.editForm.adm_account = val.chan_account;
			this.editForm.chan_parent_id = val.chan_parent_id;
			var chanName = "";//上级渠道名称 chan_parent_id=0 顶级渠道商
			if(val.chan_parent_id == 0){
				chanName = "顶级渠道商";
			}else{
				chanName = val.parent_unit_name;
			}
			this.channelList = [],//上级渠道
			this.channelList.push({
				chan_id:val.chan_parent_id,
				chan_unit_name:chanName,
			});
			this.editForm.chan_chla_id = val.chan_chla_id;
			this.channelLabelInfo = [],//渠道标签
			this.channelLabelInfo.push({
				chla_id:val.chan_chla_id,
				chla_name:val.chla_name,
			});
			this.editForm.chan_province = val.chan_province;
			this.editForm.chan_city = val.chan_city;
			this.editForm.chan_county = val.chan_county;
			this.editForm.chan_address = val.chan_address;
			this.editForm.chan_replenishment_state = val.chan_replenishment_state+'';
			this.editForm.chan_shop_state = val.chan_shop_state+'';
			// 循环地址区域对联动选择器
			if(val.chan_province != ''){
				for(var i =0; i<this.CityInfo.length;i++){
					if(val.chan_province.indexOf(this.CityInfo[i].label) > -1 || this.CityInfo[i].label.indexOf(val.chan_province) >-1){
						this.editForm.address.push(this.CityInfo[i].value);
						if(val.chan_city != ''){
							if(this.CityInfo[i].children != undefined){
								if(this.CityInfo[i].children.length != 0){
									for(var j=0;j<this.CityInfo[i].children.length;j++){
										if(val.chan_city == this.CityInfo[i].children[j].label){
											this.editForm.address.push(this.CityInfo[i].children[j].value);
											if(val.chan_county != ''){
												if(this.CityInfo[i].children[j].children != undefined){
													if(this.CityInfo[i].children[j].children.length != 0){
														for(var e = 0;e<this.CityInfo[i].children[j].children.length;e++){
															if(val.chan_county== this.CityInfo[i].children[j].children[e].label){
																// this.search.shr_xian = this.CityInfo[i].children[j].children[e].label;
																this.editForm.address.push(this.CityInfo[i].children[j].children[e].value);													
															}
														}
													}
												}
											}
										}
									}
								}
							}
						}
					}
				}
			}
			this.editDialog.show = true;
		},
		// 编辑-提交 
		setEditSubmitBtn(formName){
			this.$refs[formName].validate((valid) => {
				if(valid){
					if(this.editForm.address.length == 0){
						this.$message.warning('请选择地址区域！')
						return false
					}
					if(this.editForm.chan_replenishment_state == 2 && this.editForm.chan_shop_state == 2){
						this.$message.warning('签约补货和门店运营，至少选择一样');
						return false
					}
					const data = {...this.editForm};
					chlaListedit(data).then(response=>{
						const dataRep = response.data;
						if (errorStatus(dataRep)) {
							this.$message.success(dataRep.data);
							this.editDialog.show = false;
							this.getPageInfo();
						}
					}).catch(err=>{
						this.$message.error('编辑失败，请稍后重试！')
					})
				}else{
					// console.log(valid)
				}
			})
		},
		// 验证手机号正确性
		setPhoneValidate(val){
			if(val){
				if(!phoneTest(val)){
					this.addForm.chan_phone = '';
					this.editForm.chan_phone = '';
					this.$message.warning('请输入正确的手机号');
				}
			}
		},
	}
}
</script>
<style scoped>
/* 表单，一行有两个值需要验证prop */
.mainFormInlineBox{display:inline-block;margin-right:20px;}
</style>