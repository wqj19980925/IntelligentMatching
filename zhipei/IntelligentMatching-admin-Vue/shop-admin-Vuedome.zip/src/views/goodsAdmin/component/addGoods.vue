<template>
	<div>
		<el-row class="mainContentItemBox">
			<div class="mainHeaderTitleBox">
				<div class="titleNameBox">{{ title }}商品</div>
				<div class="buttonBox">
					<el-button type="primary" @click="submitInfo('formList')">保&nbsp;&nbsp;存</el-button>
					<el-button @click="back()">返&nbsp;&nbsp;回</el-button>
				</div>
			</div>
			<el-form ref="formList" :model="formList" :rules="formRules" label-width="150px" class="mainSearchItemBox">
				<el-card shadow="never" class="mainCardBorNoneBox">
					<div slot="header">
						<div class="titleNameBox">基本信息</div>
					</div>
					<el-col style="width:340px;">
						<el-col :span="24">
							<div class="mainGoodsUploadImgBox" @click="goodsImgUpBtn" v-if="!formList.goaf_original_img">
								<i class="el-icon-plus"></i>
								<input id="GoodsUploadBtn" type="file" accept="image/*" class="fileTypeBox" @change="onChangeGoodsImgBtn($event)">
							</div>
							<div class="mainGoodsImgBox" v-else>
								<div class="editUploadBox">
									<span>
										<i class="el-icon-delete" @click="goodsImgDelBtn"></i>
									</span>
								</div>
								<img v-if="goodsPicUp" :src="formList.goaf_original_img"/>
								<img v-else :src="baseUrl+formList.goaf_original_img"/>
							</div>
						</el-col>
					</el-col>
					<el-col :span="13">
						<el-col :span="24">
							<el-form-item label="商品名称" prop="goo_name">
								<el-input v-model="formList.goo_name" placeholder="请输入商品名称" :maxlength="20" clearable class="mainIptSelBox"/>
							</el-form-item>
						</el-col>
						<el-col :span="24">
							<el-form-item label="检索编号" prop="goo_goods_encode">
								<el-input v-model="formList.goo_goods_encode" placeholder="请输入检索编号" :maxlength="15" clearable class="mainIptSelBox"/>
							</el-form-item>
						</el-col>
						<el-col :span="24">
							<el-form-item label="商品品类" prop="goo_cate_id">
								<el-select v-model="formList.goo_cate_id" placeholder="请选择商品品类" @click.native="getCategoryDataBtn()" clearable class="mainIptSelBox">
									<el-option v-for="item in classList" :key="item.cate_id" :label="item.cate_name" :value="item.cate_id"/>
								</el-select>
							</el-form-item>
						</el-col>
						<el-col :span="24">
							<el-form-item label="商品品牌" prop="goo_bra_id">
								<el-select v-model="formList.goo_bra_id" placeholder="请选择商品品牌" @click.native="getBrandDataBtn()" clearable class="mainIptSelBox">
									<el-option v-for="item in brandList" :key="item.bra_id" :label="item.bra_name" :value="item.bra_id"/>
								</el-select>
							</el-form-item>
						</el-col>
						<el-col :span="24">
							<el-form-item label="采购价(¥)" prop="goo_purchase_price">
								<el-input type="text" v-model="formList.goo_purchase_price" placeholder="请输入商品采购价" :maxlength="8" @input="IWS_CheckDecimal(2)" clearable class="mainIptSelBox"/>
							</el-form-item>
						</el-col>
						<el-col :span="24">
							<el-form-item label="批发价(¥)" prop="goo_wholesale_price">
								<el-input type="text" v-model="formList.goo_wholesale_price" placeholder="请输入商品批发价" :maxlength="8" @input="IWS_CheckDecimal(1)" clearable class="mainIptSelBox"/>
							</el-form-item>
						</el-col>
					</el-col>
				</el-card>
				<el-card shadow="never" class="mainCardBorNoneBox">
					<div slot="header">
						<div class="titleNameBox">商品属性</div>
					</div>
					<el-row :gutter="24" class="mainGoodsHeaderBox">
						<el-col :span="6" class="titleBox">标题</el-col>
						<el-col :span="9" class="infoBox">内容</el-col>
						<el-col :span="6" class="operateBox">
							<span>上移</span>
							<span>下移</span>
							<span>删除</span>
						</el-col>
					</el-row>
					<el-row :gutter="24" v-for="(item,index) in godsDetail" :key="index" class="mainGoodsInfoBox">
						<el-col :span="6">
							<el-input v-model="item.key" :disabled="item.disabled" :class="item.nothing1?'border-red':''" placeholder="请输入名称,不超过8个字" @blur="blurKey($event,index)" :maxlength="8"/>
						</el-col>
						<el-col :span="9">
							<el-input v-if="!item.showBtn" v-model="item.value" :class="item.nothing2?'border-red':''" placeholder="请输入内容" @blur="blurValue($event,index)" :maxlength="30"/>
						</el-col>
						<el-col :span="6">
							<el-button icon="el-icon-arrow-up" @click="upInfor(index)" />
							<el-button icon="el-icon-arrow-down" @click="downInfor(index)" />
							<el-button :disabled="item.disabled" icon="el-icon-delete" class="btn-delete" @click="deleteInfo(index)"/>
						</el-col>
					</el-row>
					<el-button type="primary" @click="addInfor()">+增加信息项</el-button>
				</el-card>
			</el-form>
		</el-row>
	</div>
</template>
<script>
import { getBrandInfo,getCategoryInfo } from '@/api/commonAction'
import { addGoods,editGoods } from "@/api/goods";
import { errorStatus } from "@/utils/index";
import { phoneTest,validateURL } from "@/utils/validate";
export default {
	name: "AddTrace",
	props: {
		editId: {
			type: Number,
			required: true
		},
		btnId: {
			type: Number,
			required: true
		}
	},
	data() {
		return {
			title: "新增",
			baseUrl:process.env.BASE_API.replace("/index.php/api", "/"),
			// 提交表单
			formList: {
				goo_name:'',
				goo_goods_encode: "",
				goo_cate_name: "",
				goo_cate_id: "",
				goo_bra_name: "",
				goo_bra_id: "",
				goo_wholesale_price:'',//批发价
				goo_purchase_price :'',//采购价
				info_name: [],
				info_content: [],
				goaf_original_img:'',
			},
			// 表单验证
			formRules: {
				goo_name: [
					{ required: true, trigger: "blur", message: "请输入商品名称" }
				],
				goo_cate_id: [
					{ required: true, trigger: "change", message: "请选择商品品类" }
				],
				goo_wholesale_price: [
					{ required: true, trigger: "blur", message: "请输入商品批发价" }
				],
				goo_purchase_price: [
					{ required: true, trigger: "blur", message: "请输入商品采购价" }
				],
			},
			brandList:[],//商品品牌下拉菜单
			classList:[],//商品品类下拉菜单
			editInfoData:[],//编辑信息数据
			// 属性列表
			godsDetail: [
				{
					key: "",
					value: "",
					disabled: false,
					length: 30,
					show: 1,
					nothing2: false,
					nothing1: false,
					showText: "文本",
					type: 1,
					placeh: "",
					showBtn: false
				}
			],
			goodsPicUp:false,//商品图片来源，true=新上传,false=返回数据
		};
	},
	created() {
		if (this.btnId === 1) {
			this.pageInfor();
		}
	},
	methods: {
		// 编辑时获取数据
		pageInfor() {
			this.title = "编辑";
			const data = {};
			data.type = 1;
			data.goo_id = this.editId;
			const loading = this.$loading({
				lock: true,
				text: "Loading",
				spinner: "el-icon-loading",
				background: "rgba(0, 0, 0, 0.7)"
			});
			editGoods(data).then(response => {
				loading.close();
				const dataRep = response.data;
				if (errorStatus(dataRep)) {
					this.editInfoData.push(dataRep.data)
					this.formList = JSON.parse(JSON.stringify(dataRep.data));
					this.$nextTick(() => {
						this.formList.goo_purchase_price = (dataRep.data.goo_purchase_price/100)
						this.formList.goo_wholesale_price = (dataRep.data.goo_wholesale_price/100)
					})
					// var baseUrl = process.env.BASE_API.replace("/index.php/api", "/");
					// this.formList.goaf_original_img = baseUrl + dataRep.data.goaf_original_img
					// 商品品类
					if(dataRep.data.goo_cate_id != 0){
						this.classList.push({
							cate_id:dataRep.data.goo_cate_id,
							cate_name:dataRep.data.goo_cate_name,
						})
					}else{
						this.formList.goo_cate_id = '';
					}
					// 商品品牌
					if(dataRep.data.goo_bra_id != 0){
						this.brandList.push({
							bra_id:dataRep.data.goo_bra_id,
							bra_name:dataRep.data.goo_bra_name,
						})
					}else{
						this.formList.goo_bra_id = ''
					}
					// 商品属性
					if(dataRep.data.goaf_attribute){
						this.godsDetail = eval(dataRep.data.goaf_attribute);
					}
				}
			})
			.catch(Error => {
				this.$message.error("请求数据失败");
				loading.close();
			});
		},
		// 验证金额
		IWS_CheckDecimal(type) {
			this.$nextTick(() => {
				if(type ===1 ){//商品批发价
					this.formList.goo_wholesale_price = this.formList.goo_wholesale_price.replace(/[^\d.]/g,"");
					this.formList.goo_wholesale_price = this.formList.goo_wholesale_price.replace(/^(\-)*(\d+)\.(.\d{0,1}).*$/,'$1$2.$3');
				}else if(type === 2){//商品采购
					this.formList.goo_purchase_price = this.formList.goo_purchase_price.replace(/[^\d.]/g,"");
					this.formList.goo_purchase_price = this.formList.goo_purchase_price.replace(/^(\-)*(\d+)\.(.\d{0,1}).*$/,'$1$2.$3');
				}else{//商品零售
					this.formList.goo_price = this.formList.goo_price.replace(/[^\d.]/g,"");
					this.formList.goo_price = this.formList.goo_price.replace(/^(\-)*(\d+)\.(.\d{0,1}).*$/,'$1$2.$3');
				}
			})
		},
		// 提交
		submitInfo(formName) {
			this.$refs[formName].validate((valid) => {
				if (!valid) {
					return false;
				}else{
					const data = this.formList;
					var info_name = [];
					var info_content = [];
					if (this.formList.goo_name === "") {
						this.$message.error("请输入商品名称!");
						return false;
					}
					if (this.formList.goo_cate_id === "") {
						this.$message.error("请选择商品品类!");
						return false;
					}
					if (this.formList.goo_price === "") {
						this.$message.error("请输入商品销售价格!");
						return false;
					}
					if (this.formList.goo_wholesale_price === "") {
						this.$message.error("请输入商品批发价格!");
						return false;
					}
					if (this.formList.goo_purchase_price === "") {
						this.$message.error("请输入商品采购价格!");
						return false;
					}
					const godsDetail = this.godsDetail;
					if(godsDetail.length===1){
						if(godsDetail[0].key === "" && godsDetail[0].value === ""){
							this.$delete(godsDetail,0)
						}
					}
					if (godsDetail.length !== 0) {
						for (var i in godsDetail) {
							if (godsDetail[i].key === "") {
								this.$message.error("请输入标题名称!");
								this.$set(this.godsDetail[i], "nothing1", true);
								return false;
							} else if (godsDetail[i].value === "") {
								this.$message.error("请输入内容! ");
								this.$set(this.godsDetail[i], "nothing2", true);
								return false;
							} else 
							if (godsDetail[i].key.length>8) {
								this.$message.error("标题名称超过8位!");
									return false;
							}
							info_name.push(godsDetail[i].key);
							info_content.push(godsDetail[i].value);
						}
					}
					if(this.btnId ===1){
						if(isNaN(this.formList.goo_bra_id)){
							this.formList.goo_bra_id= this.editInfoData[0].goo_bra_id
						}
						if(isNaN(this.formList.goo_cate_id)){
							this.formList.goo_cate_id= this.editInfoData[0].goo_cate_id
						}
					}
					if (this.formList.goo_bra_id === "" || this.formList.goo_bra_id===0) {
						delete data.goo_bra_id;
						delete data.goo_bra_name
					}
				 
					if (this.formList.goaf_another_name === "") {
						delete data.goaf_another_name;
					}
					const leng = /^.{0,9}/;
				 
					if (this.formList.goo_bra_id !== 0 && this.formList.goo_bra_id) {
						for (var i in this.brandList) {
							if (this.formList.goo_bra_id === this.brandList[i].bra_id) {
								data.goo_bra_name = this.brandList[i].bra_name;
							}
						}
					}
					for (var i in this.classList) {
						if (this.formList.goo_cate_id === this.classList[i].cate_id) {
							data.goo_cate_name = this.classList[i].cate_name;
						}
					}


					data.info_name = info_name;
					data.info_content = info_content;
					if(godsDetail.length === 0){
						delete data.info_name
						delete	data.info_content
					}


					const loading = this.$loading({
						lock: true,
						text: "Loading",
						spinner: "el-icon-loading",
						background: "rgba(0, 0, 0, 0.7)"
					});

					if (this.btnId === 0) {
						addGoods(data).then(response => {
							loading.close();
							const dataRep = response.data;
							if (errorStatus(dataRep)) {
								this.$emit("listerToChild", "addPage"); // 返回
								this.$message.success('新增商品成功!');
								_this.$refs[formName].resetFields();
								const godsDetail = this.godsDetail;
								for (const i in godsDetail) {
									this.godsDetail[i].key = "";
									this.godsDetail[i].value = "";
									this.godsDetail[i].showBtn = false;
									this.godsDetail.splice(i, 1);
								}
							}
							loading.close();
						})
						.catch(Error => {
							// this.$message.error("提交请求失败!");
							loading.close();
						});
					} else {
						data.type = 2;
						if (this.formList.goaf_id) {
							data.goaf_id = this.formList.goaf_id;
						} else {
							data.goaf_id = 0;
						}
						if(data.goaf_another_name == '' || data.goaf_another_name == null){
							delete data.goaf_another_name
						}
						data.goo_id = this.editId;
						editGoods(data).then(response => {
							loading.close();
							const dataRep = response.data;
							if (errorStatus(dataRep)) {
								this.$message.success(dataRep.data);
								this.$emit("listerToChild", "addPage"); // 返回
							}
						})
						.catch(Error => {
							loading.close();
						});
					}
				}
			})
		},
		// 增加
		addInfor() {
			const godsDetail = this.godsDetail;
			const detail = {
				key: "",
				value: "",
				show: 1,
				type: 1,
				nothing2: false,
				nothing1: false,
				placeh: "请输入内容",
				showBtn: false,
				showText: "文本"
			};
			const leng = godsDetail.length;
			this.$set(this.godsDetail, leng, detail);
		},
		// 删除
		deleteInfo(index) {
			if (index === 0) {
				this.$message.error("不可删除!");
				return false;
			} else {
				this.godsDetail.splice(index, 1);
			}
		},
		// 上移
		upInfor(index) {
			if (index === 0) {
				return false;
			}
			const index_0 = index - 1;
			const goodsDetail = this.godsDetail;
			const infor = goodsDetail[index];
			const infor_0 = goodsDetail[index_0];
			this.$set(this.godsDetail, index, infor_0);
			this.$set(this.godsDetail, index_0, infor);
		},
		// 下移
		downInfor(index) {
			const leng = this.godsDetail.length - 1;
			const godsDetail = this.godsDetail;
			if (index === leng) {
				return false;
			}
			const index_0 = index + 1;
			const infor = godsDetail[index];
			const infor_0 = godsDetail[index_0];
			this.$set(this.godsDetail, index, infor_0);
			this.$set(this.godsDetail, index_0, infor);
		},
		// 返回
		back() {
			this.$confirm("商品信息未保存, 确定离开?", "提示", {
				confirmButtonText: "确定",
				cancelButtonText: "取消",
				type: "warning"
			})
			.then(() => {
				this.$emit("listerToChild", "addPage");
			})
			.catch(() => {});
		},
		// 获取品牌
		getBrandDataBtn(val) {
			const data = {};
			data.search_data = val;
			getBrandInfo(data).then(response => {
				this.brandList = [];
				const dataRep = response.data
				if (errorStatus(dataRep)) {
					this.brandList = dataRep.data.data;
				}
			});
		},
		// 获取品类
		getCategoryDataBtn(val) {
			const data = {};
			data.search_data = val;
			getCategoryInfo(data).then(response => {
				this.classList = [];
				const dataRep = response.data
				if (errorStatus(dataRep)) {
					this.classList = dataRep.data.data;
				}
			});
		},
		// 触发上传图片事件
		goodsImgUpBtn(){
			document.getElementById('GoodsUploadBtn').click();
		},
		// 上传商品图片
		onChangeGoodsImgBtn(e) {
			const _this = this
			// 利用fileReader对象获取file
			var file = e.target.files[0]
			var reader = new FileReader()
			reader.readAsDataURL(file)
			reader.onload = function(e) {
				// 读取到的图片base64 数据编码 将此编码字符串传给后台即可
				_this.formList.goaf_original_img = e.target.result
				_this.goodsPicUp = true;
			}
		},
		// 删除上传图片
		goodsImgDelBtn(){
			this.formList.goaf_original_img = '';
		},
		// 属性-标题验证
		blurKey(e, index) {
			const val = e.target.value;
			if (val === "") {
				this.$set(this.godsDetail[index], "nothing1", true);
			} else {
				this.$set(this.godsDetail[index], "nothing1", false);
			}
		},
		// 属性-内容验证
		blurValue(e, index) {
			const val = e.target.value;
			if (val === "") {
				this.$set(this.godsDetail[index], "nothing2", true);
			} else {
				this.$set(this.godsDetail[index], "nothing2", false);
			}
			if (this.godsDetail[index].type === 4) {
				if (!phoneTest(val)) {
					this.$message.error("请输入正确的手机号!");
					return false;
				}
			} else if (this.godsDetail[index].type === 3) {
				if (!validateURL(val)) {
					this.$message.error("请输入合法网址!");
					return false;
				}
			}
		},
		// 验证售价
		godsMoneyBlur(e){
			let reg = /^\d+(?=\.{0,1}\d+$|$)/;
			if(!reg.test(this.formList.goo_price)){
				this.$message.error('请输入正确的金额!')
				this.formList.goo_price = ''
				return false
			}
			this.formList.goo_price = parseFloat(this.formList.goo_price).toFixed(2)
		}
	}
};
</script>
<style scoped>
.mainGoodsUploadImgBox{width:340px;height:340px;border:1px dashed #ddd;position:relative;cursor:pointer;}
.mainGoodsUploadImgBox .el-icon-plus{display:block;font-size:40px;color:#aaa;position:absolute;top:50%;left:50%;margin:-20px 0 0 -20px;}
.mainGoodsUploadImgBox .fileTypeBox{display:none;}
.mainGoodsImgBox{width:340px;height:340px;border:1px dashed #ddd;position:relative;display:table-cell;vertical-align:middle;text-align:center;}
.mainGoodsImgBox img{max-width:100%;max-height:100%;}
.mainGoodsImgBox .editUploadBox{display:none;}
.mainGoodsImgBox:hover .editUploadBox{display:block;background-color:rgba(0, 0, 0, 0.5);position:absolute;top:0;left:0;right:0;bottom:0;z-index:9;}
.mainGoodsImgBox:hover .editUploadBox .el-icon-delete{font-size:20px;color:#fff;position:absolute;top:50%;left:50%;margin:-10px 0 0 -10px;cursor:pointer;}
.mainGoodsHeaderBox{height:30px;font-size:14px;}
.mainGoodsHeaderBox .operateBox span{display:inline-block;padding:0 24px 0 14px;}
.mainGoodsInfoBox{margin-bottom:10px;}
</style>