<template>
	<div>
		<!-- 信息筛选 -->
		<el-row class="mainContentItemBox">
			<div class="mainHeaderTitleBox">
				<div class="titleNameBox">信息筛选</div>
				<div class="buttonBox"></div>
			</div>
			<el-form ref="formList" :model="formList" size="medium" label-width="100px" class="mainSearchItemBox">
				<el-row>
					<el-col :span="6">
						<el-form-item label="品牌名称:" prop="bra_name">
							<el-input v-model="formList.bra_name" placeholder="请输入品牌名称" max="10" :maxlength="10" clearable class="mainIptSelBox"/>
						</el-form-item>
					</el-col>
					<el-col :span="6">
						<el-form-item label="状态:" prop="bra_state">
							<el-select v-model="formList.bra_state" clearable class="mainIptSelBox">
								<el-option v-for="item in stateSelectInfo" :key="item.id" :label="item.name" :value="item.id"/>
							</el-select>
						</el-form-item>
					</el-col>
					<el-col :span="6">
						<el-button class type="primary" @click="searchList('formList')">搜&nbsp;&nbsp;索</el-button>
						<el-button class @click="resetForm('formList')">重&nbsp;&nbsp;置</el-button>
					</el-col>
				</el-row>
			</el-form>
		</el-row>
		<!-- 列表 -->
		<el-row class="mainContentItemBox">
			<div class="mainHeaderTitleBox">
				<div class="titleNameBox">品牌列表</div>
				<div class="buttonBox">
				<el-button type="primary" v-if="btnShow.addBtn" @click="addBrandBtn()">新增</el-button>
					<el-button v-if="btnShow.startBtn" class="btn-staCol" @click="setBatchEnableBtn()">启用</el-button>
					<el-button v-if="btnShow.stopBtn" class="btn-delete" @click="setBatchStopBtn()">停用</el-button>
				</div>
			</div>
			<el-table :data="listData" width="100%" @selection-change="handleSelectionChange">
				<el-table-column type="selection" width="55"/>
				<el-table-column label="品牌名称" prop="bra_name" min-width align="center"/>
				<el-table-column label="商品数量" prop="bra_goods_quantity" align="center"/>
				<el-table-column label="状态" prop="bra_state" align="center">
					<template slot-scope="scope">
						{{ stateSelectInfo[scope.row.bra_state-1].name }}
					</template>
				</el-table-column>
				<el-table-column label="操作" width="260" align="center">
					<template slot-scope="scope">
						<el-button type="primary" v-if="btnShow.editBtn" @click="editBrandBtn(scope.row)">编辑</el-button>
						<el-button v-if="scope.row.bra_state == 2 && btnShow.startBtn" class="btn-staCol" @click="setStopEnableBtn(scope.row,1)">启用</el-button>
						<el-button v-if="scope.row.bra_state == 1 && btnShow.stopBtn" class="btn-delete" @click="setStopEnableBtn(scope.row,2)">停用</el-button>
					</template>
				</el-table-column>
			</el-table>
			<div v-if="listData.length>0" class="mainPageTurningBox">
				<el-pagination :current-page="currentPage" :page-size="pageSize" :total="totalNum" layout="total, prev, pager, next, jumper" background @current-change="handleCurrentChange"/>
			</div>
		</el-row>
		<!-- 新增和编辑 -->
		<el-dialog :visible.sync="showAddClas" :title="AddClastitle" :close-on-click-modal="false" width="400px" @close="resetForm('addClaForm')">
			<el-form ref="addClaForm" :model="addClaForm" :rules="addClaRules" label-width="100px">
				<el-form-item label="品牌名称:" prop="bra_name">
					<el-input v-model="addClaForm.bra_name" placeholder="请输入品牌名称" max="10" :maxlength="10" clearable class="mainIptSelBox"/>
				</el-form-item>
			</el-form>
			<span slot="footer">
				<el-button @click="showAddClas = false">取 消</el-button>
				<el-button type="primary" @click="addSubmitBtn('addClaForm')">提 交</el-button>
			</span>
		</el-dialog>
	</div>

</template>
<script>
import { brandList, addBrand, editBrand, delBrand, startBrand, stopBrand } from '@/api/goods'
import { errorStatus } from '@/utils/index'
export default {
	name: 'ClassList',
	data() {
		return {
			// 搜索参数
			formList: {
				bra_name: '',
				bra_state: '',
			},
			// 状态
			stateSelectInfo: [
				{ id: 1, name: '启用' },
				{ id: 2, name: '停用' }
			],
			listData: [],//信息列表
			chosed: '',
			currentPage: 1,//当前页码
			pageSize: null,//每页多少条
			totalNum: null,//总共多少条
			showAddClas: false,//弹框默认关闭
			AddClastitle: '',//弹框名称
			addClaSta: null, // 判断是新增还是编辑 1新增 2编辑
			// 新增表单
			addClaForm: {
				bra_name: '',
				bra_id: null
			},
			// 新增表单验证
			addClaRules: {
				bra_name: [
					{ required: true, trigger: 'blur', message: '品牌名称不能为空' }
					// { min: 1, max: 20, message: '品牌名称过长,字数不可超过20', trigger: 'blur' }
				]
			},
			// 按钮权限
			btnShow: {
				addBtn: false,
				editBtn: false,
				startBtn: false,
				stopBtn: false
			},
		}
	},
	created() {
		// 页面加载时
		this.getPageInfo()
	},
	methods: {
		// 列表
		getPageInfo() {
			const loading = this.$loading({
				lock: true,
				text: 'Loading',
				spinner: 'el-icon-loading',
				background: 'rgba(0, 0, 0, 0.7)'
			})
			const data = this.formList
			data.page = this.currentPage
			data.pri_id = this.$route.meta.pri_id
			// 获取列表
			brandList(data).then(response => {
				const dataRep = response.data
				if (errorStatus(dataRep)) {
					this.listData = dataRep.data.data
					this.currentPage = dataRep.data.current_page
					this.pageSize = dataRep.data.current_number
					this.totalNum = dataRep.data.total
					const btnList = dataRep.list_button
					for (const i in btnList) {
						if (btnList[i].pri_method_name === '新增') {
							this.btnShow.addBtn = true
						} else if (btnList[i].pri_method_name === '编辑') {
							this.btnShow.editBtn = true
						} else if (btnList[i].pri_method_name === '启用') {
							this.btnShow.startBtn = true
						} else if (btnList[i].pri_method_name === '停用') {
							this.btnShow.stopBtn = true
						}
					}
				}
				loading.close()
			})
			.catch(Error => {
				loading.close()
				this.$message.error('请求失败!')
				// console.log("获取列表err", err);
			})
		},
		// 搜索
		searchList(formName) {
			this.currentPage = 1
			this.getPageInfo()
		},
		// 重置
		resetForm(formName) {
			// console.log(formName);
			this.$refs[formName].resetFields()
		},
		// 批量启用
		setBatchEnableBtn() {
			if (this.chosed.length == 0) {
				this.$message.error('请选择要启用的品牌!');
				return false;
			}
			const braId = [];
			for (const i in this.chosed) {
				if (this.chosed[i].bra_state === 2) {
					braId.push(this.chosed[i].bra_id);
				}
			}
			if(braId.length == 0){
				this.$message.warning('您选中的品牌全部为“启用”状态，无需更改!');
				return false;
			}
			const data = {}
			data.bra_id = braId
			this.$confirm('请确认,是否启用选中的品牌?', '提示', {
				confirmButtonText: '确定',
				cancelButtonText: '取消',
				type: 'warning'
			}).then(() => {
				startBrand(data).then(response => {
					const dataRep = response.data;
					if (errorStatus(dataRep)) {
						this.$message.success(dataRep.data);
						this.getPageInfo();
					}
				})
				.catch(err => {
					this.$message.error('请求失败!')
				})
			})
			.catch(() => {
			})
		},
		// 批量停用
		setBatchStopBtn() {
			if (this.chosed.length == 0) {
				this.$message.error('请选择要停用的品牌!');
				return false;
			}
			const braId = [];
			for (const i in this.chosed) {
				if (this.chosed[i].bra_state === 1) {
					braId.push(this.chosed[i].bra_id);
				}
			}
			if(braId.length == 0){
				this.$message.warning('您选中的品牌全部为“停用”状态，无需更改!');
				return false;
			}
			const data = {}
			data.bra_id = braId
			this.$confirm('请确认,是否停用选中的品牌?', '提示', {
				confirmButtonText: '确定',
				cancelButtonText: '取消',
				type: 'warning'
			}).then(() => {
				stopBrand(data).then(response => {
					const dataRep = response.data;
					if (errorStatus(dataRep)) {
						this.$message.success(dataRep.data)
						this.getPageInfo();
					}
				})
				.catch(err => {
					this.$message.error('请求失败!')
				})
			})
			.catch(() => {
				// console.log("取消停用");
			})
		},
		// 启用/停用
		setStopEnableBtn(row, num) {
			const data = {}
			data.bra_id = [row.bra_id]
			if (num === 1) {
				// 启用
				startBrand(data).then(response => {
					if (errorStatus(response.data)) {
						this.$message.success('启用成功!')
						row.bra_state = num
					}
				})
				.catch(Error => {
					this.$message.error('启用失败!')
				})
			} else {
				// 停用
				stopBrand(data).then(response => {
					if (errorStatus(response.data)) {
						this.$message.success('停用成功!')
						row.bra_state = num
					}
				})
				.catch(Error => {
					this.$message.error('停用失败!')
				})
			}
		},
		// 新增打开
		addBrandBtn() {
			this.addClaSta = 1
			this.AddClastitle = '新增品牌'
			this.showAddClas = true
		},
		// 编辑打开
		editBrandBtn(row) {
			this.addClaForm.bra_name = row.bra_name
			this.addClaForm.bra_id = row.bra_id
			this.addClaSta = 2
			this.AddClastitle = '编辑品牌'
			this.showAddClas = true
		},
		// 选中状态
		handleSelectionChange(val) {
			this.chosed = val
		},
		// 页面--分页器
		handleCurrentChange(val) {
			// console.log(`当前页: ${val}`)
			this.currentPage = val
			this.getPageInfo()
		},
		// 弹窗-增加-提交
		addSubmitBtn(formName) {
			this.$refs[formName].validate((valid) => {
				if (!valid) {
					return false;
				}else{
					if (this.addClaForm.bra_name === '') {
						this.$message.error('请输入品牌名称!')
						return false
					} 
					const data = this.addClaForm
					if (this.addClaSta === 1) {
						delete data.bra_id
						addBrand(data).then(response => {
							if (errorStatus(response.data)) {
								this.$message.success('提交成功!')
								this.showAddClas = false
								this.getPageInfo()
							}
						})
						.catch(err => {
							console.log('err', err)
							this.$message.error('请求失败!')
						})
					} else if (this.addClaSta === 2) {
						editBrand(data).then(response => {
							if (errorStatus(response.data)) {
								this.$message.success('提交成功!')
								this.showAddClas = false
								this.getPageInfo()
							}
						})
						.catch(err => {
							console.log('err', err)
							this.$message.error('请求失败!')
						})
					}
				}
			})
		},
	}
}
</script>
<style scoped >

</style>
