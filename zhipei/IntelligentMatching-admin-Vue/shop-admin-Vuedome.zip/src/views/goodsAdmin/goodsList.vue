<template>
	<div>
		<!-- 信息筛选 -->
		<el-row class="mainContentItemBox" v-if="!showAdd">
			<div class="mainHeaderTitleBox">
				<div class="titleNameBox">信息筛选</div>
				<div class="buttonBox"></div>
			</div>
			<el-form ref="formList" :model="formList" size="medium" label-width="100px" class="mainSearchItemBox">
				<el-row>
					<el-col :span="6">
						<el-form-item label="商品名称:" prop="goo_name">
							<el-input v-model="formList.goo_name" placeholder="请输入商品名称" clearable :maxlength="20" class="mainIptSelBox"/>
						</el-form-item>
					</el-col>
					<el-col :span="6">
						<el-form-item label="检索编号:" prop="goo_goods_encode">
							<el-input v-model="formList.goo_goods_encode" placeholder="请输入检索编号" clearable :maxlength="13" class="mainIptSelBox"/>
						</el-form-item>
					</el-col>
					<el-col :span="6">
						<el-form-item label="商品品类:" prop="goo_cate_id">
							<el-select v-model="formList.goo_cate_id" placeholder="请选择商品品类" @click.native="getCategoryDataBtn()" clearable filterable :multiple="false" remote :remote-method="getCategoryDataBtn" class="mainIptSelBox">
								<el-option v-for="item in classList" :key="item.cate_id" :label="item.cate_name" :value="item.cate_id" />
							</el-select>
						</el-form-item>
					</el-col>
					<el-col :span="6">
						<el-form-item label="商品品牌:" prop="goo_bra_id">
							<el-select v-model="formList.goo_bra_id" placeholder="请选择商品品牌" @click.native="getBrandDataBtn()" clearable filterable :multiple="false" remote :remote-method="getBrandDataBtn" class="mainIptSelBox">
								<el-option v-for="item in brandList" :key="item.bra_id" :label="item.bra_name" :value="item.bra_id" />
							</el-select>
						</el-form-item>
					</el-col>
					<el-col :span="6">
						<el-form-item label="商品状态:" prop="goo_state" >
							<el-select v-model="formList.goo_state" clearable class="mainIptSelBox">
								<el-option v-for="item in stateSelectInfo" :key="item.id" :label="item.name" :value="item.id"/>
							</el-select>
						</el-form-item>
					</el-col>
					<el-col :span="6">
						<el-button type="primary" @click="searchList('formList')">搜&nbsp;&nbsp;索</el-button>
						<el-button @click="resetForm('formList')">重&nbsp;&nbsp;置</el-button>
					</el-col>
				</el-row>
			</el-form>
		</el-row>
		<!-- 列表 -->
		<el-row v-if="!showAdd" class="mainContentItemBox">
			<div class="mainHeaderTitleBox">
				<div class="titleNameBox">商品列表</div>
				<div class="buttonBox">
					<el-button type="primary" v-if="btnShow.addBtn" @click="addGoodsBtn()">新增</el-button>
					<el-button v-if="btnShow.startBtn" class="btn-staCol" @click="enableClas()">上架</el-button>
					<el-button v-if="btnShow.stopBtn" class="btn-delete" @click="stopClas()">下架</el-button>
				</div>
			</div>
			<div class="lk-table-box">
				<el-table :data="listData" stripe width="100%" @selection-change="handleSelectionChange">
					<el-table-column type="selection" width="55"/>
					<el-table-column label="商品图片" prop="goo_price" align="center" width="140">
						<template slot-scope="scope">
							<el-image  style="width: 100px; height: 100px" :src="baseUrl+scope.row.goaf_small_img" :preview-src-list="[baseUrl+scope.row.goaf_original_img,baseUrl+scope.row.goaf_original_img]" fit="contain" @click="setGoodsPicPreviewBtn(scope.$index)">
								<div slot="error"><img width="100px" height="100px" src="@/assets/img/goods_img_none.jpg"/></div>
							</el-image>
						</template>
					</el-table-column>
					<el-table-column label="商品名称" prop="goo_name" min-width align="left" header-align="center" width="200"/>
					<el-table-column label="检索编号" prop="goo_goods_encode" align="center" width="160"/>
					<el-table-column label="品类" prop="goo_cate_name" align="center"/>
					<el-table-column label="品牌" prop="goo_bra_name" align="center"/>
					<el-table-column label="采购价(¥)" prop="goo_price" align="center">
						<template slot-scope="scope">
							{{Number(scope.row.goo_purchase_price)/100}}
						</template>
					</el-table-column>
					<el-table-column label="批发价(¥)" prop="goo_price" align="center">
						<template slot-scope="scope">
							{{Number(scope.row.goo_wholesale_price)/100}}
						</template>
					</el-table-column>
					<el-table-column label="总库存量" prop="goaf_stocks_quantity" align="center"/>
					<el-table-column fixed="right" label="状态" align="center">
						<template slot-scope="scope">
							{{ stateSelectInfo[scope.row.goo_state-1].name }}
						</template>
					</el-table-column>
					<el-table-column fixed="right" label="操作" align="center" width="230">
						<template slot-scope="scope">
							<div class="mainOperationBtnBox">
								<el-button type="primary" v-if="btnShow.editBtn" @click="editRow(scope.row)">编辑</el-button>
								<el-button v-if="scope.row.goo_state===2 && btnShow.startBtn" class="btn-staCol" @click="enableThisClas(scope.row,1)">上架</el-button>
								<el-button v-if="scope.row.goo_state===1 && btnShow.stopBtn" class="btn-delete" @click="enableThisClas(scope.row,2)">下架</el-button>
								<el-button v-if="btnShow.viewBtn" class="btn-mainCol" @click="viewGoodsBtn(scope.row.goo_id)">详情</el-button>
							</div>
						</template>
					</el-table-column>
				</el-table>
			</div>
			<div v-if="listData.length>0" class="mainPageTurningBox">
				<el-pagination :current-page="currentPage" :page-size="pageSize" :total="totalNum" layout="total, prev, pager, next, jumper" background @current-change="handleCurrentChange"/>
			</div>
		</el-row>
		<!-- 查看商品详情 -->
		<el-dialog :visible.sync="goodsDetailShow.show" :title="goodsDetailShow.title" :close-on-click-modal="false" :width="goodsDetailShow.width">
			<el-form size="medium" label-width="80px">
				<el-row>
					<el-col :span="12">
						<div class="mainDetailGoodsImgBox">
							<img :src="baseUrl+goodsDetailData.goaf_original_img" alt="" v-if="goodsDetailData.goaf_original_img" />
							<img src="@/assets/img/goods_img_none.jpg" v-else />
						</div>
					</el-col>
					<el-col :span="12">
						<el-col :span="24">
							<el-form-item label="商品名称:" prop="" class="mainFormSeeInfoBox">
								{{ goodsDetailData.goo_name }}
							</el-form-item>
						</el-col>
						<el-col :span="24">
							<el-form-item label="检索编码:" prop="" class="mainFormSeeInfoBox">
								{{ goodsDetailData.goo_goods_encode }}
							</el-form-item>
						</el-col>
						<el-col :span="24">
							<el-form-item label="品牌名称:" prop="" class="mainFormSeeInfoBox">
								{{ goodsDetailData.goo_bra_name }}
							</el-form-item>
						</el-col>
						<el-col :span="24">
							<el-form-item label="品类名称:" prop="" class="mainFormSeeInfoBox">
								{{ goodsDetailData.goo_cate_name }}
							</el-form-item>
						</el-col>
						<el-col :span="24">
							<el-form-item label="采购价格:" prop="" class="mainFormSeeInfoBox">
								¥{{ goodsDetailData.goo_purchase_price/100 }}
							</el-form-item>
						</el-col>
						<el-col :span="24">
							<el-form-item label="批发价格:" prop="" class="mainFormSeeInfoBox">
								¥{{ goodsDetailData.goo_wholesale_price/100 }}
							</el-form-item>
						</el-col>
					</el-col>
				</el-row>
			</el-form>
			<el-card class="box-card" shadow="none">
				<div slot="header" class="clearfix">
					<span>商品属性</span>
				</div>
				<el-form size="medium" label-width="120px" v-if="goodsDetailData.goaf_attribute">
					<el-row>
						<el-col :span="24" v-for="(item,index) in goodsDetailData.goaf_attribute" :key="index">
							<el-form-item :label="item.key" prop="" class="mainFormSeeInfoBox">
								{{ item.value }}
							</el-form-item>
						</el-col>
					</el-row>
				</el-form>
				<div v-else>暂无属性信息</div>
			</el-card>
		</el-dialog>
		<!-- 新增页面 -->
		<addgoods v-if="showAdd" :edit-id="edit_id" :btnId="btnId" @listerToChild="showListPages()"/>
	</div>
</template>
<script>
import { goodsList,startGoods,stopGoods,infoGoods} from '@/api/goods'
import { getBrandInfo,getCategoryInfo } from '@/api/commonAction'
import { errorStatus } from '@/utils/index'
import { getToken } from '@/utils/auth'
import Addgoods from './component/addGoods'
export default {
	name: 'goodsList',
	components: { Addgoods },
	data() {
		return {
			getToken:'',
			// 搜索表单
			formList: {
				goo_name: '',
				goo_goods_encode: '',
				goo_state: '',
				goo_bra_id: '',
				goo_cate_id: '',
			},
			baseUrl:process.env.BASE_API.replace("/index.php/api", "/"),
			showlist:1,//默认table列表打开的是属性查看
			brandList:[],//商品品牌下拉菜单
			classList:[],//商品品类下拉菜单
			goodsDetail:{},//商品属性
			listData: [],//列表
			// 商品详情
			goodsDetailShow:{
				title:'商品详情',
				show:false,
				width:'560px',
			},
			goodsDetailData:{},//商品详情
			// 商品状态
			stateSelectInfo: [
				{ id: 1, name: '上架' },
				{ id: 2, name: '下架' }
			],
			chosed:[],//列表全选ID
			currentPage: 1,
			pageSize: '',
			totalNum:'',
			showAdd: false,//新增和编号组件
			edit_id: 0,
			btnId:0,
			// 按钮权限
			btnShow: {
				addBtn: false,
				editBtn: false,
				startBtn: false,
				stopBtn: false,
				viewBtn: false,
			}
		}
	},
	created() {
		// 页面加载时
		this.getToken=localStorage.getItem('Admin-Token')
		this.getPageInfo()
	},
	methods: {
		// 获取列表
		getPageInfo() {
			const loading = this.$loading({
				lock: true,
				text: 'Loading',
				spinner: 'el-icon-loading',
				background: 'rgba(0, 0, 0, 0.7)'
			})
			const data = this.formList;
			data.page = this.currentPage
			data.pri_id = this.$route.meta.pri_id
			goodsList(data).then(response => {
				loading.close()
				const dataRep = response.data;
				if (errorStatus(dataRep)) {
					this.listData = dataRep.data.data;
					// for(var i in this.listData){
					// 	this.listData[i].previewPic = [];
					// 	this.listData[i].previewPic.push(this.baseUrl+this.listData[i].goaf_original_img);
					// }
					this.currentPage = dataRep.data.current_page;
					this.pageSize = dataRep.data.current_number;
					this.totalNum = dataRep.data.total;
					// 获取按钮
					const btnList = dataRep.list_button;
					for (const i in btnList) {
						if (btnList[i].pri_method_name === '新增') {
							this.btnShow.addBtn = true;
						} else if (btnList[i].pri_method_name === '编辑') {
							this.btnShow.editBtn = true;
						} else if (btnList[i].pri_method_name === '启用') {
							this.btnShow.startBtn = true;
						} else if (btnList[i].pri_method_name === '停用') {
							this.btnShow.stopBtn = true;
						} else if (btnList[i].pri_method_name === '详情') {
							this.btnShow.viewBtn = true;
						}
					}
				}
			})
			.catch(err => {
				loading.close()
				this.$message.error('请求失败!')
			})
		},
		// 获取品牌
		getBrandDataBtn(val) {
			const data = {};
			data.search_data = val;
			getBrandInfo(data).then(response => {
				const dataRep = response.data
				if (errorStatus(dataRep)) {
					this.brandList = dataRep.data.data;
				}
			});
		},
		// 获取品类
		getCategoryDataBtn(val) {
			const data = {};
			data.search_data = val;
			getCategoryInfo(data).then(response => {
				const dataRep = response.data
				if (errorStatus(dataRep)) {
					this.classList = dataRep.data.data;
				}
			});
		},
		// 搜索
		searchList(formName) {
			this.currentPage = 1
			this.getPageInfo()
		},
		// 查看详情
		viewGoodsBtn(val){
			const data = {};
			data.goo_id = val;
			infoGoods(data).then(response => {
				const dataRep = response.data
				this.goodsDetailData = {};
				if (errorStatus(dataRep)) {
					this.goodsDetailData = dataRep.data;
					this.goodsDetailData.goaf_attribute = eval(dataRep.data.goaf_attribute);
					this.goodsDetailShow.show = true;
				}
			})
			.catch(Error => {
				this.$message.error('请求失败!')
			})
		},
		// 重置
		resetForm(formName) {
			this.$refs[formName].resetFields()
		},
		// 上架/下架
		enableThisClas(row, num) {
			const data = {}
			data.goo_id = [row.goo_id]
			if (num === 1) {
				startGoods(data).then(response => {
					if (errorStatus(response.data)) {
						this.$message.success('上架成功!')
						row.goo_state = num
					}
				})
				.catch(Error => {
					this.$message.error('请求失败!')
				})
			} else if (num === 2) {
				stopGoods(data).then(response => {
					if (errorStatus(response.data)) {
						this.$message.success('下架成功!')
						row.goo_state = num
					}
				})
				.catch(Error => {
					this.$message.error('请求失败!')
				})
			}
		},
		// 批量上架
		enableClas() {
			if (this.chosed.length < 1) {
				this.$message.warning('请选择要上架的商品!')
				return false;
			}
			const goodsId = [];
			for(let i in this.chosed){
				if(this.chosed[i].goo_state == 2){
					goodsId.push(this.chosed[i].goo_id);
				}
			}
			if(goodsId.length == 0){
				this.$message.warning('您选中的商品全部为“上架”状态，无需更改!')
				return false;
			}
			this.$confirm('请确认,是否上架选中的商品?', '提示', {
				confirmButtonText: '确定',
				cancelButtonText: '取消',
				type: 'warning'
			}).then(() => {
				const data = {}
				data.goo_id = goodsId
				startGoods(data).then(response => {
					const dataRep = response.data
					if (errorStatus(dataRep)) {
						this.getPageInfo();
						this.$message.success('批量上架成功!')
					}
				})
				.catch(err => {
					this.$message.error('批量上架请求失败!')
				})
			})
			.catch(() => {
			})
		},
		// 批量下架
		stopClas() {
			if (this.chosed.length < 1) {
				this.$message.warning('请选择要下架的商品!')
				return false;
			}
			const goodsId = [];
			for(let i in this.chosed){
				if(this.chosed[i].goo_state == 1){
					goodsId.push(this.chosed[i].goo_id);
				}
			}
			if(goodsId.length == 0){
				this.$message.warning('您选中的商品全部为“下架”状态，无需更改!')
				return false;
			}
			this.$confirm('请确认,是否下架选中的商品?', '提示', {
				confirmButtonText: '确定',
				cancelButtonText: '取消',
				type: 'warning'
			}).then(() => {
				const data = {}
				data.goo_id = goodsId
				stopGoods(data).then(response => {
					if (errorStatus(response.data)) {
						this.getPageInfo();
						this.$message.success('批量下架成功!')
					}
				})
				.catch(err => {
					this.$message.error('批量下架请求失败!')
				})
			})
			.catch(() => {
			})
		},
		// 新增
		addGoodsBtn() {
			this.showAdd = true
			this.btnId = 0
		},
		// 编辑
		editRow(row) {
			this.edit_id = row.goo_id
			this.showAdd = true
			this.btnId = 1
		},
		// 关闭新增和编辑
		showListPages() {
			this.showAdd = false
			this.getPageInfo()
		},
		// 选中状态
		handleSelectionChange(val) {
			this.chosed = val;
		},
		// 页面--分页器
		handleCurrentChange(val) {
			// console.log(`当前页: ${val}`)
			this.currentPage = val
			this.getPageInfo()
		},
		// 预览图片，处理默认不显示图片的问题
		setGoodsPicPreviewBtn(index){
			document.getElementsByClassName("el-image-viewer__next")[index].click();
		},
	}
}
</script>
<style scoped>
/* 列表图片 */
.mainGoddsImgBox{width:100px;height:100px;display:table-cell;vertical-align:middle;text-align:center;margin:0 auto;}
.mainGoddsImgBox img{max-width:100%;max-height:100%;}
/* 详情图片 */
.mainDetailGoodsImgBox{width:230px;height:230px;display:table-cell;vertical-align:middle;text-align:center;}
.mainDetailGoodsImgBox img{max-width:100%;max-height:100%;}
</style>