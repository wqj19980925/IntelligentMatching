<template>
	<div>
		<!-- 信息筛选 -->
		<el-row class="mainContentItemBox">
			<div class="mainHeaderTitleBox">
				<div class="titleNameBox">信息筛选</div>
				<div class="buttonBox"></div>
			</div>
			<el-form ref="formList" :model="formList" size="medium" label-width="100px" class="mainSearchItemBox">
				<el-row>
					<el-col :span="6">
						<el-form-item label="品牌名称:" prop="cate_name">
							<el-input v-model="formList.cate_name" placeholder="请输入品类名称" max="10" :maxlength="10" clearable class="mainIptSelBox"/>
						</el-form-item>
					</el-col>
					<el-col :span="6">
						<el-form-item label="状态:" prop="cate_state">
							<el-select v-model="formList.cate_state" clearable class="mainIptSelBox">
								<el-option v-for="item in stateSelectInfo" :key="item.id" :label="item.name" :value="item.id"/>
							</el-select>
						</el-form-item>
					</el-col>
					<el-col :span="6">
						<el-button class type="primary" @click="searchList('formList')">搜&nbsp;&nbsp;索</el-button>
						<el-button class @click="resetForm('formList')">重&nbsp;&nbsp;置</el-button>
					</el-col>
				</el-row>
			</el-form>
		</el-row>
		<el-row class="mainContentItemBox">
			<div class="mainHeaderTitleBox">
				<div class="titleNameBox">品类列表</div>
				<div class="buttonBox">
					<el-button type="primary" v-if="btnShow.addBtn" @click="addClassBtn()">新增</el-button>
					<el-button v-if="btnShow.startBtn" class="btn-staCol" @click="setBatchEnableBtn()">启用</el-button>
					<el-button v-if="btnShow.stopBtn" class="btn-delete" @click="setBatchStopBtn()">停用</el-button>
				</div>
			</div>
			<el-table :data="listData" width="100%" @selection-change="handleSelectionChange">
				<el-table-column type="selection" width="55" />
				<!-- <el-table-column prop='id' width='0'></el-table-column> -->
				<el-table-column label="品类名称" prop="cate_name" min-width align="center" />
				<el-table-column label="隶属上级" prop="cate_parent_name" min-width align="center">
					<template slot-scope="scope">
						<span v-if="scope.row.cate_parent_name">{{scope.row.cate_parent_name}}</span>
						<span v-else>顶级品类</span>
					</template>
				</el-table-column>
				<el-table-column label="商品数量" prop="cate_goods_quantity" min-width align="center" />
				<el-table-column label="状态" prop="" align="center">
					<template slot-scope="scope">
						{{ stateSelectInfo[scope.row.cate_state-1].name }}
					</template>
				</el-table-column>
				<el-table-column label="操作" width="250" align="center">
					<template slot-scope="scope">
						<el-button type="primary" v-if="btnShow.editBtn" @click="editClassBtn(scope.row)">编辑</el-button>
						<el-button v-if="scope.row.cate_state == 2 && btnShow.startBtn" class="btn-staCol" @click="setStopEnableBtn(scope.row,1)">启用</el-button>
						<el-button v-if="scope.row.cate_state == 1 && btnShow.stopBtn" class="btn-delete" @click="setStopEnableBtn(scope.row,2)">停用</el-button>
					</template>
				</el-table-column>
			</el-table>
			<div v-if="listData.length>0" class="mainPageTurningBox">
				<el-pagination :current-page="currentPage" :page-size="pageSize" :total="totalNum" layout="total, prev, pager, next, jumper" background @current-change="handleCurrentChange"/>
			</div>
		</el-row>
		<!-- 新增/编辑 -->
		<el-dialog :visible.sync="showAddClas" :title="AddClastitle" :close-on-click-modal="false" width="450px" @close="resetForm('addClaForm')">
			<el-form ref="addClaForm" :model="addClaForm" label-width="100px" :rules="rules"> 
				<el-form-item label="隶属上级:" prop="cate_parent_id"> 
					<el-select v-model="addClaForm.cate_parent_id" class="mainIptSelBox"> 
						<el-option v-for="item in cateParentInfo" :key="item.cate_id" :label="item.cate_name" :value="item.cate_id"/>
					</el-select>
				</el-form-item>
				<el-form-item label="品类名称:" prop="cate_name"> 
					<el-input v-model="addClaForm.cate_name" placeholder="请输入品类名称" maxlength="10"  class="mainIptSelBox"/>
				</el-form-item>
			</el-form>
			<span slot="footer">
				<el-button @click="showAddClas = false">取 消</el-button>
				<el-button type="primary" @click="addsubBtn('addClaForm')">提 交</el-button>
			</span>
		</el-dialog>
	</div>
</template>
<script>
import { ClasList,addClass,editClass,delClas,openClas,stopeClas,GooClassifis,searchParent } from "@/api/goods";
import { errorStatus } from "@/utils/index";
import { getCategoryInfo } from "@/api/commonAction";
export default {
	name: "ClassList",
	data() {
		return {
			// 搜索表单
			formList: {
				cate_name: "",
				cate_state: ""
			},
			// 状态
			stateSelectInfo: [
				{ id: 1, name: "启用" },
				{ id: 2, name: "停用" }
			],
			listData: [],//列表
			chosed: "",
			currentPage: 1,
			pageSize: null,
			totalNum: null,
			showAddClas: false,//弹框默认关闭
			AddClastitle: "",//弹框名称
			addClaSta: null, // 判断是新增还是编辑 1新增 2编辑
			// 新增表单
			addClaForm: {
				cate_name: "",
				cate_parent_id: "",
				cate_id: ""
			},
			// 新增表单验证
			rules:{
				 cate_name: [
					{ required: true, message: "品类名称不能为空!", trigger: "change" }
				],
				cate_parent_id: [
					{ required: true, message: "隶属上级不能为空!", trigger: "change" }
				],
			},
			cateParentInfo: [],//品类下拉菜单
			// 按钮权限
			btnShow: {
				addBtn: false,
				editBtn: false,
				delBtn: false,
				startBtn: false,
				stopBtn: false
			},
		};
	},
	created() {
		// 页面加载时
		this.getPageInfo();
	},
	methods: {
		// 获取列表
		getPageInfo() {
			const loading = this.$loading({
				lock: true,
				text: "Loading",
				spinner: "el-icon-loading",
				background: "rgba(0, 0, 0, 0.7)"
			});
			const data = this.formList;
			data.page = this.currentPage;
			data.pri_id = this.$route.meta.pri_id;
			ClasList(data).then(response => {
				loading.close();
				const dataRep = response.data;
				if (errorStatus(dataRep)) {
					this.listData = dataRep.data.data;
					this.currentPage = dataRep.data.current_page;
					this.pageSize = dataRep.data.current_number;
					this.totalNum = dataRep.data.total;
					const btnList = dataRep.list_button;
					for (const i in btnList) {
						if (btnList[i].pri_method_name === "新增") {
							this.btnShow.addBtn = true;
						} else if (btnList[i].pri_method_name === "编辑") {
							this.btnShow.editBtn = true;
						} else if (btnList[i].pri_method_name === "启用") {
							this.btnShow.startBtn = true;
						} else if (btnList[i].pri_method_name === "停用") {
							this.btnShow.stopBtn = true;
						}
					}
				}
				
			}).catch(Error => {
				loading.close();
				this.$message.error("请求失败!");
			});
		},
		// 搜索
		searchList(formName) {
			this.currentPage = 1;
			this.getPageInfo();
		},
		// 重置
		resetForm(formName) {
			this.$refs[formName].resetFields();
		},
		// 批量启用
		setBatchEnableBtn() {
			if (this.chosed.length == 0) {
				this.$message.error("请选择要启用的品类!");
				return false;
			}
			const cateId = [];
			for (const i in this.chosed) {
				if (this.chosed[i].cate_state === 2) {
					cateId.push(this.chosed[i].cate_id);
				}
			}
			if(cateId.length == 0){
				this.$message.warning('您选中的品类全部为“启用”状态，无需更改!');
				return false;
			}
			const data = {};
			data.cate_id = cateId;
			this.$confirm("请确认,是否启用选中的品类?", "提示", {
				confirmButtonText: "确定",
				cancelButtonText: "取消",
				type: "warning"
			}).then(() => {
				openClas(data).then(response => {
					const dataRep = response.data;
					if (errorStatus(dataRep)) {
						this.$message.success(dataRep.data);
						this.getPageInfo();
					}
				})
				.catch(err => {
					this.$message.error("请求失败!");
				});
			}).catch(() => {
			});
		},
		// 批量停用
		setBatchStopBtn() {
			if (this.chosed.length == 0) {
				this.$message.error("请选择要停用的品类!");
				return false;
			}
			const cateId = [];
			for (const i in this.chosed) {
				if (this.chosed[i].cate_state === 1) {
					cateId.push(this.chosed[i].cate_id);
				}
			}
			if(cateId.length == 0){
				this.$message.warning('您选中的品类全部为“启用”状态，无需更改!');
				return false;
			}
			const data = {};
			data.cate_id = cateId;
			this.$confirm("请确认,是否停用选中品类?", "提示", {
				confirmButtonText: "确定",
				cancelButtonText: "取消",
				type: "warning"
			}).then(() => {
				stopeClas(data).then(response => {
					const dataRep = response.data;
					if (errorStatus(dataRep)) {
						this.$message.success(dataRep.data);
						this.getPageInfo();
					}
				})
				.catch(err => {
					this.$message.error("请求失败!");
				});
			}).catch(() => {
			});
		},
		// 启用/停用
		setStopEnableBtn(row, num) {
			const data = {};
			data.cate_id = [row.cate_id];
			if (num === 1) {
				// 启用
				openClas(data).then(response => {
					const dataRep = response.data;
					if (errorStatus(dataRep)) {
						this.$message.success("启用成功!");
						row.cate_state = num;
					}
				})
				.catch(Error => {
					this.$message.error("启用失败!");
				});
			} else {
				// 停用
				stopeClas(data).then(response => {
					const dataRep = response.data;
					if (errorStatus(dataRep)) {
						this.$message.success("停用成功!");
						row.cate_state = num;
					}
				})
				.catch(Error => {
					this.$message.error("停用失败!");
				});
			}
		},
		// 新增
		addClassBtn() {
			this.getThisParentBtn();
			this.addClaSta = 1;
			this.AddClastitle = "新增品类";
			this.showAddClas = true;
		},
		// 编辑
		editClassBtn(row) {
			this.addClaForm.cate_id = row.cate_id;
			this.addClaForm.cate_name = row.cate_name;
			this.addClaForm.cate_parent_id = row.cate_parent_id
			this.addClaSta = 2;
			this.AddClastitle = "编辑品类";
			this.showAddClas = true;
		},
		// 品类下拉菜单
		getThisParentBtn() {
			const loading = this.$loading({
				lock: true,
				text: "Loading",
				spinner: "el-icon-loading",
				background: "rgba(0, 0, 0, 0.7)"
			});
			const data = {};
			getCategoryInfo(data).then(response => {
				loading.close();
				const dataRep = response.data;
				if (errorStatus(dataRep)) {
					this.cateParentInfo = dataRep.data.data;
					const gos = { cate_id: 0, cate_name: "顶级品类" };
					this.cateParentInfo.unshift(gos);
				}
			}).catch(Error => {
				loading.close();
				this.$message.error("获取列表失败");
			});
		},
		// 选中状态
		handleSelectionChange(val) {
			this.chosed = val;
		},
		// 页面--分页器
		handleCurrentChange(val) {
			// console.log(`当前页: ${val}`)
			this.currentPage = val;
			this.getPageInfo();
		},
		// 弹窗-增加-提交
		addsubBtn(formName) {
			this.$refs[formName].validate((valid) => {
				if (!valid) {
					return false;
				}else{
					const addClas = this.addClaForm;
					const addClaSta = this.addClaSta;
					const val = this.addClaForm.cate_name;
					if (addClas.cate_name === "") {
						this.$message.error("请输入品类名称!");
						return false;
					}
					if(this.addClaForm.cate_parent_id === '' && this.addClaForm.cate_parent_id !== 0){
						this.$message.error('隶属上级不能为空')
						return false
					}
					if (addClaSta === 1) {
						delete addClas.cate_id;
						addClass(addClas).then(response => {
							if (errorStatus(response.data)) {
								this.$message.success("提交成功!");
								this.showAddClas = false;
								this.getPageInfo();
							}
						})
						.catch(err => {
							console.log("err", err);
							this.$message.error("请求失败!");
						});
					} else if (addClaSta === 2) {
						editClass(addClas).then(response => {
							if (errorStatus(response.data)) {
								this.$message.success("提交成功!");
								this.showAddClas = false;
								this.getPageInfo();
							}
						})
						.catch(err => {
							console.log("err", err);
							this.$message.error("请求失败!");
						});	
					}
				}
			})
		},
	}
};
</script>

