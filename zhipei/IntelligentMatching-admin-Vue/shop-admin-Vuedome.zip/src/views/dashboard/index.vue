<template>
	<view>11111111111111111111</view>
</template>

<script>

export default {};
</script>
<style lang="scss" scoped>
.app-container {
	padding: 15px;
	.app_indexBox {
		display: flex;
		.app_cashierBtn {
			width: 850px;
			height: 300px;
			background: #fff;
			text-align: center;
			cursor: pointer;
			position: relative;
			overflow: hidden;
			.sytContent{
				height: 70px;
				width: 250px;
				text-align: center;
				margin-left: 150px;
				margin-top: 100px;
				span {
					display: inline-block;
					font-size: 34px;
					font-weight: bold;
					margin-left: 15px;
				}
				img{
					display: inline-block;
					width: 80px;
					vertical-align: middle;
				}
			}
			.sytImg{
				position: absolute;
				bottom: -50px;
				right: -30px;
				width: 250px;
			}
		}
		.app_btnlist {
			margin-right: 20px;
			background: #fff;
			height: 240px;
			text-align: center;
			cursor: pointer;
			border-radius: 10px;
			box-shadow: 0 0 5px #dbdbdb;
				.imgNoDefalue{
					margin-top: 55px;
					display:none;
				}
				.imgDefalue{
					margin-top: 55px;
					display:block;
				}
			span{
				font-size: 14px;
				color: #999999;
				margin-top: -10px;
				display: inline-block;
			}
		}
		.hoverEffect1:hover{
			background: #f94a6d;
			color:#fff;
				.imgNoDefalue{
					margin-top: 55px;
					display:block;
				}
				.imgDefalue{
					margin-top: 55px;
					display:none;
				}
			span{
				color: #fff !important;
			}
		}
		.hoverEffect2:hover{
			background: #31bbe9;
			color:#fff;
			.imgNoDefalue{
					margin-top: 55px;
					display:block;
				}
				.imgDefalue{
					margin-top: 55px;
					display:none;
				}
				span{
				color: #fff !important;
			}
		}
		.hoverEffect3:hover{
			background: #ff9c00;
			color:#fff;
			.imgNoDefalue{
					margin-top: 55px;
					display:block;
				}
				.imgDefalue{
					margin-top: 55px;
					display:none;
				}
				span{
				color: #fff !important;
			}
		}
		.hoverEffect4:hover{
			background: #30bdb1;
			color:#fff;
			.imgNoDefalue{
					margin-top: 55px;
					display:block;
				}
				.imgDefalue{
					margin-top: 55px;
					display:none;
				}
				span{
				color: #fff !important;
			}
		}
		.hoverEffect5:hover{
			background: #ba8c2a;
			color:#fff;
			.imgNoDefalue{
					margin-top: 55px;
					display:block;
				}
				.imgDefalue{
					margin-top: 55px;
					display:none;
				}
				span{
				color: #fff !important;
			}
		}
		.hoverEffect6:hover{
			background: #3ed992;
			color:#fff;
			.imgNoDefalue{
					margin-top: 55px;
					display:block;
				}
				.imgDefalue{
					margin-top: 55px;
					display:none;
				}
				span{
				color: #fff !important;
			}
		}
		.hoverEffect7:hover{
			background: #1b9c60;
			color:#fff;
			.imgNoDefalue{
					margin-top: 55px;
					display:block;
				}
				.imgDefalue{
					margin-top: 55px;
					display:none;
				}
				span{
				color: #fff !important;
			}
		}
		.hoverEffect8:hover{
			background: #e39315;
			color:#fff;
			.imgNoDefalue{
					margin-top: 55px;
					display:block;
				}
				.imgDefalue{
					margin-top: 55px;
					display:none;
				}
				span{
				color: #fff !important;
			}
		}
		.hoverEffect9:hover{
			background: #1dbbc1;
			color:#fff;
			.imgNoDefalue{
					margin-top: 55px;
					display:block;
				}
				.imgDefalue{
					margin-top: 55px;
					display:none;
				}
				span{
				color: #fff !important;
			}
		}
		.hoverEffect10:hover{
			background: #ff6500;
			color:#fff;
			.imgNoDefalue{
					margin-top: 55px;
					display:block;
				}
				.imgDefalue{
					margin-top: 55px;
					display:none;
				}
				span{
				color: #fff !important;
			}
		}
		.hoverEffect11:hover{
			background: #8cc90e;
			color:#fff;
			.imgNoDefalue{
					margin-top: 55px;
					display:block;
				}
				.imgDefalue{
					margin-top: 55px;
					display:none;
				}
				span{
				color: #fff !important;
			}
		}
		.marL_20 {
			margin-left: 20px;
		}
	}
	.marT_20 {
		margin-top: 20px;
	}
}
</style>
<style scoped> 
.imgsyt img{width:60px;height:60px;}
/*.app-container .app_indexBox */
</style>